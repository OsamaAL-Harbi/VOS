<?php
session_start();
header('Content-Type: application/json');

try {
    // Database connection
    $host = 'localhost'; // Replace with your database host
    $dbname = 'faculty'; // Replace with your database name
    $username = 'root'; // Replace with your database username
    $password = 'Root'; // Replace with your database password

    // Create PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get input data
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = intval($data['complaint_id'] ?? 0);
    $comment = trim($data['comment'] ?? '');
    $faculty_id = $_SESSION['faculty_id'];

    // Validate input
    if (!$complaint_id || !$comment || !$faculty_id) {
        echo json_encode(['success' => false, 'message' => 'Invalid input']);
        exit;
    }

    // Begin transaction
    $pdo->beginTransaction();

    // Update complaint status to "Rejected"
    $updateQuery = "UPDATE complaints SET status = 'Rejected' WHERE complaint_id = :complaint_id";
    $stmt = $pdo->prepare($updateQuery);
    $stmt->bindParam(':complaint_id', $complaint_id, PDO::PARAM_INT);
    $stmt->execute();

    // Insert action into complaint_actions table
    $actionQuery = "
        INSERT INTO complaint_actions (complaint_id, action_type, action_by, comment)
        VALUES (:complaint_id, 'Rejected', :faculty_id, :comment)
    ";
    $stmt = $pdo->prepare($actionQuery);
    $stmt->bindParam(':complaint_id', $complaint_id, PDO::PARAM_INT);
    $stmt->bindParam(':faculty_id', $faculty_id, PDO::PARAM_INT);
    $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);
    $stmt->execute();

    // Commit transaction
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Complaint rejected successfully']);
} catch (Exception $e) {
    // Rollback transaction in case of error
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Failed to reject complaint: ' . $e->getMessage()]);
}
?>