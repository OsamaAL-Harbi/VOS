<?php
// Start the session
session_start();

// Database connection
$host = 'localhost';
$dbname = 'faculty';
$username = 'root';
$password = 'Root';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$complaint_id = intval($data['complaint_id']);
$action = $data['action']; // 'in_progress' or 'reject'
$comment = trim($data['comment']);
$faculty_id = $_SESSION['faculty_id'];

if (!$complaint_id || !$action || !$comment) {
    die(json_encode(['success' => false, 'message' => 'Invalid request data']));
}

try {
    // Begin transaction
    $pdo->beginTransaction();
    
    if ($action === 'in_progress') {
        // Update complaint status to 'In_progress'
        $stmt1 = $pdo->prepare("
            UPDATE complaints 
            SET status = 'In_progress', updated_at = NOW()
            WHERE complaint_id = :complaint_id AND active_complaints = 1
        ");
        $action_type = 'Forwarded'; // Assuming "In Progress" maps to "Forwarded"
    } elseif ($action === 'reject') {
        // Update complaint status to 'Rejected'
        $stmt1 = $pdo->prepare("
            UPDATE complaints 
            SET status = 'Rejected', active_complaints = 0, updated_at = NOW()
            WHERE complaint_id = :complaint_id AND active_complaints = 1
        ");
        $action_type = 'Rejected';
    } else {
        throw new Exception('Invalid action type');
    }
    
    $stmt1->execute([':complaint_id' => $complaint_id]);
    
    // Check if update was successful
    if ($stmt1->rowCount() === 0) {
        throw new Exception('Failed to update complaint status or invalid complaint ID');
    }
    
    // Insert into complaint_actions
    $stmt2 = $pdo->prepare("
        INSERT INTO complaint_actions (
            complaint_id, action_type, action_by, action_date, AA_comment
        ) VALUES (
            :complaint_id, :action_type, :action_by, NOW(), :comment
        )
    ");
    $stmt2->execute([
        ':complaint_id' => $complaint_id,
        ':action_type' => $action_type,
        ':action_by' => $faculty_id,
        ':comment' => $comment
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Complaint status updated successfully'
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>