<?php
// Start the session
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in, otherwise redirect to the login page
if (!isset($_SESSION['loggedin'])) {
    header('Location: ../index.html'); // Redirect to login page
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty'; // Replace with your database name
$username = 'root';  // Replace with your database username
$password = 'Root';  // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
}

// Handle POST request for forwarding complaints
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = isset($data['complaint_id']) ? intval($data['complaint_id']) : null;
    $comment = isset($data['comment']) ? trim($data['comment']) : null;
    $faculty_id = $_SESSION['faculty_id']; // Logged-in faculty member (academic advisor)

    // Validate input data
    if (!$complaint_id || !$comment) {
        die(json_encode(['success' => false, 'message' => 'Invalid request data']));
    }

    try {
        // Begin transaction
        $pdo->beginTransaction();

        // Fetch the course name and department for the complaint
        $stmt_course = $pdo->prepare("
            SELECT course_name, complaint_department 
            FROM complaints 
            WHERE complaint_id = :complaint_id
        ");
        $stmt_course->execute([':complaint_id' => $complaint_id]);
        $course = $stmt_course->fetch(PDO::FETCH_ASSOC);

        if (!$course) {
            throw new Exception('Course not found for the complaint.');
        }

        $course_name = $course['course_name'];
        $department = $course['complaint_department'];

        // Debugging: Print the course name and department
        error_log("Course Name: $course_name, Department: $department");

        // Fetch the HOD of the course's department
        $stmt_hod = $pdo->prepare("
            SELECT faculty_id 
            FROM faculty_members 
            WHERE role = 'head_of_department' AND department_id = (
                SELECT department_id 
                FROM departments 
                WHERE department_name = :department
            )
        ");
        $stmt_hod->execute([':department' => $department]);
        $hod = $stmt_hod->fetch(PDO::FETCH_ASSOC);

        if (!$hod) {
            throw new Exception('Head of Department (HOD) not found for the department: ' . $department);
        }

        $hod_id = $hod['faculty_id'];

        // Debugging: Print the HOD ID
        error_log("HOD ID: $hod_id");

        // Update complaint status and recipient to HOD
        $stmt_update = $pdo->prepare("
            UPDATE complaints 
            SET status = 'In_progress', recipient = :hod_id, updated_at = NOW()
            WHERE complaint_id = :complaint_id AND active_complaints = 1
        ");
        $stmt_update->execute([
            ':hod_id' => $hod_id,
            ':complaint_id' => $complaint_id
        ]);

        // Check if the update was successful
        if ($stmt_update->rowCount() === 0) {
            throw new Exception('Failed to update complaint status or invalid complaint ID');
        }

        // Insert into complaint_actions
        $stmt_action = $pdo->prepare("
            INSERT INTO complaint_actions (
                complaint_id, action_type, action_by, action_date, AA_comment
            ) VALUES (
                :complaint_id, :action_type, :action_by, NOW(), :comment
            )
        ");
        $stmt_action->execute([
            ':complaint_id' => $complaint_id,
            ':action_type' => 'Forwarded',
            ':action_by' => $faculty_id,
            ':comment' => $comment
        ]);

        // Commit transaction
        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Complaint forwarded to HOD successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        error_log("Error: " . $e->getMessage()); // Log the error for debugging
        echo json_encode([
            'success' => false,
            'message' => 'An error occurred. Please try again.',
            'error' => $e->getMessage() // Include the actual error message
        ]);
    }
    exit;
}

// If the request method is not POST, return an error
echo json_encode([
    'success' => false,
    'message' => 'Invalid request method'
]);
?>