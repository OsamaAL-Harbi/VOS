<?php
// Start the session
session_start();
// Check if the user is logged in, otherwise redirect to the login page
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="faculty_member.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="logo.png" class="logo">
                <img src="logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="faculty_profile.php"><i class="fas fa-user-circle"></i>Profile</a>
            <a href="track.php"><i class="fas fa-file-alt"></i>track</a>
            <a href="Academic_Advisor/academic_advisor.php\"><i class="fas fa-file-alt"></i>All Complaints</a>
            <a href="../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i>Logout</a>
        </div>
    </nav>
    <div class="content">
        <h2>Welcome, Academic Advisor Dashboard</h2>
        <p>Hello, <?=htmlspecialchars($_SESSION['name'], ENT_QUOTES)?></p>
        
   <!-- Card with download button for the guide -->
   <div class="card">
        <h3>Download Guidelines</h3>
        <p>Click the button below to view or download the student guide in PDF format:</p>
        <button id="viewPdfButton" class="download-button">
            <i class="fas fa-eye"></i> View PDF Guide
        </button>
    </div>

    <!-- Modal for displaying the PDF -->
    <div id="pdfModal" class="modal">
        <button id="closeModalButton" class="close-modal">Close</button>
        <div class="modal-content">
            <iframe src="../Guidelines.pdf"></iframe>
        </div>
    </div>

    <!-- Overlay for the modal -->
    <div id="overlay" class="overlay"></div>
    </div>
</body>
<script>
    // Function to parse query parameters from the URL
    function getQueryParams() {
        const params = {};
        window.location.search
            .substring(1)
            .split('&')
            .forEach(pair => {
                const [key, value] = pair.split('=');
                params[decodeURIComponent(key)] = decodeURIComponent(value);
            });
        return params;
    }

    // On page load, check for the 'change_password' parameter
    window.onload = function () {
        const queryParams = getQueryParams();

        if (queryParams.change_password === 'true') {
            alert('Please change your password from your profile.');
        }
    };

            // Get references to elements
            const viewPdfButton = document.getElementById('viewPdfButton');
        const pdfModal = document.getElementById('pdfModal');
        const closeModalButton = document.getElementById('closeModalButton');
        const overlay = document.getElementById('overlay');

        // Function to open the modal
        function openModal() {
            pdfModal.style.display = 'block';
            overlay.style.display = 'block';
        }

        // Function to close the modal
        function closeModal() {
            pdfModal.style.display = 'none';
            overlay.style.display = 'none';
        }

        // Event listeners
        viewPdfButton.addEventListener('click', openModal);
        closeModalButton.addEventListener('click', closeModal);
        overlay.addEventListener('click', closeModal);
</script>
</body>
</html>
