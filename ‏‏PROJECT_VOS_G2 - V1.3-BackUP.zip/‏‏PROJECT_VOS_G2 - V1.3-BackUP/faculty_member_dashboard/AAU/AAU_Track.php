<?php

// Start the session
session_start();


// Database connection
$host = 'localhost';
$dbname = 'faculty'; // Replace with your database name
$username = 'root';  // Replace with your database username
$password = 'Root';  // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = intval($data['complaint_id'] ?? 0);
    $action = $data['action'] ?? ''; // 'forward' or 'reject'
    $comment = trim($data['comment'] ?? '');
    $faculty_id = $_SESSION['faculty_id'] ?? null;

    // Validate input data
    if (!$complaint_id || !in_array($action, ['forward', 'reject']) || empty($comment) || !$faculty_id) {
        http_response_code(400); // Bad Request
        die(json_encode(['success' => false, 'message' => 'Invalid request data']));
    }

    try {
        // Begin transaction
        $pdo->beginTransaction();

// In your POST handler section, replace the forwarding logic with this:
    if ($action === 'forward') {
        // Fetch the AAU ID
        $stmt_fetch_mrc = $pdo->prepare("
            SELECT faculty_id 
            FROM faculty_members 
            WHERE role = 'head_of_Academic_Unit'
        ");
        $stmt_fetch_mrc->execute();
        $AAU_id = $stmt_fetch_mrc->fetchColumn();
    
        if (!$AAU_id) {
            throw new Exception('Head of Academic Unit not found');
        }
    
        // Update complaint status to 'Resolved' and assign to AAU
        $stmt1 = $pdo->prepare("
            UPDATE complaints 
            SET status = 'Resolved', 
                recipient = :AAU_id, 
                updated_at = NOW()
            WHERE complaint_id = :complaint_id 
            AND active_complaints = 1
        ");
        $stmt1->execute([
            ':complaint_id' => $complaint_id,
            ':AAU_id' => $AAU_id
        ]);
    
        $action_type = 'Resolved';
    

        } elseif ($action === 'reject') {
            // Update complaint status to 'Rejected'
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'Rejected', active_complaints = 0, updated_at = NOW()
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([':complaint_id' => $complaint_id]);

            $action_type = 'Rejected';
        }

        // Check if update was successful
        if ($stmt1->rowCount() === 0) {
            throw new Exception('Failed to update complaint status or invalid complaint ID');
        }

    // Update action record in complaint_actions
    $stmt2 = $pdo->prepare("
        UPDATE complaint_actions
        SET 
            action_type = :action_type,
            action_by = :action_by,
            action_date = NOW(),
            AAU_comment = :AAU_comment,
            action_by_AAU = :action_by_AAU,
            is_readed = 0
        WHERE complaint_id = :complaint_id
    ");
    $stmt2->execute([
        ':complaint_id' => $complaint_id,
        ':action_type' => $action_type,
        ':action_by' => $faculty_id,
        ':action_by_AAU' => $faculty_id,
        ':AAU_comment' => $comment
    ]);

        // Commit transaction
        $pdo->commit();
        echo json_encode([
            'success' => true,
            'message' => 'Complaint status updated successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        http_response_code(500); // Internal Server Error
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Fetch complaints for students assigned to the logged-in academic advisor
$faculty_id = $_SESSION['faculty_id'] ?? null; // Assume the faculty ID is stored in the session


$query = "
    SELECT 
        c.complaint_id,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.created_at,
        c.updated_at,
        c.active_complaints,
        s.student_id,
        s.first_name AS first_name,
        s.last_name AS last_name,
        f.first_name AS advisor_first_name,
        f.last_name AS advisor_last_name
    FROM complaints c
    JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
    WHERE c.recipient = :faculty_id
    AND c.status = 'In_progress'
    AND c.active_complaints = 1
    AND c.complaint_type IN ('late_announcement', 'Assignments/Quizzes/Labs(Excuses)')
    ORDER BY c.created_at DESC
";

try {
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':faculty_id', $faculty_id, PDO::PARAM_INT);
    $stmt->execute();
    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
}
?>


<!-- Start HTML Section -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="../../faculty_member_dashboard/CSS/track_FM.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        /* Simple styling for alerts */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            z-index: 1000;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Styling for the modal */
        .modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            font-family: Arial, sans-serif;
            text-align: center;
            max-height: 80vh;
            overflow-y: auto;
        }

        .backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* Styling for buttons */
        .action-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .action-btn:hover {
            background-color: #0056b3;
        }

        /* Styling for complaint table */
        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .complaints-table th, .complaints-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .complaints-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="/logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="AAU_Home.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="AAU_Profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    <div id="alert-container"></div>
    <div class="content">
        <h2>AAU Dashboard - Track Complaints</h2>
        <p>Hello, <?= htmlspecialchars($_SESSION['name'] ?? 'Guest', ENT_QUOTES) ?></p>
        <!-- Display Complaints -->
        <?php if (!empty($complaints)): ?>
            <table class="complaints-table">
                <thead>
                    <tr>
                        <th>Complaint ID</th>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Complaint Type</th>
                        <th>Course Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Date Submitted</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($complaints as $complaint): ?>
                        <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                            <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['first_name'] . ' ' . $complaint['last_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['created_at'], ENT_QUOTES) ?></td>
                            <td><?= $complaint['active_complaints'] ? 'Yes' : 'No' ?></td>
                            <td>
                                <button class="action-btn" onclick="handleComplaint(<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>)">
                                    Action
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No complaints found.</p>
        <?php endif; ?>
    </div>
    <script src="AAU_Track.js"></script>

</body>
</html>