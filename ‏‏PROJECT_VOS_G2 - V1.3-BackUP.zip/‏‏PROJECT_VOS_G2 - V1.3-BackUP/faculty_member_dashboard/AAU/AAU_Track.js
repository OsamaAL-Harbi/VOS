


// Function to handle complaint actions
function handleComplaint(complaintId) {
    const modal = createModal(complaintId);
    const backdrop = createBackdrop(modal);
    document.body.append(backdrop, modal);
}

// Helper function to create the modal
function createModal(complaintId) {
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
        <h3>Complaint ID: ${complaintId}</h3>
        <button id="forwardBtn">Resolving</button>
        <button id="rejectBtn">Reject</button>
    `;
    modal.querySelector('#forwardBtn').onclick = () => showModalForm(modal, complaintId, 'forward', 'Add Comment for Resolving', 'Submit Forward');
    modal.querySelector('#rejectBtn').onclick = () => showModalForm(modal, complaintId, 'reject', 'Add Reason for Rejection', 'Submit Rejection');
    return modal;
}

// Helper function to create the backdrop
function createBackdrop(modal) {
    const backdrop = document.createElement('div');
    backdrop.classList.add('backdrop');
    backdrop.onclick = () => {
        modal.remove();
        backdrop.remove();
    };
    return backdrop;
}

// Helper function to show the form in the modal
function showModalForm(modal, complaintId, action, heading, buttonText) {
    // Remove any existing form before adding a new one
    const existingForm = modal.querySelector('.modal-form');
    if (existingForm) existingForm.remove();
    const form = document.createElement('div');
    form.classList.add('modal-form');
    form.innerHTML = `
        <h4>${heading}</h4>
        <textarea id="commentBox" rows="4" cols="50"></textarea>
        <button id="submitBtn">${buttonText}</button>
    `;
    modal.appendChild(form);
    form.querySelector('#submitBtn').onclick = () => {
        const comment = form.querySelector('#commentBox').value.trim();
        if (!comment) {
            showAlert('Comment is required.', 'error');
            return;
        }
        sendRequest('../../faculty_member_dashboard/AAU/AAU_Track.php', { complaint_id: complaintId, action, comment });
    };
}

// Update the sendRequest function to properly handle the modal:
function sendRequest(url, data) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            // Find and remove any existing modals/backdrops
            const existingModal = document.querySelector('.modal');
            const existingBackdrop = document.querySelector('.backdrop');
            if (existingModal) existingModal.remove();
            if (existingBackdrop) existingBackdrop.remove();
            
            if (xhr.status === 200) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        showAlert(response.message, 'success');
                        // Remove the complaint row from the UI
                        const row = document.querySelector(`tr[data-complaint-id="${data.complaint_id}"]`);
                        if (row) row.remove();
                        // Optional: Refresh the page after 2 seconds
                        setTimeout(() => {
                            window.location.reload();
                        }, 2000);
                    } else {
                        showAlert(response.message, 'error');
                    }
                } catch (e) {
                    console.error('Invalid response:', xhr.responseText);
                    showAlert('An unexpected error occurred. Please try again.', 'error');
                }
            } else {
                showAlert('An error occurred while processing your request. Please try again.', 'error');
            }
        }
    };
    xhr.onerror = function() {
        showAlert('Network error occurred. Please check your connection.', 'error');
    };
    xhr.send(JSON.stringify(data));
}

// Function to show alerts
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert ${type === 'success' ? 'alert-success' : 'alert-error'}`;
    alertDiv.textContent = message;
    alertContainer.appendChild(alertDiv);
    // Automatically remove the alert after 3 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
}
