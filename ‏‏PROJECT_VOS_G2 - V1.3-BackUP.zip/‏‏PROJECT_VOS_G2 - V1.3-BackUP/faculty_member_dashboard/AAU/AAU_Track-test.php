<?php
// Start PHP section
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Check if the user is logged in, otherwise redirect to the login page
if (!isset($_SESSION['loggedin'])) {
    header('Location: ../index.html'); // Redirect to login page
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty'; // Replace with your database name
$username = 'root';  // Replace with your database username
$password = 'Root';  // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
}

// Fetch complaints and their actions for the HOD's department dashboard
try {
    // Get additional filters from query parameters
    $status_filter = isset($_GET['status']) ? filter_var($_GET['status'], FILTER_SANITIZE_STRING) : 'active';
    $type_filter = isset($_GET['type']) ? filter_var($_GET['type'], FILTER_SANITIZE_STRING) : 'all';

    // Base query to fetch complaints and their actions related to the HOD's department
    $query = "
        SELECT 
            c.complaint_id,
            c.complaint_type,
            c.course_name,
            c.complaint_description,
            c.status,
            c.created_at,
            c.updated_at,
            s.student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            CONCAT(f.first_name, ' ', f.last_name) AS advisor_name,
            s.email AS student_email,
            s.phone AS student_phone,
            d.department_name,
            ca.action_id,
            ca.action_type AS action_taken,
            ca.AA_comment,
            ca.HOD_comment,
            ca.MRC_comment,
            ca.AAU_comment,
            ca.action_date,
            CONCAT(fm.first_name, ' ', fm.last_name) AS action_by_name
        FROM complaints c
        JOIN students s ON c.complainant_id = s.student_id
        LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
        JOIN departments d ON s.department_id = d.department_id
        LEFT JOIN complaint_actions ca ON c.complaint_id = ca.complaint_id
        LEFT JOIN faculty_members fm ON ca.action_by = fm.faculty_id
        WHERE d.department_head_id = :hod_id
    ";

    // Add filters
    $params = [':hod_id' => $_SESSION['faculty_id']];
    if ($status_filter === 'active') {
        $query .= " AND c.active_complaints = 1";
    } elseif ($status_filter === 'resolved') {
        $query .= " AND c.active_complaints = 0 AND c.status = 'Resolved'";
    } elseif ($status_filter === 'rejected') {
        $query .= " AND c.active_complaints = 0 AND c.status = 'Rejected'";
    }

    if ($type_filter !== 'all') {
        $query .= " AND c.complaint_type = :type";
        $params[':type'] = $type_filter;
    }

    // Add sorting
    $sort = isset($_GET['sort']) ? filter_var($_GET['sort'], FILTER_SANITIZE_STRING) : 'created_at';
    $order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
    $query .= " ORDER BY " . ($sort === 'student' ? 's.last_name' : "c.$sort") . " $order";

    // Prepare and execute query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $complaints = $stmt->fetchAll();

    // Format dates and truncate long descriptions
    foreach ($complaints as &$complaint) {
        $complaint['created_at_formatted'] = date('M j, Y g:i a', strtotime($complaint['created_at']));
        $complaint['updated_at_formatted'] = $complaint['updated_at'] ? 
            date('M j, Y g:i a', strtotime($complaint['updated_at'])) : 'N/A';
        $complaint['short_description'] = strlen($complaint['complaint_description']) > 100 ? 
            substr($complaint['complaint_description'], 0, 100) . '...' : $complaint['complaint_description'];
        $complaint['action_date_formatted'] = $complaint['action_date'] ? 
            date('M j, Y g:i a', strtotime($complaint['action_date'])) : 'N/A';
    }

    // Return JSON if AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true, 
            'data' => $complaints,
            'count' => count($complaints)
        ]);
        exit;
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Failed to fetch complaints']);
        exit;
    }
    $complaints = []; // Fallback for HTML rendering
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AAU Dashboard - Voice of Student</title>
    <link href="CSS/AAU_Track.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="loggedin">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="../logo.png" alt="Logo" style="height: 40px;">
                <span class="ms-2">Voice of Student</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="AAU_Home.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="AAU_Profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../../../logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="alert-container" class="fixed-top" style="top: 70px; z-index: 1000;"></div>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3">
                <!-- Filters and Statistics -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-filter"></i> Filters
                    </div>
                    <div class="card-body">
                        <form id="filter-form">
                            <div class="mb-3">
                                <label for="status-filter" class="form-label">Status</label>
                                <select class="form-select" id="status-filter" name="status">
                                    <option value="active" selected>Active</option>
                                    <option value="resolved">Resolved</option>
                                    <option value="rejected">Rejected</option>
                                    <option value="all">All</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="type-filter" class="form-label">Complaint Type</label>
                                <select class="form-select" id="type-filter" name="type">
                                    <option value="all" selected>All Types</option>
                                    <option value="late_announcement">Late Announcement</option>
                                    <option value="Assignments/Quizzes/Labs(Excuses)">Academic Excuses</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="sort-by" class="form-label">Sort By</label>
                                <select class="form-select" id="sort-by" name="sort">
                                    <option value="created_at">Date Created</option>
                                    <option value="updated_at">Last Updated</option>
                                    <option value="student">Student Name</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="sort-order" class="form-label">Order</label>
                                <select class="form-select" id="sort-order" name="order">
                                    <option value="DESC">Newest First</option>
                                    <option value="ASC">Oldest First</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-sync-alt"></i> Apply Filters
                            </button>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-chart-bar"></i> Statistics
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <h6>Active Complaints</h6>
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar" style="width: 75%">15</div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <h6>Resolved This Month</h6>
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 45%">9</div>
                            </div>
                        </div>
                        <div>
                            <h6>Average Resolution Time</h6>
                            <p class="text-muted">3.2 days</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h2 class="h5 mb-0">
                            <i class="fas fa-tasks"></i> Complaints Dashboard
                        </h2>
                        <span class="badge bg-light text-dark">
                            Showing <span id="complaint-count"><?= count($complaints) ?></span> complaints
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Student</th>
                                        <th>Type</th>
                                        <th>Course</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Submitted</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="complaints-table-body">
                                    <?php if (!empty($complaints)): ?>
                                        <?php foreach ($complaints as $complaint): ?>
                                            <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES, 'UTF-8') ?>">
                                                <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES, 'UTF-8') ?></td>
                                                <td>
                                                    <strong><?= htmlspecialchars($complaint['student_name'], ENT_QUOTES, 'UTF-8') ?></strong><br>
                                                    <small class="text-muted">ID: <?= htmlspecialchars($complaint['student_id'], ENT_QUOTES, 'UTF-8') ?></small>
                                                </td>
                                                <td><?= htmlspecialchars($complaint['course_name'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></td>
                                                <td>
                                                    <span class="d-inline-block text-truncate" style="max-width: 200px;" 
                                                        title="<?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES, 'UTF-8') ?>">
                                                        <?= htmlspecialchars($complaint['short_description'], ENT_QUOTES, 'UTF-8') ?>
                                                    </span>
                                                </td>
                                                <td>
                                                        <?= htmlspecialchars($complaint['status'], ENT_QUOTES, 'UTF-8') ?>
                                                    </span>
                                                </td>
                                                <td><?= $complaint['created_at_formatted'] ?></td>
                                                <td>
                                                    <div class="btn-group" role="group">
                                                        <button class="btn btn-sm btn-info view-btn" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#complaintDetailsModal"
                                                            data-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES, 'UTF-8') ?>"
                                                            data-actions="<?= htmlspecialchars(json_encode([
                                                                'action_taken' => $complaint['action_taken'],
                                                                'AA_comment' => $complaint['AA_comment'],
                                                                'HOD_comment' => $complaint['HOD_comment'],
                                                                'MRC_comment' => $complaint['MRC_comment'],
                                                                'AAU_comment' => $complaint['AAU_comment'],
                                                                'action_date' => $complaint['action_date_formatted'],
                                                                'action_by' => $complaint['action_by_name']
                                                            ]), ENT_QUOTES, 'UTF-8') ?>">
                                                            <i class="fas fa-eye"></i>
                                                        </button>
                                                        <?php if ($complaint['active_complaints'] == 1): ?>
                                                            <button class="btn btn-sm btn-success forward-btn" 
                                                                data-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES, 'UTF-8') ?>">
                                                                <i class="fas fa-share"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-danger reject-btn" 
                                                                data-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES, 'UTF-8') ?>">
                                                                <i class="fas fa-times"></i>
                                                            </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="8" class="text-center py-4">
                                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                                <h5>No complaints found</h5>
                                                <p class="text-muted">There are currently no complaints matching your filters</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <nav aria-label="Complaints pagination">
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" tabindex="-1">Previous</a>
                                </li>
                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#">Next</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Complaint Details Modal -->
    <div class="modal fade" id="complaintDetailsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Complaint Details</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="complaint-details-content">
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Confirmation Modal -->
    <div class="modal fade" id="actionModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="actionModalTitle">Confirm Action</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="action-form">
                        <input type="hidden" id="action-complaint-id" name="complaint_id">
                        <input type="hidden" id="action-type" name="action">
                        <div class="mb-3">
                            <label for="action-comment" class="form-label">Comments</label>
                            <textarea class="form-control" id="action-comment" name="comment" rows="4" required></textarea>
                            <div class="form-text">Please provide details for this action</div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirm-action-btn">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Global variables
        let currentComplaintId = null;
        let currentAction = null;

        // DOM Ready
        document.addEventListener('DOMContentLoaded', function () {
            // Initialize tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Setup event listeners
            setupEventListeners();

            // Apply filters when form is submitted
            document.getElementById('filter-form').addEventListener('submit', function (e) {
                e.preventDefault();
                fetchComplaints();
            });

            // Initialize with default filters
            fetchComplaints();
        });

        // Setup event listeners
        function setupEventListeners() {
            // View complaint details
            document.getElementById('complaints-table-body').addEventListener('click', function (e) {
                if (e.target.closest('.view-btn')) {
                    const btn = e.target.closest('.view-btn');
                    const complaintId = btn.getAttribute('data-id');
                    const encodedActions = btn.getAttribute('data-actions');
                    showComplaintDetails(complaintId, encodedActions);
                }
            });

            // Forward complaint
            document.getElementById('complaints-table-body').addEventListener('click', function (e) {
                if (e.target.closest('.forward-btn')) {
                    const btn = e.target.closest('.forward-btn');
                    const complaintId = btn.getAttribute('data-id');
                    showActionModal(complaintId, 'forward');
                }
            });

            // Reject complaint
            document.getElementById('complaints-table-body').addEventListener('click', function (e) {
                if (e.target.closest('.reject-btn')) {
                    const btn = e.target.closest('.reject-btn');
                    const complaintId = btn.getAttribute('data-id');
                    showActionModal(complaintId, 'reject');
                }
            });

            // Confirm action
            document.getElementById('confirm-action-btn').addEventListener('click', function () {
                processComplaintAction();
            });
        }

        // Fetch complaints with filters
        function fetchComplaints() {
            const form = document.getElementById('filter-form');
            const formData = new FormData(form);
            const params = new URLSearchParams(formData);
            showLoading(true);
            fetch(`track.php?${params.toString()}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        renderComplaintsTable(data.data);
                        document.getElementById('complaint-count').textContent = data.count;
                    } else {
                        showAlert('Failed to fetch complaints: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert('An error occurred while fetching complaints', 'error');
                })
                .finally(() => {
                    showLoading(false);
                });
        }

        // Render complaints table
        function renderComplaintsTable(complaints) {
            const tbody = document.getElementById('complaints-table-body');
            if (complaints.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                            <h5>No complaints found</h5>
                            <p class="text-muted">There are currently no complaints matching your filters</p>
                        </td>
                    </tr>
                `;
                return;
            }
            tbody.innerHTML = complaints.map(complaint => `
                <tr data-complaint-id="${complaint.complaint_id}">
                    <td>${complaint.complaint_id}</td>
                    <td>
                        <strong>${complaint.student_name}</strong><br>
                        <small class="text-muted">ID: ${complaint.student_id}</small>
                    </td>
                    <td>${formatComplaintType(complaint.complaint_type)}</td>
                    <td>${complaint.course_name || 'N/A'}</td>
                    <td>
                        <span class="d-inline-block text-truncate" style="max-width: 200px;" 
                            title="${complaint.complaint_description}">
                            ${complaint.short_description}
                        </span>
                    </td>
                    <td>
                        <span class="badge ${getStatusBadgeClass(complaint.status)}">
                            ${complaint.status}
                        </span>
                    </td>
                    <td>${complaint.created_at_formatted}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button class="btn btn-sm btn-info view-btn" 
                                data-bs-toggle="modal" 
                                data-bs-target="#complaintDetailsModal"
                                data-id="${complaint.complaint_id}"
                                data-actions='${JSON.stringify({
                                    action_taken: complaint.action_taken,
                                    AA_comment: complaint.AA_comment,
                                    HOD_comment: complaint.HOD_comment,
                                    MRC_comment: complaint.MRC_comment,
                                    AAU_comment: complaint.AAU_comment,
                                    action_date: complaint.action_date_formatted,
                                    action_by: complaint.action_by_name
                                })}'>
                                <i class="fas fa-eye"></i>
                            </button>
                            ${complaint.active_complaints == 1 ? `
                                <button class="btn btn-sm btn-success forward-btn" 
                                    data-id="${complaint.complaint_id}">
                                    <i class="fas fa-share"></i>
                                </button>
                                <button class="btn btn-sm btn-danger reject-btn" 
                                    data-id="${complaint.complaint_id}">
                                    <i class="fas fa-times"></i>
                                </button>
                            ` : ''}
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        // Show complaint details modal
        function showComplaintDetails(complaintId, encodedActions) {
            const modal = new bootstrap.Modal(document.getElementById('complaintDetailsModal'));
            const contentDiv = document.getElementById('complaint-details-content');
            const actions = JSON.parse(decodeURIComponent(encodedActions));
            contentDiv.innerHTML = `
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            `;
            modal.show();
            fetch(`get_complaint_details.php?id=${complaintId}`)
                .then(response => response.text())
                .then(html => {
                    contentDiv.innerHTML = html;
                    // Display actions
                    const actionsDiv = document.createElement('div');
                    actionsDiv.innerHTML = `
                        <h6>Actions Taken:</h6>
                        <p><strong>Action:</strong> ${actions.action_taken || 'N/A'}</p>
                        <p><strong>AA Comment:</strong> ${actions.AA_comment || 'N/A'}</p>
                        <p><strong>HOD Comment:</strong> ${actions.HOD_comment || 'N/A'}</p>
                        <p><strong>MRC Comment:</strong> ${actions.MRC_comment || 'N/A'}</p>
                        <p><strong>AAU Comment:</strong> ${actions.AAU_comment || 'N/A'}</p>
                        <p><strong>Action Date:</strong> ${actions.action_date || 'N/A'}</p>
                        <p><strong>Action By:</strong> ${actions.action_by || 'N/A'}</p>
                    `;
                    contentDiv.appendChild(actionsDiv);
                })
                .catch(error => {
                    console.error('Error:', error);
                    contentDiv.innerHTML = `
                        <div class="alert alert-danger">
                            Failed to load complaint details. Please try again.
                        </div>
                    `;
                });
        }

        // Show action confirmation modal
        function showActionModal(complaintId, action) {
            currentComplaintId = complaintId;
            currentAction = action;
            const modal = new bootstrap.Modal(document.getElementById('actionModal'));
            const title = document.getElementById('actionModalTitle');
            const form = document.getElementById('action-form');

            // Reset form
            form.reset();

            // Set modal title based on action
            if (action === 'forward') {
                title.textContent = 'Forward Complaint';
            } else {
                title.textContent = 'Reject Complaint';
            }

            // Set hidden fields
            document.getElementById('action-complaint-id').value = complaintId;
            document.getElementById('action-type').value = action;
            modal.show();
        }

        // Process complaint action
        function processComplaintAction() {
            const form = document.getElementById('action-form');
            const formData = new FormData(form);
            const comment = formData.get('comment');
            if (!comment.trim()) {
                showAlert('Please enter a comment before proceeding', 'error');
                return;
            }
            const action = formData.get('action');
            const complaintId = formData.get('complaint_id');

            // Close the modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('actionModal'));
            modal.hide();

            // Show loading indicator
            showLoading(true);
            fetch('track.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    complaint_id: complaintId,
                    action: action,
                    comment: comment.trim()
                })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        showAlert(data.message, 'success');
                        // Refresh the complaints list
                        fetchComplaints();
                    } else {
                        throw new Error(data.message || 'Action failed');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAlert(error.message || 'An error occurred while processing your request', 'error');
                })
                .finally(() => {
                    showLoading(false);
                });
        }

        // Helper function to format complaint type
        function formatComplaintType(type) {
            const types = {
                'late_announcement': 'Late Announcement',
                'Assignments/Quizzes/Labs(Excuses)': 'Academic Excuses'
            };
            return types[type] || type;
        }

        // Helper function to get status badge class
        function getStatusBadgeClass(status) {
            const classes = {
                'Pending': 'bg-warning',
                'Forwarded': 'bg-info',
                'Resolved': 'bg-success',
                'Rejected': 'bg-danger'
            };
            return classes[status] || 'bg-secondary';
        }

        // Show alert message
        function showAlert(message, type) {
            const alertContainer = document.getElementById('alert-container');
            // Remove existing alerts
            alertContainer.innerHTML = '';
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show mx-3 shadow`;
            alertDiv.setAttribute('role', 'alert');
            alertDiv.innerHTML = `
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;
            alertContainer.appendChild(alertDiv);
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(alertDiv);
                bsAlert.close();
            }, 5000);
        }

        // Show loading state
        function showLoading(show) {
            const loader = document.getElementById('loading-indicator');
            if (loader) {
                loader.style.display = show ? 'block' : 'none';
            }
        }
    </script>
</body>
</html>