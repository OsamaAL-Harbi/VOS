<?php
// Start the session
session_start();

// Check if the user is logged in, otherwise redirect to the login page
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: ../index.html'); // Redirect to login page
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty'; // Replace with your database name
$username = 'root';  // Replace with your database username
$password = 'Root';  // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = intval($data['complaint_id'] ?? 0); // Use null coalescing to avoid undefined index warnings
    $action = $data['action'] ?? ''; // 'forward' or 'reject'
    $comment = trim($data['comment'] ?? '');
    $faculty_id = $_SESSION['faculty_id'] ?? null;

    // Validate input data
    if (!$complaint_id || !in_array($action, ['forward', 'reject']) || empty($comment) || !$faculty_id) {
        die(json_encode(['success' => false, 'message' => 'Invalid request data']));
    }

    try {
        // Begin transaction
        $pdo->beginTransaction();

        if ($action === 'forward') {
            // Fetch the complaint type and department ID
            $stmt_fetch_complaint = $pdo->prepare("
                SELECT c.complaint_type, s.department_id 
                FROM complaints c
                INNER JOIN students s ON c.complainant_id = s.student_id
                WHERE c.complaint_id = :complaint_id AND c.active_complaints = 1
            ");
            $stmt_fetch_complaint->execute([':complaint_id' => $complaint_id]);
            $complaint_data = $stmt_fetch_complaint->fetch(PDO::FETCH_ASSOC);

            if (!$complaint_data) {
                throw new Exception('Complaint not found or invalid complaint ID');
            }

            $complaint_type = $complaint_data['complaint_type'];
            $department_id = $complaint_data['department_id'];

            // Determine the recipient based on the complaint type
            if (in_array($complaint_type, ['late_announcement', 'Assignments/Quizzes/Labs(Excuses)'])) {
                // Assign to Head of Academic Unit
                $stmt_fetch_head_of_academic_unit = $pdo->prepare("
                    SELECT faculty_id 
                    FROM faculty_members 
                    WHERE role = 'head_of_Academic_Unit'
                ");
                $stmt_fetch_head_of_academic_unit->execute(); // No parameters needed
                $recipient_id = $stmt_fetch_head_of_academic_unit->fetchColumn();
                if (!$recipient_id) {
                    throw new Exception('Head of Academic Unit not found');
                }
            } else {
                // Assign to HOD (default behavior)
                $stmt_fetch_hod = $pdo->prepare("
                    SELECT department_head_id 
                    FROM departments 
                    WHERE department_id = :department_id
                ");
                $stmt_fetch_hod->execute([':department_id' => $department_id]); // Bind :department_id
                $recipient_id = $stmt_fetch_hod->fetchColumn();
                if (!$recipient_id) {
                    throw new Exception('HOD not found for the department');
                }
            }

            // Update complaint status to 'In_progress' and assign to the appropriate recipient
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'In_progress', recipient = :recipient_id, updated_at = NOW()
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([
                ':complaint_id' => $complaint_id,
                ':recipient_id' => $recipient_id
            ]);
            $action_type = 'Forwarded';
        } elseif ($action === 'reject') {
            // Update complaint status to 'Rejected'
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'Rejected', active_complaints = 0, updated_at = NOW(), recipient = NULL
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([':complaint_id' => $complaint_id]);
            $action_type = 'Rejected';
        }

        // Check if update was successful
        if ($stmt1->rowCount() === 0) {
            throw new Exception('Failed to update complaint status or invalid complaint ID');
        }

        // Insert into complaint_actions
        $stmt2 = $pdo->prepare("
            INSERT INTO complaint_actions (
                complaint_id, action_type, action_by, action_date, AA_comment, action_by_AA, action_by_HOD, is_readed
            ) VALUES (
                :complaint_id, :action_type, :action_by, NOW(), :AA_comment, :action_by_AA, :action_by_HOD, 0
            )
        ");
        $stmt2->execute([
            ':complaint_id' => $complaint_id,
            ':action_type' => $action_type,
            ':action_by' => $faculty_id,
            ':AA_comment' => $comment,
            ':action_by_AA' => $faculty_id,
            ':action_by_HOD' => null // Explicitly set to NULL
        ]);

        // Commit transaction
        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Complaint submitted  successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Fetch complaints for students assigned to the logged-in academic advisor
$faculty_id = $_SESSION['faculty_id']; // Assume the faculty ID is stored in the session

$query = "
    SELECT 
        c.*, 
        s.student_id, -- Explicitly include the student_id column
        s.first_name AS student_first_name, 
        s.last_name AS student_last_name,
        f.first_name AS advisor_first_name, 
        f.last_name AS advisor_last_name
    FROM complaints c
    INNER JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
    WHERE s.academic_advisor = :faculty_id 
    AND c.status = 'Submited' -- Only fetch complaints with the status 'Submitted'
    AND c.active_complaints = 1 -- Only fetch active complaints
    ORDER BY c.created_at DESC
";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':faculty_id', $faculty_id, PDO::PARAM_INT);
$stmt->execute();
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="../faculty_member_dashboard/CSS/track_FM.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        /* Simple styling for alerts */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            z-index: 1000;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
                <img src="logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="../faculty_member_dashboard/faculty_member.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="faculty_profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    <div id="alert-container"></div>
    <div class="content">
        <h2>Faculty Dashboard - Track Complaints</h2>
        <p>Hello, <?= htmlspecialchars($_SESSION['name'] ?? 'Guest', ENT_QUOTES) ?></p>
        <!-- Display Complaints -->
        <?php if (!empty($complaints)): ?>
            <table class="complaints-table">
                <thead>
                    <tr>
                        <th>Complaint ID</th>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Complaint Type</th>
                        <th>Course Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Date Submitted</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($complaints as $complaint): ?>
                        <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                            <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['created_at'], ENT_QUOTES) ?></td>
                            <td><?= $complaint['active_complaints'] ? 'Yes' : 'No' ?></td>
                            <td>
                                <button class="action-btn" onclick="handleComplaint(<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>)">
                                    Action
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No complaints found.</p>
        <?php endif; ?>
    </div>
    <script>
// Function to handle complaint actions with enhanced error handling
function handleComplaint(complaintId) {
    try {
        // Create and show modal
        const modal = createModal(complaintId);
        const backdrop = createBackdrop(modal);
        document.body.append(backdrop, modal);
        
        // Focus trap for accessibility
        trapFocus(modal);
    } catch (error) {
        console.error('Error handling complaint:', error);
        showAlert('Failed to open complaint dialog. Please try again.', 'error');
    }
}

// Helper function to create the modal with improved styling and accessibility
function createModal(complaintId) {
    const modal = document.createElement('div');
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-labelledby', 'modalTitle');
    modal.setAttribute('aria-modal', 'true');
    modal.id = 'complaint-modal';
    
    modal.style.cssText = `
        position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
        background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        z-index: 1000; width: min(450px, 90vw); font-family: 'Segoe UI', Arial, sans-serif; 
        text-align: center; max-height: 90vh; overflow-y: auto; border: 1px solid #e0e0e0;
        animation: fadeIn 0.3s ease-out;
    `;
    
    modal.innerHTML = `
        <h3 id="modalTitle" style="margin-top: 0; color: #2c3e50;">Complaint #${complaintId}</h3>
        <div style="display: flex; gap: 15px; justify-content: center; margin: 20px 0;">
            <button id="forwardBtn" class="modal-action-btn" style="background-color: #3498db;">
                <i class="fas fa-share" style="margin-right: 8px;"></i>Forward
            </button>
            <button id="rejectBtn" class="modal-action-btn" style="background-color: #e74c3c;">
                <i class="fas fa-times" style="margin-right: 8px;"></i>Reject
            </button>
        </div>
        <button id="closeModalBtn" aria-label="Close modal" 
            style="position: absolute; top: 10px; right: 10px; background: none; 
            border: none; font-size: 1.2rem; cursor: pointer; color: #7f8c8d;">
            &times;
        </button>
    `;
    
    // Add button event listeners
    modal.querySelector('#forwardBtn').onclick = () => 
        showModalForm(modal, complaintId, 'forward', 'Add Comment for Forwarding', 'Submit Forward');
    
    modal.querySelector('#rejectBtn').onclick = () => 
        showModalForm(modal, complaintId, 'reject', 'Add Reason for Rejection', 'Submit Rejection');
    
    modal.querySelector('#closeModalBtn').onclick = () => 
        document.querySelector('.modal-backdrop')?.click();
    
    return modal;
}

// Helper function to create the backdrop with animation
function createBackdrop(modal) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.5); z-index: 999;
        animation: fadeIn 0.3s ease-out;
    `;
    
    backdrop.onclick = () => {
        modal.style.animation = 'fadeOut 0.3s ease-out';
        backdrop.style.animation = 'fadeOut 0.3s ease-out';
        setTimeout(() => {
            modal.remove();
            backdrop.remove();
        }, 300);
    };
    
    // Close modal on Escape key
    document.addEventListener('keydown', function handleEscape(e) {
        if (e.key === 'Escape') {
            backdrop.click();
            document.removeEventListener('keydown', handleEscape);
        }
    });
    
    return backdrop;
}

// Enhanced modal form with better validation
function showModalForm(modal, complaintId, action, heading, buttonText) {
    // Remove any existing form
    const existingForm = modal.querySelector('.modal-form');
    if (existingForm) existingForm.remove();
    
    const form = document.createElement('div');
    form.className = 'modal-form';
    form.innerHTML = `
        <h4 style="margin-bottom: 15px; color: #2c3e50;">${heading}</h4>
        <textarea id="commentBox" rows="5" style="width: 100%; padding: 12px; 
            border: 1px solid #ddd; border-radius: 6px; resize: vertical; 
            font-family: inherit; margin-bottom: 15px;" 
            placeholder="Please provide details..." required></textarea>
        <div style="display: flex; justify-content: flex-end; gap: 10px;">
            <button id="cancelBtn" style="padding: 8px 16px; background: #95a5a6; 
                color: white; border: none; border-radius: 6px; cursor: pointer;">
                Cancel
            </button>
            <button id="submitBtn" style="padding: 8px 20px; background: ${
                action === 'forward' ? '#3498db' : '#e74c3c'
            }; color: white; border: none; border-radius: 6px; cursor: pointer;">
                ${buttonText}
            </button>
        </div>
    `;
    
    modal.appendChild(form);
    
    // Focus on textarea when form appears
    form.querySelector('#commentBox').focus();
    
    // Cancel button handler
    form.querySelector('#cancelBtn').onclick = () => {
        form.remove();
    };
    
    // Submit button handler
    form.querySelector('#submitBtn').onclick = () => {
        const commentBox = form.querySelector('#commentBox');
        const comment = commentBox.value.trim();
        
        if (!comment) {
            commentBox.style.borderColor = '#e74c3c';
            showAlert('Please enter a comment before submitting.', 'error');
            return;
        }
        
        // Disable button during submission
        const submitBtn = form.querySelector('#submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i> Processing...`;
        
        sendRequest('track.php', { complaint_id: complaintId, action, comment })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = buttonText;
            });
    };
}

// Enhanced AJAX function using Fetch API with timeout
function sendRequest(url, data) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
    
    return fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        signal: controller.signal
    })
    .then(response => {
        clearTimeout(timeoutId);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(response => {
        if (response.success) {
            showAlert(response.message, 'success');
            // Remove the complaint row from the UI
            const row = document.querySelector(`tr[data-complaint-id="${data.complaint_id}"]`);
            if (row) {
                row.style.transition = 'all 0.3s';
                row.style.opacity = '0';
                setTimeout(() => row.remove(), 300);
            }
            // Close modal
            document.querySelector('.modal-backdrop')?.click();
        } else {
            throw new Error(response.message || 'Action failed');
        }
    })
    .catch(error => {
        console.error('Request failed:', error);
        showAlert(
            error.message === 'The user aborted a request.' 
                ? 'Request timed out. Please try again.' 
                : error.message || 'An error occurred. Please try again.',
            'error'
        );
    });
}

// Enhanced alert function with icons and animations
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    const alertDiv = document.createElement('div');
    
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    alertContainer.appendChild(alertDiv);
    
    // Animate in
    setTimeout(() => {
        alertDiv.style.opacity = '1';
        alertDiv.style.transform = 'translateY(0)';
    }, 10);
    
    // Remove after delay
    setTimeout(() => {
        alertDiv.style.opacity = '0';
        alertDiv.style.transform = 'translateY(-20px)';
        setTimeout(() => alertDiv.remove(), 300);
    }, 3000);
}

// Focus trap for accessibility
function trapFocus(modal) {
    const focusableElements = modal.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const firstElement = focusableElements[0];
    const lastElement = focusableElements[focusableElements.length - 1];
    
    if (firstElement) firstElement.focus();
    
    modal.addEventListener('keydown', function(e) {
        if (e.key !== 'Tab') return;
        
        if (e.shiftKey) {
            if (document.activeElement === firstElement) {
                lastElement.focus();
                e.preventDefault();
            }
        } else {
            if (document.activeElement === lastElement) {
                firstElement.focus();
                e.preventDefault();
            }
        }
    });
}

// Add CSS animations to document head
if (!document.querySelector('#modal-animations')) {
    const style = document.createElement('style');
    style.id = 'modal-animations';
    style.textContent = `
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -45%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        @keyframes fadeOut {
            to { opacity: 0; transform: translate(-50%, -45%); }
        }
        .alert {
            opacity: 0;
            transform: translateY(-20px);
            transition: all 0.3s ease;
            padding: 15px 20px;
            margin-bottom: 10px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .alert i {
            font-size: 1.2em;
        }
        .modal-action-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            color: white;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
        }
        .modal-action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
    `;
    document.head.appendChild(style);
}
    </script>
</body>
</html>