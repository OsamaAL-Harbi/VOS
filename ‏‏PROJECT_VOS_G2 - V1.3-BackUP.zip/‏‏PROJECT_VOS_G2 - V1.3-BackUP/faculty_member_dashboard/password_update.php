<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    // If there is an error with the connection, stop the script and display the error.
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit();
}

// Get current password hash from the database
$stmt = $con->prepare('SELECT password FROM faculty_members WHERE faculty_id = ?');
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($currentPassword);
$stmt->fetch();
$stmt->close();

// Check if the form data is submitted
if (isset($_POST['new_password'], $_POST['confirm_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if the new password and confirm password match
    if ($newPassword !== $confirmPassword) {
        echo '<script>';
        echo 'alert("Passwords do not match. Please try again.");';
        echo 'window.location.href = "Password_Update.html";';
        echo '</script>';
        exit();
    }

    // Check if the new password is the same as the current password
    if (password_verify($newPassword, $currentPassword)) {
        echo '<script>';
        echo 'alert("The new password is the same as the current password. Please choose a different one.");';
        echo 'window.location.href = "Password_Update.html";';
        echo '</script>';
        exit();
    }

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update the password in the database
    $stmt = $con->prepare('UPDATE faculty_members SET password = ? WHERE faculty_id = ?');
    $stmt->bind_param('si', $hashedPassword, $_SESSION['id']);
    $stmt->execute();
    $stmt->close();

    // Determine the user's role and redirect accordingly
    if ($_SESSION['role'] === 'HOD') {
        $redirectUrl = 'HOD_Home.php';
    } elseif ($_SESSION['role'] === 'Academic Advisor') {
        $redirectUrl = 'Academic_Advisor_Home.php';
    } elseif ($_SESSION['role'] === 'MRC') {
        $redirectUrl = 'MRC_Home.php';
    } else {
        // Default fallback if role is not recognized
        $redirectUrl = 'index.html';
    }

    // Notify the user of success and redirect
    echo '<script>';
    echo 'alert("Password updated successfully!");';
    echo 'window.location.href = "' . $redirectUrl . '";';
    echo '</script>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Update.css">
    <title>Change Password</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
            font-size: 16px;
        }

        body {
            background-color: #435165;
        }

        h2 {
            text-align: center;
            color: #ffffff;
            font-size: 24px;
            margin-top: 50px;
        }

        form {
            width: 400px;
            background-color: #ffffff;
            box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3);
            margin: 0 auto;
            padding: 30px;
        }

        form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #4a536e;
        }

        form input[type="password"] {
            width: 100%;
            height: 40px;
            border: 1px solid #dee0e4;
            padding: 0 15px;
            margin-bottom: 20px;
            font-size: 16px;
        }

        form button {
            width: 100%;
            padding: 15px;
            background-color: #3274d6;
            border: 0;
            cursor: pointer;
            font-weight: bold;
            color: #ffffff;
            font-size: 16px;
            transition: background-color 0.2s;
        }

        form button:hover {
            background-color: #2868c7;
            transition: background-color 0.2s;
        }

        form input[type="password"]:focus {
            border-color: #3274d6;
            outline: none;
        }

        form .error-message {
            color: red;
            font-size: 14px;
            margin-top: -15px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <h2>Change Password</h2>
    <form action="password_update.php" method="post">
        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required><br><br>

        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required><br><br>

        <button type="submit">Update Password</button>
    </form>
</body>
</html>