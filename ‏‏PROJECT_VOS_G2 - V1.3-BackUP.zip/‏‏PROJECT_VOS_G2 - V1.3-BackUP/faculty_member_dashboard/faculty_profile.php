<?php
session_start();

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit();
}

$stmt = $con->prepare('
    SELECT f.faculty_id, f.first_name, f.last_name, f.email, d.department_name 
    FROM faculty_members f
    JOIN departments d ON f.department_id = d.department_id
    WHERE f.faculty_id = ?
');
$stmt->bind_param('i', $_SESSION['faculty_id']);
$stmt->execute();

$stmt->bind_result($faculty_id, $first_name, $last_name, $email, $department_name);
$stmt->fetch();
$stmt->close();

$_SESSION['name'] = $first_name . ' ' . $last_name;
$_SESSION['email'] = $email;
$_SESSION['faculty_id'] = $faculty_id;
$_SESSION['department_name'] = $department_name;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="faculty_profile.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body class="loggedin">
    <nav class="navtop">        
        <div>
            <a href="logo.png" class="logo">
                <img src="logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="faculty_member.php"> <i class="fas fa-home"></i> Back to Home</a>
            <a href="../../logout/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
        </div>
    </nav>
    <div class="content">
        <div class="card">
            <h2>Profile Page</h2>
            <p>Your account details are below:</p>
            <table>
                <tr>
                    <td>Faculty ID:</td>
                    <td><?= htmlspecialchars($_SESSION['faculty_id'], ENT_QUOTES) ?></td> 
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><?= htmlspecialchars($_SESSION['name'], ENT_QUOTES) ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?= htmlspecialchars($_SESSION['email'], ENT_QUOTES) ?></td>
                </tr>
                <tr>
                    <td>Department:</td>
                    <td><?= htmlspecialchars($_SESSION['department_name'], ENT_QUOTES) ?></td>
                </tr>
                <tr>
                    <td>Edit Password:</td>
                    <td>
                        <a href="password_update.php">
                            <input type="button" value="Update">
                        </a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>