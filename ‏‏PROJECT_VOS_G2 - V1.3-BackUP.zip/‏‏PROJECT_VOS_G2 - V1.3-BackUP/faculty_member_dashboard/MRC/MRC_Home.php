<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    // If there is an error with the connection, stop the script and display the error.
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== TRUE) {
    header('Location: ../index.html');
    exit();
}

// Fetch user details from the database
$stmt = $con->prepare('SELECT faculty_id, first_name, last_name, email FROM faculty_members WHERE faculty_id = ?');
$stmt->bind_param('i', $_SESSION['faculty_id']);
$stmt->execute();
$stmt->bind_result($faculty_id, $first_name, $last_name, $email);
$stmt->fetch();
$stmt->close();

// Update session variables
$_SESSION['name'] = $first_name . ' ' . $last_name; // Full name
$_SESSION['email'] = $email;
$_SESSION['faculty_id'] = $faculty_id;

// Fetch complaint statistics
$query = "
    SELECT 
        COUNT(*) AS total_complaints,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending_complaints,
        SUM(CASE WHEN status = 'Forwarded' THEN 1 ELSE 0 END) AS forwarded_complaints,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_complaints
    FROM complaints
";
$result = $con->query($query);
$stats = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOD Dashboard - Voice of Student</title>
    <link href="MRC_Home.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <!-- Logo added here -->
            <a href="../logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="MRC_profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="MRC_track.php"><i class="fas fa-file-alt"></i>track</a>
            <a href="MRC_report.php" rel="noopener noreferrer" title="View Report" aria-label="View Report">    <i class="fas fa-chart-bar"></i> Report
            <a href="/PROJECT_VOS_G2/logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>

    <div class="content">
        <h2>Welcome, <?= htmlspecialchars($_SESSION['name'], ENT_QUOTES) ?></h2>
        <p>Hello, <?=htmlspecialchars($_SESSION['name'], ENT_QUOTES)?></p>
                <!-- Card with download button for the guide -->
                <div class="card">
            <h3>Download Guide</h3>
            <p>Click the button below to download the student guide in PDF format:</p>
            <a href="path/to/your/guide.pdf" download class="download-button">
                <i class="fas fa-download"></i> Download PDF Guide
            </a>
        </div>

    </div>
</body>
</html>