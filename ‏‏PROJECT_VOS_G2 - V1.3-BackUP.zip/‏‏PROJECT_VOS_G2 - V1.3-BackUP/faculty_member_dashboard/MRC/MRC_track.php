<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Redirect if the user is not logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: ../index.html');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty';
$username = 'root';
$password = 'Root';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = intval($data['complaint_id'] ?? 0);
    $action = $data['action'] ?? ''; // 'Resolved' or 'reject'
    $comment = trim($data['comment'] ?? '');
    $faculty_id = $_SESSION['faculty_id'] ?? null;

    // Validate input data
    if (!$complaint_id || !in_array($action, ['Resolved', 'reject']) || empty($comment) || !$faculty_id) {
        die(json_encode(['success' => false, 'message' => 'Invalid request data']));
    }

    try {
        $pdo->beginTransaction();

        if ($action === 'Resolved') {
            // Fetch the Head of Review Committee ID
            $stmt_fetch_mrc = $pdo->prepare("SELECT faculty_id FROM faculty_members WHERE role = 'head of review_committee'");
            $stmt_fetch_mrc->execute();
            $mrc_id = $stmt_fetch_mrc->fetchColumn();
        
            if (!$mrc_id) {
                throw new Exception('Head of Review Committee not found');
            }
        
            // Update complaint status to 'Resolved', assign to MRC, and mark as inactive
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'Resolved', recipient = :mrc_id, active_complaints = 0, updated_at = NOW()
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([
                ':complaint_id' => $complaint_id,
                ':mrc_id' => $mrc_id
            ]);
        
            $action_type = 'Resolved';
        }

        // Check if update was successful
        if ($stmt1->rowCount() === 0) {
            throw new Exception('Failed to update complaint status or invalid complaint ID');
        }

        // Update action record in complaint_actions
        $stmt2 = $pdo->prepare("
        UPDATE complaint_actions
        SET 
            action_type = :action_type,
            action_by = :action_by,
            action_date = NOW(),
            MRC_comment = :MRC_comment,
            action_by_MRC = :action_by_MRC,
            is_readed = 0
        WHERE complaint_id = :complaint_id
    ");
    $stmt2->execute([
        ':complaint_id' => $complaint_id,
        ':action_type' => $action_type,
        ':action_by' => $faculty_id,
        ':MRC_comment' => $comment,
        ':action_by_MRC' => $faculty_id
    ]);

        // Commit transaction
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Complaint status updated successfully']);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        die(json_encode(['success' => false, 'message' => $e->getMessage()]));
    }
    exit;
}

// Fetch complaints for the logged-in faculty member
$faculty_id = $_SESSION['faculty_id'] ?? null;

if (!$faculty_id) {
    die(json_encode(['success' => false, 'message' => 'User session expired or invalid faculty ID']));
}

$query = "
    SELECT 
        c.complaint_id,
        c.complainant_id,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.created_at,
        c.active_complaints,
        s.student_id,
        s.first_name AS student_first_name,
        s.last_name AS student_last_name,
        f.first_name AS faculty_first_name,
        f.last_name AS faculty_last_name
    FROM complaints c
    INNER JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN faculty_members f ON c.recipient = f.faculty_id
    WHERE c.recipient = :faculty_id
      AND c.status = 'Under_review'
      AND c.active_complaints = 1
    ORDER BY c.created_at DESC
";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute([':faculty_id' => $faculty_id]);
    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voice of Student</title>
    <link href="MRC_track.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
</head>
<body class="loggedin">
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="../logo.png" alt="Logo">
            <h1>Voice of Student</h1>
        </div>
        <nav class="nav">
            <a href="MRC_Home.php"><i class="fas fa-home"></i> Home</a>
            <a href="MRC_profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>
    </header>
    <!-- Main Content -->
    <main class="main-content">
        <div class="content-header">
            <h2>Faculty Dashboard - Track Complaints</h2>
            <p>Hello, <?= htmlspecialchars($_SESSION['name'] ?? 'Guest', ENT_QUOTES) ?></p>
        </div>
        <div class="complaints-container">
            <!-- Display Complaints -->
            <?php if (!empty($complaints)): ?>
                <table class="complaints-table">
                    <thead>
                        <tr>
                            <th>Complaint ID</th>
                            <th>Student Name</th>
                            <th>Student ID</th>
                            <th>Complaint Type</th>
                            <th>Course Name</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Date Submitted</th>
                            <th>Active</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($complaints as $complaint): ?>
                            <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['created_at'], ENT_QUOTES) ?></td>
                                <td><?= $complaint['active_complaints'] ? 'Yes' : 'No' ?></td>
                                <td>
                                    <button class="action-btn" onclick="handleComplaint(<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>)">
                                        Submit
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No complaints found.</p>
            <?php endif; ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 Voice of Student. All rights reserved.</p>
    </footer>

    <!-- Alert Container -->
    <div id="alert-container"></div>

    <!-- Scripts -->
    <script>
// Function to handle complaint actions
function handleComplaint(complaintId) {
    // Create and display the modal
    const modal = createModal(complaintId);
    document.body.appendChild(modal);
}

// Function to create the modal
function createModal(complaintId) {
    const modal = document.createElement('div');
    modal.classList.add('modal');
    modal.innerHTML = `
        <div class="modal-content">
            <h3>Complaint ID: ${complaintId}</h3>
            <textarea id="commentBox" rows="4" cols="50" placeholder="Enter your comment"></textarea>
            <div class="modal-buttons">
                <button id="submitBtn">Submit</button>
                <button id="cancelBtn">Cancel</button>
            </div>
        </div>
    `;

    // Handle submit button click
    modal.querySelector('#submitBtn').addEventListener('click', () => {
        const comment = modal.querySelector('#commentBox').value.trim();
        if (!comment) {
            showAlert('Comment is required.', 'error');
            return;
        }

        // Prepare the data to be sent
        const data = {
            complaint_id: complaintId,
            action: 'Resolved', // Default action
            comment: comment
        };

        console.log("Sending data:", data); // Debugging: Log the data being sent

        // Send the request to the server
        sendRequest('../../faculty_member_dashboard/MRC/MRC_track.php', data);

        // Close the modal
        modal.remove();
    });

    // Handle cancel button click
    modal.querySelector('#cancelBtn').addEventListener('click', () => {
        modal.remove();
    });

    return modal;
}

// Function to send a request to the server
function sendRequest(url, data) {
    fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(response => {
        console.log("Response:", response); // Debugging: Log the response
        if (response.success) {
            showAlert(response.message, 'success');
            removeComplaintRow(data.complaint_id);
        } else {
            showAlert(response.message, 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error); // Debugging: Log any errors
        showAlert('An unexpected error occurred. Please try again.', 'error');
    });
}

// Function to remove the complaint row from the UI
function removeComplaintRow(complaintId) {
    const row = document.querySelector(`tr[data-complaint-id="${complaintId}"]`);
    if (row) row.remove();
}

// Function to show alerts
function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert ${type === 'success' ? 'alert-success' : 'alert-error'}`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.textContent = message;
    alertContainer.appendChild(alertDiv);

    // Show the alert
    setTimeout(() => alertDiv.classList.add('show'), 10);

    // Automatically remove the alert after 3 seconds
    setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 300); // Wait for transition to complete
    }, 3000);
}
    </script>
</body>
</html>