<?php
session_start();
// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';
// Try and connect to MySQL
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
// Ensure user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== TRUE) {
    header('Location: ../index.html');
    exit();
}
// Check if session variables exist
if (!isset($_SESSION['faculty_id']) || !isset($_SESSION['name'])) {
    exit('Session data missing. Please log in again.');
}
// Get the MRC's faculty ID
$mrc_id = $_SESSION['faculty_id'];
// Default filters
$status_filter = $_GET['status'] ?? '';
$type_filter = $_GET['type'] ?? '';
$start_date = $_GET['start_date'] ?? '';
$end_date = $_GET['end_date'] ?? '';
$department_filter = $_GET['department'] ?? '';
$assigned_to_filter = $_GET['assigned_to'] ?? ''; // 'faculty' or 'hod'

$query = "
    SELECT 
        c.complaint_id,
        c.complainant_id,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.created_at,
        c.complaint_department,
        s.student_id,
        s.first_name AS student_first_name,
        s.last_name AS student_last_name,
        s.email AS student_email,
        f.first_name AS faculty_first_name,
        f.last_name AS faculty_last_name,
        f.email AS faculty_email
    FROM complaints c
    INNER JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN faculty_members f ON c.recipient = f.faculty_id
    WHERE c.recipient = ?
";

// Parameters array
$params = [$mrc_id];
$types = 'i';

// Add filters
if (!empty($status_filter)) {
    $query .= " AND c.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if (!empty($type_filter)) {
    $query .= " AND c.complaint_type = ?";
    $params[] = $type_filter;
    $types .= 's';
}
if (!empty($start_date) && !empty($end_date)) {
    $query .= " AND c.created_at BETWEEN ? AND ?";
    $params[] = $start_date;
    $params[] = $end_date;
    $types .= 'ss';
}
if (!empty($department_filter)) {
    $query .= " AND c.complaint_department = ?";
    $params[] = $department_filter;
    $types .= 's';
}
if (!empty($assigned_to_filter)) {
    if ($assigned_to_filter === 'faculty') {
        $query .= " AND f.faculty_id IS NOT NULL"; // Complaints assigned to faculty members
    } elseif ($assigned_to_filter === 'hod') {
        $query .= " AND f.faculty_id IS NULL"; // Complaints assigned to HOD (unassigned faculty)
    }
}

$query .= " ORDER BY c.created_at DESC";

// Prepare and execute the query
$stmt = $con->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$complaints = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Handle AJAX request for complaint details
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_complaint_details' && isset($_GET['id'])) {
    $complaint_id = (int)$_GET['id'];
    
    // Get complaint details
    $query = "
        SELECT 
            c.*,
            s.first_name AS student_first_name,
            s.last_name AS student_last_name,
            s.email AS student_email,
            f.first_name AS faculty_first_name,
            f.last_name AS faculty_last_name,
            f.email AS faculty_email
        FROM complaints c
        INNER JOIN students s ON c.complainant_id = s.student_id
        LEFT JOIN faculty_members f ON c.recipient = f.faculty_id
        WHERE c.complaint_id = ?
        AND c.recipient = ?
    ";
    $stmt = $con->prepare($query);
    $stmt->bind_param('ii', $complaint_id, $mrc_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $complaint = $result->fetch_assoc();
    $stmt->close();
    
    if (!$complaint) {
        exit('Complaint not found or unauthorized access');
    }
    
    // Display complaint details
    echo '<div class="complaint-details">';
    echo '<p><strong>Complaint ID:</strong> ' . htmlspecialchars($complaint['complaint_id']) . '</p>';
    echo '<p><strong>Student:</strong> ' . htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name']) . '</p>';
    echo '<p><strong>Student Email:</strong> ' . htmlspecialchars($complaint['student_email']) . '</p>';
    echo '<p><strong>Type:</strong> ' . htmlspecialchars($complaint['complaint_type']) . '</p>';
    echo '<p><strong>Course Name:</strong> ' . htmlspecialchars($complaint['course_name']) . '</p>';
    echo '<p><strong>Description:</strong> ' . nl2br(htmlspecialchars($complaint['complaint_description'])) . '</p>';
    echo '<p><strong>Status:</strong> ' . htmlspecialchars($complaint['status']) . '</p>';
    echo '<p><strong>Date Submitted:</strong> ' . htmlspecialchars($complaint['created_at']) . '</p>';
    
    if (!empty($complaint['faculty_first_name'])) {
        echo '<p><strong>Assigned To:</strong> ' . htmlspecialchars($complaint['faculty_first_name'] . ' ' . $complaint['faculty_last_name']) . '</p>';
        echo '<p><strong>Faculty Email:</strong> ' . htmlspecialchars($complaint['faculty_email']) . '</p>';
    } else {
        echo '<p><strong>Assigned To:</strong> Unassigned</p>';
    }
    
    if (!empty($complaint['resolution_notes'])) {
        echo '<p><strong>Resolution Notes:</strong> ' . nl2br(htmlspecialchars($complaint['resolution_notes'])) . '</p>';
    }
    
    // Get complaint actions
    $actions_query = "
        SELECT 
            ca.*,
            fm_aa.first_name AS aa_first_name, fm_aa.last_name AS aa_last_name,
            fm_hod.first_name AS hod_first_name, fm_hod.last_name AS hod_last_name,
            fm_mrc.first_name AS mrc_first_name, fm_mrc.last_name AS mrc_last_name,
            fm_aau.first_name AS aau_first_name, fm_aau.last_name AS aau_last_name
        FROM complaint_actions ca
        LEFT JOIN faculty_members fm_aa ON ca.action_by_AA = fm_aa.faculty_id
        LEFT JOIN faculty_members fm_hod ON ca.action_by_HOD = fm_hod.faculty_id
        LEFT JOIN faculty_members fm_mrc ON ca.action_by_MRC = fm_mrc.faculty_id
        LEFT JOIN faculty_members fm_aau ON ca.action_by_AAU = fm_aau.faculty_id
        WHERE ca.complaint_id = ?
        ORDER BY ca.action_date DESC
    ";
    
    $actions_stmt = $con->prepare($actions_query);
    $actions_stmt->bind_param('i', $complaint_id);
    $actions_stmt->execute();
    $actions_result = $actions_stmt->get_result();
    $actions = $actions_result->fetch_all(MYSQLI_ASSOC);
    $actions_stmt->close();
    
    if (!empty($actions)) {
        echo '<div class="action-history">';
        echo '<h4>Action History</h4>';
        echo '<div class="action-timeline">';
        
        foreach ($actions as $action) {
            echo '<div class="action-item">';
            echo '<div class="action-header">';
            echo '<span class="action-type">' . htmlspecialchars($action['action_type']) . '</span>';
            echo '<span class="action-date">' . htmlspecialchars($action['action_date']) . '</span>';
            echo '</div>';
            
            // Display action by information
            $action_by = '';
            if (!empty($action['action_by_AA'])) {
                $action_by = 'Academic Advisor: ' . htmlspecialchars($action['aa_first_name'] . ' ' . $action['aa_last_name']);
            } elseif (!empty($action['action_by_HOD'])) {
                $action_by = 'HOD: ' . htmlspecialchars($action['hod_first_name'] . ' ' . $action['hod_last_name']);
            } elseif (!empty($action['action_by_MRC'])) {
                $action_by = 'MRC: ' . htmlspecialchars($action['mrc_first_name'] . ' ' . $action['mrc_last_name']);
            } elseif (!empty($action['action_by_AAU'])) {
                $action_by = 'AAU: ' . htmlspecialchars($action['aau_first_name'] . ' ' . $action['aau_last_name']);
            }
            
            if (!empty($action_by)) {
                echo '<p class="action-by"><strong>Action By:</strong> ' . $action_by . '</p>';
            }
            
            // Display comments
            if (!empty($action['AA_comment'])) {
                echo '<p class="action-comment"><strong>AA Comment:</strong> ' . nl2br(htmlspecialchars($action['AA_comment'])) . '</p>';
            }
            if (!empty($action['HOD_comment'])) {
                echo '<p class="action-comment"><strong>HOD Comment:</strong> ' . nl2br(htmlspecialchars($action['HOD_comment'])) . '</p>';
            }
            if (!empty($action['MRC_comment'])) {
                echo '<p class="action-comment"><strong>MRC Comment:</strong> ' . nl2br(htmlspecialchars($action['MRC_comment'])) . '</p>';
            }
            if (!empty($action['AAU_comment'])) {
                echo '<p class="action-comment"><strong>AAU Comment:</strong> ' . nl2br(htmlspecialchars($action['AAU_comment'])) . '</p>';
            }
            
            echo '</div>'; // .action-item
        }
        
        echo '</div>'; // .action-timeline
        echo '</div>'; // .action-history
    } else {
        echo '<p>No actions recorded for this complaint.</p>';
    }
    
    echo '</div>'; // .complaint-details
    
    // Add a button to view full action history (if needed)
    echo '<button class="btn btn-primary view-full-history" data-id="' . $complaint_id . '">';
    echo '<i class="fas fa-history"></i> View Full Action History';
    echo '</button>';
    
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Report - MRC Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="../logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="../MRC/MRC_Home.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="MRC_track.php"><i class="fas fa-file-alt"></i> Track</a>
            <a href="../../logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    <div class="content">
        <h2>Complaint Report - MRC Dashboard</h2>
        <p>Hello, <?= htmlspecialchars($_SESSION['name'], ENT_QUOTES) ?></p>

        <div class="filter-section">
    <div class="filter-header">
        <h3><i class="fas fa-filter"></i> Filter Complaints</h3>
        <button class="toggle-filters" aria-expanded="true">
            <i class="fas fa-chevron-up"></i>
        </button>
    </div>
    
        <form method="GET" action="" class="filter-form" id="complaintFilters">
            <div class="filter-grid">
                <!-- Type Filter -->
                <div class="filter-group">
                    <label for="type"><i class="fas fa-tag"></i> Complaint Type</label>
                    <select name="type" id="type" class="filter-select">
                        <option value="">All Types</option>
                        <?php
                        // Assuming you have types from database
                        $types = ['final_exam', 'midterm_exam'];
                        foreach ($types as $type) {
                            $selected = ($type_filter === $type) ? 'selected' : '';
                            echo "<option value='$type' $selected>$type</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Date Range Filter -->
                <div class="filter-group">
                    <label><i class="far fa-calendar-alt"></i> Date Range</label>
                    <div class="date-range">
                        <div class="date-input">
                            <label for="start_date">From</label>
                            <input type="date" name="start_date" id="start_date" 
                                value="<?= htmlspecialchars($start_date) ?>" 
                                max="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="date-input">
                            <label for="end_date">To</label>
                            <input type="date" name="end_date" id="end_date" 
                                value="<?= htmlspecialchars($end_date) ?>" 
                                max="<?= date('Y-m-d') ?>">
                        </div>
                    </div>
                </div>

                <!-- Department Filter -->
                <div class="filter-group">
                    <label for="department"><i class="fas fa-building"></i> Department</label>
                    <select name="department" id="department" class="filter-select">
                        <option value="">All Departments</option>
                        <?php
                        // Assuming you have departments from database
                        $departments = ['Information Technology', 'Computer Science', 'Data Science'];
                        foreach ($departments as $dept) {
                            $selected = ($department_filter === $dept) ? 'selected' : '';
                            echo "<option value='$dept' $selected>$dept</option>";
                        }
                        ?>
                    </select>
                </div>

            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Apply Filters
                </button>
                <button type="button" class="btn btn-secondary" onclick="resetFilters()">
                    <i class="fas fa-undo"></i> Reset Filters
                </button>

            </div>
        </form>
    </div>

        <table id="complaintsTable" class="display">
        <thead>
            <tr>
                <th>Complaint ID</th>
                <th>Complainant</th>
                <th>Type</th>
                <th>Course Name</th>
                <th>Description</th>
                <th>Status</th>
                <th>Date Submitted</th>
                <th>Assigned To</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($complaints)): ?>
                <?php foreach ($complaints as $complaint): ?>
                    <tr>
                        <td><?= htmlspecialchars($complaint['complaint_id'] ?? '', ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars(($complaint['student_first_name'] ?? '') . ' ' . ($complaint['student_last_name'] ?? ''), ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars($complaint['complaint_type'] ?? '', ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars($complaint['course_name'] ?? '', ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars(substr($complaint['complaint_description'] ?? '', 0, 50) . (strlen($complaint['complaint_description'] ?? '') > 50 ? '...' : ''), ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars($complaint['status'] ?? '', ENT_QUOTES) ?></td>
                        <td><?= htmlspecialchars($complaint['created_at'] ?? '', ENT_QUOTES) ?></td>
                        <td>
                            <?php if (!empty($complaint['faculty_first_name'])): ?>
                                <?= htmlspecialchars($complaint['faculty_first_name'] . ' ' . $complaint['faculty_last_name'], ENT_QUOTES) ?>
                            <?php else: ?>
                                Unassigned
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="view-details" data-id="<?= $complaint['complaint_id'] ?>">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9">No complaints found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    </div>
    <!-- Modal for complaint details -->
    <div id="complaintModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h3>Complaint Details</h3>
            <div id="complaintDetails"></div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $('#complaintsTable').DataTable({
                paging: true,
                searching: true,
                ordering: true,
                info: true,
                lengthMenu: [5, 10, 25, 50],
                columnDefs: [{ targets: [0, 1, 2, 3, 4, 5, 6, 7, 8], orderable: true }]
            });
            // Modal functionality
            var modal = document.getElementById("complaintModal");
            var span = document.getElementsByClassName("close")[0];
            // When the user clicks on a view details button
            $('.view-details').click(function() {
                var complaintId = $(this).data('id');
                // AJAX request to get complaint details
                $.ajax({
                    url: window.location.href.split('?')[0] + '?ajax=get_complaint_details&id=' + complaintId,
                    type: 'GET',
                    success: function(response) {
                        $('#complaintDetails').html(response);
                        modal.style.display = "block";
                    },
                    error: function() {
                        $('#complaintDetails').html('<p>Error loading complaint details.</p>');
                        modal.style.display = "block";
                    }
                });
            });
            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }
            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        });
// Toggle filter visibility
document.querySelector('.toggle-filters').addEventListener('click', function() {
    const filterSection = document.querySelector('.filter-section');
    filterSection.classList.toggle('collapsed');
    const isExpanded = !filterSection.classList.contains('collapsed');
    this.setAttribute('aria-expanded', isExpanded);
});

// Reset filters
function resetFilters() {
    document.getElementById('complaintFilters').reset();
    // Submit the form after reset if you want to show all results immediately
    document.getElementById('complaintFilters').submit();
}

// Export functionality
function exportFilters() {
    // You can implement CSV or Excel export here
    alert('Export functionality would be implemented here');
    // Example: window.location.href = 'export.php?' + new URLSearchParams(new FormData(document.getElementById('complaintFilters')));
}

// Date validation
document.getElementById('end_date').addEventListener('change', function() {
    const startDate = document.getElementById('start_date').value;
    if (startDate && this.value < startDate) {
        alert('End date cannot be before start date');
        this.value = '';
    }
});
    </script>
    <style>
/* Base Styles */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
    color: #333;
    line-height: 1.6;
}

/* Navigation Bar */
.navtop {
    background-color: #2c3e50;
    height: 60px;
    width: 100%;
    border: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.navtop div {
    display: flex;
    align-items: center;
    gap: 20px;
}

.navtop h1 {
    color: white;
    font-size: 1.5rem;
    margin: 0;
    font-weight: 600;
}

.navtop a {
    color: white;
    text-decoration: none;
    font-size: 1rem;
    padding: 5px 10px;
    border-radius: 4px;
    transition: background-color 0.3s;
    display: flex;
    align-items: center;
    gap: 5px;
}

.navtop a:hover {
    background-color: rgba(255, 255, 255, 0.1);
}

.navtop .logo img {
    height: 40px;
}

/* Main Content */
.content {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.content h2 {
    color: #2c3e50;
    margin-top: 0;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
}

.content p {
    margin-bottom: 20px;
}

/* Filter Form */
/* Filter Section Styles */
.filter-section {
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
    margin-bottom: 2rem;
    overflow: hidden;
    transition: all 0.3s ease;
}

.filter-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 1.5rem;
    background: linear-gradient(135deg, #3498db, #2c3e50);
    color: white;
    cursor: pointer;
}

.filter-header h3 {
    margin: 0;
    font-size: 1.1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.toggle-filters {
    background: transparent;
    border: none;
    color: white;
    font-size: 1rem;
    cursor: pointer;
    transition: transform 0.3s ease;
}

.filter-form {
    padding: 1.5rem;
    border-top: 1px solid #eee;
}

.filter-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.filter-group {
    margin-bottom: 0;
}

.filter-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: #2c3e50;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.filter-select, 
.filter-group input[type="date"],
.filter-group input[type="text"] {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 0.9rem;
    transition: border-color 0.3s, box-shadow 0.3s;
    background-color: #f9f9f9;
}

.filter-select:focus, 
.filter-group input[type="date"]:focus,
.filter-group input[type="text"]:focus {
    border-color: #3498db;
    box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
    outline: none;
    background-color: #fff;
}

.date-range {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.75rem;
}

.date-input {
    display: flex;
    flex-direction: column;
}

.date-input label {
    font-size: 0.8rem;
    color: #666;
    margin-bottom: 0.25rem;
}

.filter-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
    flex-wrap: wrap;
    padding-top: 1rem;
    border-top: 1px solid #eee;
}

.btn {
    padding: 0.75rem 1.25rem;
    border: none;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s ease;
}

.btn-primary {
    background-color: #3498db;
    color: white;
}

.btn-primary:hover {
    background-color: #2980b9;
    transform: translateY(-1px);
}

.btn-secondary {
    background-color: #f8f9fa;
    color: #495057;
    border: 1px solid #dee2e6;
}

.btn-secondary:hover {
    background-color: #e9ecef;
    transform: translateY(-1px);
}

.btn-export {
    background-color: #27ae60;
    color: white;
}

.btn-export:hover {
    background-color: #219955;
    transform: translateY(-1px);
}

/* Collapsed state */
.filter-section.collapsed .filter-form {
    display: none;
}

.filter-section.collapsed .toggle-filters i {
    transform: rotate(180deg);
}

/* Responsive Design */
@media (max-width: 768px) {
    .filter-grid {
        grid-template-columns: 1fr;
    }
    
    .date-range {
        grid-template-columns: 1fr;
    }
    
    .filter-actions {
        justify-content: flex-start;
    }
}
/* DataTables Styling */
#complaintsTable {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

#complaintsTable thead th {
    background-color: #2c3e50;
    color: white;
    padding: 12px 15px;
    text-align: left;
}

#complaintsTable tbody td {
    padding: 10px 15px;
    border-bottom: 1px solid #eee;
}

#complaintsTable tbody tr:nth-child(even) {
    background-color: #f9f9f9;
}

#complaintsTable tbody tr:hover {
    background-color: #f1f1f1;
}

/* Action Buttons */
.view-details {
    background-color: #3498db;
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.85rem;
    transition: background-color 0.3s;
    display: flex;
    align-items: center;
    gap: 5px;
}

.view-details:hover {
    background-color: #2980b9;
}

.view-details i {
    font-size: 0.8rem;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto;
    padding: 25px;
    border-radius: 8px;
    width: 70%;
    max-width: 700px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    position: relative;
}

.close {
    color: #aaa;
    position: absolute;
    top: 15px;
    right: 25px;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover,
.close:focus {
    color: #333;
    text-decoration: none;
}

#complaintDetails p {
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
}

#complaintDetails p:last-child {
    border-bottom: none;
}

#complaintDetails strong {
    display: inline-block;
    width: 150px;
    color: #555;
}

/* DataTables Custom Styling */
.dataTables_wrapper .dataTables_length,
.dataTables_wrapper .dataTables_filter,
.dataTables_wrapper .dataTables_info,
.dataTables_wrapper .dataTables_paginate {
    margin: 10px 0;
    padding: 0 10px;
}

.dataTables_wrapper .dataTables_filter input {
    border: 1px solid #ddd;
    padding: 5px;
    border-radius: 4px;
}

.dataTables_wrapper .dataTables_paginate .paginate_button {
    padding: 5px 10px;
    margin: 0 2px;
    border: 1px solid transparent;
    border-radius: 4px;
    color: #333;
    cursor: pointer;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current,
.dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
    background-color: #2c3e50;
    color: white;
    border: 1px solid #2c3e50;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background-color: #f1f1f1;
    border: 1px solid #ddd;
}

/* Responsive Design */
@media (max-width: 768px) {
    .navtop {
        flex-direction: column;
        height: auto;
        padding: 15px;
    }
    
    .navtop div {
        flex-direction: column;
        gap: 10px;
        width: 100%;
    }
    
    .navtop a {
        width: 100%;
        justify-content: center;
    }
    
    .content {
        padding: 15px;
        margin: 10px;
    }
    
    form {
        grid-template-columns: 1fr;
    }
    
    form button {
        max-width: 100%;
    }
    
    .modal-content {
        width: 90%;
        margin: 20% auto;
    }
    
    #complaintsTable thead {
        display: none;
    }
    
    #complaintsTable tbody td {
        display: block;
        text-align: right;
        padding-left: 50%;
        position: relative;
    }
    
    #complaintsTable tbody td::before {
        content: attr(data-label);
        position: absolute;
        left: 15px;
        width: 45%;
        padding-right: 10px;
        font-weight: bold;
        text-align: left;
    }
    
    #complaintsTable tbody tr {
        margin-bottom: 15px;
        display: block;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
}

/* Print Styles */
@media print {
    .navtop, form, .view-details {
        display: none;
    }
    
    .content {
        margin: 0;
        padding: 0;
        box-shadow: none;
    }
    
    #complaintsTable {
        width: 100%;
        border-collapse: collapse;
    }
    
    #complaintsTable th, #complaintsTable td {
        border: 1px solid #ddd;
        padding: 8px;
    }
    
    #complaintsTable th {
        background-color: #f2f2f2;
    }
}
.complaint-details {
    padding: 20px;
    background: #f9f9f9;
    border-radius: 8px;
    margin-bottom: 20px;
}

.action-history {
    margin-top: 30px;
    border-top: 1px solid #eee;
    padding-top: 20px;
}

.action-history h4 {
    color: #2c3e50;
    margin-bottom: 15px;
}

.action-timeline {
    border-left: 2px solid #3498db;
    padding-left: 20px;
    margin-left: 10px;
}

.action-item {
    background: white;
    padding: 15px;
    border-radius: 6px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 15px;
    position: relative;
}

.action-item:before {
    content: '';
    position: absolute;
    left: -26px;
    top: 20px;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #3498db;
    border: 2px solid white;
}

.action-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.action-type {
    font-weight: bold;
    color: #2c3e50;
}

.action-date {
    color: #7f8c8d;
    font-size: 0.9em;
}

.action-by {
    color: #3498db;
    margin-bottom: 10px;
}

.action-comment {
    background: #f5f5f5;
    padding: 10px;
    border-radius: 4px;
    margin-bottom: 8px;
}

.btn-primary {
    background-color: #3498db;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 600;
    margin-top: 15px;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.btn-primary:hover {
    background-color: #2980b9;
}
    </style>
</body>
</html>