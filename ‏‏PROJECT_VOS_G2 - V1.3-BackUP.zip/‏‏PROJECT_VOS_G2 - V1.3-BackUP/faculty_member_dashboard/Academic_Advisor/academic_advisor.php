<?php
// Start the session with secure settings
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Check authentication and authorization
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || !isset($_SESSION['faculty_id'])) {
    header('Location: ../index.html');
    exit;
}

// Database configuration - consider moving these to a separate config file
define('DB_HOST', 'localhost');
define('DB_NAME', 'faculty');
define('DB_USER', 'root');
define('DB_PASS', 'Root');

// Establish database connection with proper error handling
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    // Log the error and show a user-friendly message
    error_log("Database connection failed: " . $e->getMessage());
    die("We're experiencing technical difficulties. Please try again later.");
}

// Input validation and filtering
$allowed_statuses = ['Submited', 'In_progress', 'Resolved', 'Rejected', 'Under_review'];
$status_filter = in_array($_GET['status'] ?? '', $allowed_statuses) ? $_GET['status'] : '';
$course_filter = isset($_GET['course']) ? trim($_GET['course']) : '';
$student_id_filter = isset($_GET['student_id']) ? (int)$_GET['student_id'] : '';

// Base query with parameterized inputs
$query = "
    SELECT 
        c.complaint_id,
        c.complainant_id,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.complaint_department,
        c.created_at,
        c.updated_at,
        c.active_complaints,
        ca.action_id,
        ca.action_type,
        ca.action_by,
        ca.action_date,
        ca.AA_comment,
        ca.HOD_comment,
        ca.MRC_comment,
        ca.AAU_comment,  
        ca.is_readed,
        s.student_id,
        s.first_name AS student_first_name,
        s.last_name AS student_last_name,
        f.first_name AS advisor_first_name,
        f.last_name AS advisor_last_name
    FROM complaints c
    INNER JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
    LEFT JOIN complaint_actions ca ON c.complaint_id = ca.complaint_id
    WHERE s.academic_advisor = :faculty_id
    AND c.active_complaints IN (1, 0)
";

// Apply filters
if ($status_filter) {
    $query .= " AND c.status = :status";
}
if ($course_filter) {
    $query .= " AND c.course_name LIKE :course";
}
if ($student_id_filter) {
    $query .= " AND s.student_id = :student_id";
}

$query .= " ORDER BY c.created_at DESC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->bindValue(':faculty_id', $_SESSION['faculty_id'], PDO::PARAM_INT);
    
    if ($status_filter) {
        $stmt->bindValue(':status', $status_filter, PDO::PARAM_STR);
    }
    if ($course_filter) {
        $stmt->bindValue(':course', "%$course_filter%", PDO::PARAM_STR);
    }
    if ($student_id_filter) {
        $stmt->bindValue(':student_id', $student_id_filter, PDO::PARAM_INT);
    }
    
    $stmt->execute();
    $complaints = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Database query failed: " . $e->getMessage());
    die("Error fetching complaints. Please try again later.");
}
?>

<!-- Rest of your HTML remains the same -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Tracking System | Voice of Student</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/main.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --success-color: #2ecc71;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --info-color: #1abc9c;
            --light-color: #ecf0f1;
            --dark-color: #34495e;
            --text-color: #333;
            --text-light: #7f8c8d;
            --border-color: #ddd;
            --shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        /* Base Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: #f5f7fa;
            margin: 0;
            padding: 0;
        }

        /* Navigation */
        .navbar {
            background-color: var(--secondary-color);
            color: white;
            padding: 1rem 2rem;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .navbar-brand img {
            height: 40px;
        }

        .navbar-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0;
        }

        .navbar-links {
            display: flex;
            gap: 1rem;
        }

        .nav-link {
            color: white;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-link.logout {
            background-color: var(--danger-color);
        }

        .nav-link.logout:hover {
            background-color: #c0392b;
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        /* Main Content */
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 1.8rem;
            color: var(--secondary-color);
            margin: 0;
        }

        .welcome-message {
            color: var(--text-light);
            font-size: 1rem;
        }

        /* Filters */
        .filters-container {
            background-color: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 2rem;
        }

        .filters-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            align-items: end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-label {
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: var(--secondary-color);
        }

        .filter-input {
            padding: 0.75rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
            transition: var(--transition);
        }

        .filter-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }

        .filter-select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1rem;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: #2980b9;
        }

        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--primary-color);
            color: var(--primary-color);
        }

        .btn-outline:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }

        /* Complaints Table */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .complaints-table {
            width: 100%;
            border-collapse: collapse;
        }

        .complaints-table th {
            background-color: var(--secondary-color);
            color: white;
            padding: 1rem;
            text-align: left;
            font-weight: 500;
        }

        .complaints-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            vertical-align: middle;
        }

        .complaints-table tr:last-child td {
            border-bottom: none;
        }

        .complaints-table tr:hover {
            background-color: rgba(52, 152, 219, 0.05);
        }

        /* Status Badges */
        .status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-Submited {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-In_progress {
            background-color: #cce5ff;
            color: #004085;
        }

        .status-Resolved {
            background-color: #d4edda;
            color: #155724;
        }

        .status-Rejected {
            background-color: #f8d7da;
            color: #721c24;
        }

        .status-Under_review {
            background-color: #e2e3e5;
            color: #383d41;
        }

        /* Complaint Details */
        .complaint-details {
            display: none;
            padding: 1.5rem;
            background-color: #f8f9fa;
            border-radius: 0 0 8px 8px;
        }

        .complaint-details.show {
            display: block;
        }

        .details-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .details-title {
            font-size: 1.25rem;
            color: var(--secondary-color);
            margin: 0;
        }

        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .detail-group {
            margin-bottom: 1rem;
        }

        .detail-label {
            font-weight: 500;
            color: var(--text-light);
            display: block;
            margin-bottom: 0.25rem;
        }

        .detail-value {
            font-size: 1rem;
        }

        .description-box {
            background-color: #f1f1f1;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
        }

        /* Action History */
        .action-history {
            margin-top: 2rem;
        }

        .section-title {
            font-size: 1.1rem;
            color: var(--secondary-color);
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .timeline {
            position: relative;
            padding-left: 1.5rem;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 0.5rem;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: var(--border-color);
        }

        .timeline-item {
            position: relative;
            padding-bottom: 1.5rem;
        }

        .timeline-point {
            position: absolute;
            left: -1.5rem;
            top: 0;
            width: 1rem;
            height: 1rem;
            border-radius: 50%;
            background-color: var(--primary-color);
            border: 2px solid white;
        }

        .timeline-content {
            background-color: white;
            padding: 1rem;
            border-radius: 4px;
            box-shadow: var(--shadow);
        }

        .timeline-date {
            font-size: 0.875rem;
            color: var(--text-light);
            margin-bottom: 0.5rem;
        }

        .comment {
            margin-top: 0.5rem;
            padding: 0.5rem;
            background-color: #f8f9fa;
            border-left: 3px solid var(--primary-color);
            border-radius: 0 4px 4px 0;
        }

        /* No Complaints Message */
        .empty-state {
            text-align: center;
            padding: 3rem;
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .empty-icon {
            font-size: 3rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }

        .empty-title {
            font-size: 1.5rem;
            color: var(--secondary-color);
            margin-bottom: 0.5rem;
        }

        .empty-text {
            color: var(--text-light);
            margin-bottom: 1.5rem;
        }

        /* Alerts */
        .alert-container {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 1100;
            max-width: 400px;
            width: 100%;
            padding: 0 1rem;
        }

        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            box-shadow: var(--shadow);
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }

        .alert.show {
            opacity: 1;
            transform: translateX(0);
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #155724;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #721c24;
        }

        .alert-close {
            margin-left: auto;
            background: none;
            border: none;
            cursor: pointer;
            color: inherit;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                align-items: stretch;
                padding: 1rem;
            }

            .navbar-brand {
                justify-content: space-between;
                margin-bottom: 1rem;
            }

            .navbar-links {
                display: none;
                flex-direction: column;
                gap: 0.5rem;
            }

            .navbar-links.show {
                display: flex;
            }

            .menu-toggle {
                display: block;
            }

            .filters-form {
                grid-template-columns: 1fr;
            }

            .complaints-table th,
            .complaints-table td {
                padding: 0.75rem;
            }

            .complaints-table th:nth-child(3),
            .complaints-table td:nth-child(3),
            .complaints-table th:nth-child(4),
            .complaints-table td:nth-child(4) {
                display: none;
            }
        }

        @media (max-width: 480px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.5rem;
            }

            .complaints-table th:nth-child(2),
            .complaints-table td:nth-child(2) {
                display: none;
            }

            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-brand">
            <a href="../../faculty_member.php" class="logo">
                <img src="../../logo.png" alt="Voice of Student Logo">
            </a>
            <h1 class="navbar-title">Voice of Student</h1>
            <button class="menu-toggle" id="menuToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="navbar-links" id="navbarLinks">
            <a href="../../faculty_member.php" class="nav-link">
                <i class="fas fa-home"></i> Home
            </a>
            <a href="../../faculty_profile.php" class="nav-link">
                <i class="fas fa-user-circle"></i> Profile
            </a>
            <a href="../../../logout/logout.php" class="nav-link logout">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <!-- Alert Container -->
    <div class="alert-container" id="alertContainer"></div>

    <!-- Main Content -->
    <div class="container">
        <div class="page-header">
            <div>
                <h1 class="page-title">Complaint Tracking</h1>
                <p class="welcome-message">Welcome back, <?= htmlspecialchars($_SESSION['name'] ?? 'Faculty', ENT_QUOTES) ?></p>
            </div>
        </div>

        <!-- Filters Section -->
        <div class="filters-container">
            <form method="GET" action="" class="filters-form">
                <div class="filter-group">
                    <label for="status" class="filter-label">Status</label>
                    <select name="status" id="status" class="filter-input filter-select">
                        <option value="">All Statuses</option>
                        <option value="Submited" <?= $status_filter === 'Submited' ? 'selected' : '' ?>>Submitted</option>
                        <option value="In_progress" <?= $status_filter === 'In_progress' ? 'selected' : '' ?>>In Progress</option>
                        <option value="Resolved" <?= $status_filter === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                        <option value="Rejected" <?= $status_filter === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                        <option value="Under_review" <?= $status_filter === 'Under_review' ? 'selected' : '' ?>>Under Review</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="course" class="filter-label">Course Name</label>
                    <input type="text" name="course" id="course" class="filter-input" 
                           value="<?= htmlspecialchars($course_filter, ENT_QUOTES) ?>" 
                           placeholder="Enter course name">
                </div>
                
                <div class="filter-group">
                    <label for="student_id" class="filter-label">Student ID</label>
                    <input type="text" name="student_id" id="student_id" class="filter-input" 
                           value="<?= htmlspecialchars($student_id_filter, ENT_QUOTES) ?>" 
                           placeholder="Enter student ID">
                </div>
                
                <div class="filter-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                    <button type="button" id="resetFilters" class="btn btn-outline">
                        <i class="fas fa-sync-alt"></i> Reset
                    </button>
                </div>
            </form>
        </div>

        <!-- Complaints Table -->
        <?php if (!empty($complaints)): ?>
            <div class="table-responsive">
                <table class="complaints-table">
                    <thead>
                        <tr>
                            <th>Complaint ID</th>
                            <th>Student</th>
                            <th>Type</th>
                            <th>Course</th>
                            <th>Status</th>
                            <th>Submitted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($complaints as $complaint): ?>
                            <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                                <td>
                                    <?= htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name'], ENT_QUOTES) ?>
                                    <div class="text-muted">ID: <?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></div>
                                </td>
                                <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                                <td>
                                    <span class="status-badge status-<?= htmlspecialchars(str_replace(' ', '_', $complaint['status']), ENT_QUOTES) ?>">
                                        <?= htmlspecialchars(str_replace('_', ' ', $complaint['status']), ENT_QUOTES) ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y', strtotime($complaint['created_at'])) ?></td>
                                <td>
                                    <button class="btn btn-primary btn-sm view-details" 
                                            data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                </td>
                            </tr>
                            <tr class="complaint-details" id="complaint-details-<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                <td colspan="7">
                                    <div class="details-header">
                                        <h2 class="details-title">Complaint Details #<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></h2>
                                        <button class="btn btn-outline btn-sm close-details" 
                                                data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                            <i class="fas fa-times"></i> Close
                                        </button>
                                    </div>
                                    
                                    <div class="details-grid">
                                        <div>
                                            <div class="detail-group">
                                                <span class="detail-label">Student Name</span>
                                                <span class="detail-value">
                                                    <?= htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name'], ENT_QUOTES) ?>
                                                </span>
                                            </div>
                                            
                                            <div class="detail-group">
                                                <span class="detail-label">Student ID</span>
                                                <span class="detail-value">
                                                    <?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?>
                                                </span>
                                            </div>
                                            
                                            <div class="detail-group">
                                                <span class="detail-label">Complaint Type</span>
                                                <span class="detail-value">
                                                    <?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <div class="detail-group">
                                                <span class="detail-label">Course Name</span>
                                                <span class="detail-value">
                                                    <?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?>
                                                </span>
                                            </div>
                                            
                                            <div class="detail-group">
                                                <span class="detail-label">Status</span>
                                                <span class="detail-value status-badge status-<?= htmlspecialchars(str_replace(' ', '_', $complaint['status']), ENT_QUOTES) ?>">
                                                    <?= htmlspecialchars(str_replace('_', ' ', $complaint['status']), ENT_QUOTES) ?>
                                                </span>
                                            </div>
                                            
                                            <div class="detail-group">
                                                <span class="detail-label">Submitted On</span>
                                                <span class="detail-value">
                                                    <?= date('M d, Y h:i A', strtotime($complaint['created_at'])) ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="detail-group">
                                        <span class="detail-label">Description</span>
                                        <div class="description-box">
                                            <?= nl2br(htmlspecialchars($complaint['complaint_description'], ENT_QUOTES)) ?>
                                        </div>
                                    </div>
                                    
                                    <?php if (!empty($complaint['action_type'])): ?>
                                    <div class="action-history">
                                        <h3 class="section-title">Action History</h3>
                                        <div class="timeline">
                                            <div class="timeline-item">
                                                <div class="timeline-point"></div>
                                                <div class="timeline-content">
                                                    <strong><?= htmlspecialchars($complaint['action_type'], ENT_QUOTES) ?></strong>
                                                    <div class="timeline-date">
                                                        <?= date('M d, Y h:i A', strtotime($complaint['action_date'])) ?>
                                                    </div>
                                                    
                                                    <?php if (!empty($complaint['AA_comment'])): ?>
                                                        <div class="comment">
                                                            <strong>Academic Advisor Comment:</strong> <?= htmlspecialchars($complaint['AA_comment'], ENT_QUOTES) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (!empty($complaint['HOD_comment'])): ?>
                                                        <div class="comment">
                                                            <strong>Head of Department Comment:</strong> <?= htmlspecialchars($complaint['HOD_comment'], ENT_QUOTES) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (!empty($complaint['MRC_comment'])): ?>
                                                        <div class="comment">
                                                            <strong>Mark Review Committee Comment:</strong> <?= htmlspecialchars($complaint['MRC_comment'], ENT_QUOTES) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <?php if (!empty($complaint['AAU_comment'])): ?>
                                                        <div class="comment">
                                                            <strong>Academic Advisor Unit Comment:</strong> <?= htmlspecialchars($complaint['AAU_comment'], ENT_QUOTES) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p>No actions have been taken on this complaint yet.</p>
                                <?php endif; ?>
                                    
                                    <div class="action-buttons">
                                        <?php if ($complaint['status'] === 'Submited' || $complaint['status'] === 'Under_review'): ?>
                                            <button class="btn btn-primary take-action" 
                                                    data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                                <i class="fas fa-edit"></i> Take Action
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <i class="fas fa-info-circle"></i>
                </div>
                <h3 class="empty-title">No Complaints Found</h3>
                <p class="empty-text">There are currently no complaints matching your criteria.</p>
                <?php if ($status_filter || $course_filter || $student_id_filter): ?>
                    <button id="clearFilters" class="btn btn-primary">
                        <i class="fas fa-times"></i> Clear Filters
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
    // Enhanced Application Controller
    class ComplaintTrackingApp {
        constructor() {
            this.alertSystem = new AlertSystem();
            this.complaintManager = new ComplaintDetailsManager();
            this.filterManager = new FilterManager();
            this.uiManager = new UIManager();
            
            this.initEventListeners();
            this.checkForNotifications();
        }
        
        initEventListeners() {
            // Mobile menu toggle
            document.getElementById('menuToggle').addEventListener('click', () => {
                this.uiManager.toggleMobileMenu();
            });
            
            // Take action buttons
            document.querySelectorAll('.take-action').forEach(button => {
                button.addEventListener('click', (e) => {
                    const complaintId = e.currentTarget.dataset.complaintId;
                    this.handleTakeAction(complaintId);
                });
            });
        }
        
        checkForNotifications() {
            <?php if (isset($_GET['filtered'])) : ?>
                this.alertSystem.show('Complaints filtered successfully', 'success');
            <?php endif; ?>
            
            <?php if (isset($_GET['uploaded'])) : ?>
                this.alertSystem.show('Complaints uploaded successfully', 'success');
            <?php endif; ?>
        }
        
        handleTakeAction(complaintId) {
            // In a real implementation, this would open a modal or redirect to an action page
            this.alertSystem.show(`Taking action on complaint #${complaintId}`, 'info');
            window.location.href = `../track.php?id=${complaintId}`;
        }
    }

    // Alert System
    class AlertSystem {
        constructor() {
            this.container = document.getElementById('alertContainer');
            this.alertTimeout = 5000;
            this.transitionTime = 300;
        }
        
        show(message, type = 'success') {
            const alert = document.createElement('div');
            alert.className = `alert alert-${type}`;
            
            const icon = type === 'success' ? 'fa-check-circle' : 
                        type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle';
            
            alert.innerHTML = `
                <i class="fas ${icon}"></i>
                <span>${message}</span>
                <button class="alert-close"><i class="fas fa-times"></i></button>
            `;
            
            this.container.appendChild(alert);
            
            // Force reflow to enable transition
            void alert.offsetWidth;
            
            // Show alert
            alert.classList.add('show');
            
            // Auto-dismiss
            const dismissTimer = setTimeout(() => this.dismiss(alert), this.alertTimeout);
            
            // Manual dismiss
            alert.querySelector('.alert-close').addEventListener('click', () => {
                clearTimeout(dismissTimer);
                this.dismiss(alert);
            });
        }
        
        dismiss(alert) {
            alert.classList.remove('show');
            setTimeout(() => alert.remove(), this.transitionTime);
        }
    }

    // Complaint Details Manager
    class ComplaintDetailsManager {
        constructor() {
            this.currentOpenComplaint = null;
            this.initEventListeners();
        }
        
        initEventListeners() {
            // View details buttons
            document.querySelectorAll('.view-details').forEach(button => {
                button.addEventListener('click', (e) => {
                    const complaintId = e.currentTarget.dataset.complaintId;
                    this.toggleDetails(complaintId);
                });
            });
            
            // Close details buttons
            document.querySelectorAll('.close-details').forEach(button => {
                button.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const complaintId = e.currentTarget.dataset.complaintId;
                    this.closeDetails(complaintId);
                });
            });
            
            // Close when clicking outside
            document.addEventListener('click', (e) => {
                if (this.currentOpenComplaint && 
                    !e.target.closest('.complaint-details, .view-details')) {
                    this.closeDetails(this.currentOpenComplaint);
                }
            });
            
            // Keyboard support
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.currentOpenComplaint) {
                    this.closeDetails(this.currentOpenComplaint);
                }
            });
        }
        
        toggleDetails(complaintId) {
            if (this.currentOpenComplaint === complaintId) {
                this.closeDetails(complaintId);
            } else {
                this.openDetails(complaintId);
            }
        }
        
        openDetails(complaintId) {
            // Close currently open complaint if exists
            if (this.currentOpenComplaint) {
                this.closeDetails(this.currentOpenComplaint);
            }
            
            const detailsPanel = document.getElementById(`complaint-details-${complaintId}`);
            if (detailsPanel) {
                detailsPanel.style.display = 'table-row';
                this.currentOpenComplaint = complaintId;
                
                // Scroll to the panel
                setTimeout(() => {
                    detailsPanel.scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest'
                    });
                }, 50);
                
                // Highlight the parent row
                const parentRow = document.querySelector(`tr[data-complaint-id="${complaintId}"]`);
                if (parentRow) {
                    parentRow.classList.add('active-row');
                }
            }
        }
        
        closeDetails(complaintId) {
            const detailsPanel = document.getElementById(`complaint-details-${complaintId}`);
            if (detailsPanel) {
                detailsPanel.style.display = 'none';
                
                // Remove highlight from parent row
                const parentRow = document.querySelector(`tr[data-complaint-id="${complaintId}"]`);
                if (parentRow) {
                    parentRow.classList.remove('active-row');
                }
                
                if (this.currentOpenComplaint === complaintId) {
                    this.currentOpenComplaint = null;
                }
            }
        }
    }

    // Filter Manager
    class FilterManager {
        constructor() {
            this.initResetButtons();
        }
        
        initResetButtons() {
            document.getElementById('resetFilters')?.addEventListener('click', () => {
                this.resetFilters();
            });
            
            document.getElementById('clearFilters')?.addEventListener('click', () => {
                this.resetFilters();
            });
        }
        
        resetFilters() {
            const url = new URL(window.location.href);
            url.search = '';
            window.location.href = url.toString();
        }
    }

    // UI Manager
    class UIManager {
        toggleMobileMenu() {
            const menu = document.getElementById('navbarLinks');
            menu.classList.toggle('show');
        }
    }

    // Initialize the application
    document.addEventListener('DOMContentLoaded', () => {
        new ComplaintTrackingApp();
    });

    // Error handling
    window.addEventListener('error', (error) => {
        console.error('Application error:', error);
        const alertSystem = new AlertSystem();
        alertSystem.show('An unexpected error occurred. Please try again.', 'error');
    });
    </script>
</body>
</html>