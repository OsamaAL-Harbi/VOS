<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    // If there is an error with the connection, stop the script and display the error.
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Check if the data from the login form was submitted.
if (!isset($_POST['faculty_id'], $_POST['password'])) {
    // Could not get the data that should have been sent.
    showErrorAndRedirect("Please fill both the ID and password fields!");
    exit;
}

// Function to show error message and redirect back
function showErrorAndRedirect($message) {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Error</title>
        <style>
            .loader-container {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(255,255,255,0.9);
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }
            .loader {
                border: 5px solid #f3f3f3;
                border-top: 5px solid #3498db;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                animation: spin 1s linear infinite;
                margin-bottom: 20px;
            }
            .error-message {
                padding: 15px;
                background: #ffebee;
                color: #c62828;
                border-radius: 4px;
                max-width: 80%;
                text-align: center;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    </head>
    <body>
        <div class="loader-container">
            <div class="loader"></div>
            <div class="error-message">'.htmlspecialchars($message).'</div>
        </div>
        <script>
            setTimeout(function() {
                window.history.back();
            }, 2000);
        </script>
    </body>
    </html>';
}

// Function to show loading screen and redirect
function showLoaderAndRedirect($url) {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Loading...</title>
        <style>
            .loader-container {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(255,255,255,0.9);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }
            .loader {
                border: 5px solid #f3f3f3;
                border-top: 5px solid #3498db;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    </head>
    <body>
        <div class="loader-container">
            <div class="loader"></div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = "'.htmlspecialchars($url).'";
            }, 1000);
        </script>
    </body>
    </html>';
}

// Check for the special admin credentials first
if ($_POST['faculty_id'] == 1 && $_POST['password'] === 'admin') {
    // Set session variables
    session_regenerate_id();
    $_SESSION['loggedin'] = TRUE;
    $_SESSION['name'] = 'Admin';
    $_SESSION['faculty_id'] = 1;
    
    // Show loader and redirect
    showLoaderAndRedirect("../admin/main-nav/index.php");
    exit;
}

// Check for the special academic unit credentials
if ($_POST['faculty_id'] == 440100 && $_POST['password'] === 'ِِِAU123456') {
    // Set session variables
    session_regenerate_id();
    $_SESSION['loggedin'] = TRUE;
    $_SESSION['name'] = 'head_of_Academic_Unit';
    $_SESSION['faculty_id'] = 440100;
    
    // Show loader and redirect
    showLoaderAndRedirect("../faculty_member_dashboard/AAU/AAU_Home.php");
    exit;
}

// Prepare our SQL to check for regular faculty members.
if ($stmt = $con->prepare('SELECT faculty_id, first_name, last_name, password, role FROM faculty_members WHERE faculty_id = ?')) {
    // Bind parameters (i = integer)
    $stmt->bind_param('i', $_POST['faculty_id']);
    $stmt->execute();
    // Store the result so we can check if the account exists in the database.
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Account exists, bind the result variables.
        $stmt->bind_result($faculty_id, $first_name, $last_name, $password, $role);
        $stmt->fetch();

        // Verify the password.
        if ($_POST['password'] === $password) {
            // Verification success! User has logged in!
            session_regenerate_id();
            $_SESSION['loggedin'] = TRUE;
            $_SESSION['name'] = $first_name . ' ' . $last_name; // Store full name
            $_SESSION['faculty_id'] = $faculty_id;

            // Determine redirect URL based on role
            $redirectUrl = "../faculty_member_dashboard/faculty_member.php"; // Default
            
            if ($role === 'head_of_department') {
                $redirectUrl = "../faculty_member_dashboard/HOD/HOD_Home.php";
            } elseif ($role === 'head of review_committee') {
                $redirectUrl = "../faculty_member_dashboard/MRC/MRC_home.php";
            }
            
            // Show loader and redirect
            showLoaderAndRedirect($redirectUrl);
            exit;
        } else {
            // Incorrect password
            showErrorAndRedirect("Incorrect ID and/or password!");
        }
    } else {
        // Incorrect username
        showErrorAndRedirect("Incorrect ID and/or password!");
    }

    // Close the statement
    $stmt->close();
} else {
    // Database error
    showErrorAndRedirect("A system error occurred. Please try again later.");
}

// Close the database connection
mysqli_close($con);

// Function to show success message and redirect (if needed)
function showSuccessAndRedirect($message, $url) {
    echo '<!DOCTYPE html>
    <html>
    <head>
        <title>Success</title>
        <style>
            .message-container {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(255,255,255,0.9);
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }
            .success-message {
                padding: 15px;
                background: #e8f5e9;
                color: #2e7d32;
                border-radius: 4px;
                max-width: 80%;
                text-align: center;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            .loader {
                border: 5px solid #f3f3f3;
                border-top: 5px solid #4caf50;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    </head>
    <body>
        <div class="message-container">
            <div class="success-message">'.htmlspecialchars($message).'</div>
            <div class="loader"></div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = "'.htmlspecialchars($url).'";
            }, 1500);
        </script>
    </body>
    </html>';
}
?>