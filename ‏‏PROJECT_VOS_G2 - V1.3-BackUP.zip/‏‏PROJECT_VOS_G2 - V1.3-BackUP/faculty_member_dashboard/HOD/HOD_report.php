<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Department mapping
$DEPARTMENT_MAP = [
    1 => 'IT',
    2 => 'CS',
    3 => 'DS'
];

try {
    // Use PDO for database connection
    $pdo = new PDO("mysql:host=$DATABASE_HOST;dbname=$DATABASE_NAME", $DATABASE_USER, $DATABASE_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ensure user is logged in
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        header('Location: ../index.html');
        exit();
    }

    // Check if session variables exist
    if (!isset($_SESSION['faculty_id']) || !isset($_SESSION['name'])) {
        exit('Session data missing. Please log in again.');
    }

    // Get HOD's department_id and verify they are actually a HOD
    $stmt = $pdo->prepare("
        SELECT fm.department_id, d.department_name 
        FROM faculty_members fm
        LEFT JOIN departments d ON fm.faculty_id = d.department_head_id
        WHERE fm.faculty_id = ? AND d.department_head_id IS NOT NULL
    ");
    $stmt->execute([$_SESSION['faculty_id']]);
    $faculty_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$faculty_data) {
        exit('Access denied. You are not authorized as a Head of Department.');
    }

    // Set department information
    $department_id = (int)$faculty_data['department_id'];
    $department_name = $DEPARTMENT_MAP[$department_id] ?? $faculty_data['department_name'] ?? 'Unknown Department';

    // Initialize filter variables from GET parameters
    $filters = [
        'status' => $_GET['status'] ?? '',
        'type' => $_GET['type'] ?? '',
        'start_date' => $_GET['start_date'] ?? '',
        'end_date' => $_GET['end_date'] ?? '',
        'course' => $_GET['course'] ?? '',
        'student_id' => $_GET['student_id'] ?? ''
    ];

    // Base query for complaints
    $query_complaints = "
        SELECT 
            c.complaint_id,
            c.complainant_id,
            c.complaint_type,
            c.course_name,
            c.complaint_description,
            c.status,
            c.created_at,
            c.updated_at,
            c.active_complaints,
            d.department_name,
            s.student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            f.faculty_id AS advisor_id,
            CONCAT(f.first_name, ' ', f.last_name) AS advisor_name,
            hod.faculty_id AS hod_id,
            CONCAT(hod.first_name, ' ', hod.last_name) AS hod_name
        FROM complaints c
        INNER JOIN students s ON c.complainant_id = s.student_id
        INNER JOIN departments d ON c.complaint_department = d.department_id
        LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
        LEFT JOIN faculty_members hod ON d.department_head_id = hod.faculty_id
        WHERE c.status != 'Cancelled'
        AND c.complaint_type IN ('final_exam', 'midterm_exam')
        AND hod.faculty_id = :hod_id
    ";

    // Initialize parameters array
    $params = [':hod_id' => $_SESSION['faculty_id']];

    // Add filters dynamically
    if (!empty($filters['status'])) {
        $query_complaints .= " AND c.status = :status";
        $params[':status'] = $filters['status'];
    }
    if (!empty($filters['type'])) {
        $query_complaints .= " AND c.complaint_type = :type";
        $params[':type'] = $filters['type'];
    }
    if (!empty($filters['start_date']) && !empty($filters['end_date'])) {
        $query_complaints .= " AND c.created_at BETWEEN :start_date AND :end_date";
        $params[':start_date'] = $filters['start_date'] . ' 00:00:00';
        $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
    }
    if (!empty($filters['course'])) {
        $query_complaints .= " AND c.course_name LIKE :course";
        $params[':course'] = '%' . $filters['course'] . '%';
    }
    if (!empty($filters['student_id'])) {
        $query_complaints .= " AND s.student_id = :student_id";
        $params[':student_id'] = $filters['student_id'];
    }

    // Add final ordering
    $query_complaints .= " ORDER BY c.created_at DESC";

    // Execute the complaints query
    $stmt_complaints = $pdo->prepare($query_complaints);
    $stmt_complaints->execute($params);
    $complaints = $stmt_complaints->fetchAll(PDO::FETCH_ASSOC);

    // Query to fetch actions for each complaint (if any)
    $actions_by_complaint = [];
    if (!empty($complaints)) {
        $complaint_ids = array_column($complaints, 'complaint_id');
        $placeholders = implode(',', array_fill(0, count($complaint_ids), '?'));
        
        $query_actions = "
            SELECT 
                ca.action_id,
                ca.complaint_id,
                ca.action_type,
                ca.action_by,
                ca.action_date,
                ca.AA_comment,
                ca.HOD_comment,
                ca.MRC_comment,
                ca.AAU_comment,
                ca.is_readed,
                ca.action_by_AA,
                ca.action_by_HOD,
                ca.action_by_MRC,
                ca.action_by_AAU
            FROM complaint_actions ca
            WHERE ca.complaint_id IN ($placeholders)
            ORDER BY ca.action_date DESC
        ";

        $stmt_actions = $pdo->prepare($query_actions);
        $stmt_actions->execute($complaint_ids);
        $actions = $stmt_actions->fetchAll(PDO::FETCH_ASSOC);

        // Organize actions by complaint ID
        foreach ($actions as $action) {
            $actions_by_complaint[$action['complaint_id']][] = $action;
        }
    }

} catch (PDOException $e) {
    die('Database error: ' . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Report - HOD Dashboard</title>
    <link rel="stylesheet" href="style-report.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <style>
        /* Base Styles */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
            line-height: 1.6;
        }
        
        /* Loader Styles */
        .loader {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
            vertical-align: middle;
            margin-right: 8px;
        }
        
        .loader-lg {
            width: 40px;
            height: 40px;
            border-width: 4px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Alert Styles */
        #alert-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            max-width: 400px;
        }
        
        .alert {
            padding: 15px 20px;
            margin-bottom: 15px;
            border-radius: 4px;
            color: white;
            display: flex;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateX(120%);
            animation: slideIn 0.5s forwards, fadeOut 0.5s forwards 2.5s;
            opacity: 1;
        }
        
        .alert i {
            margin-right: 10px;
            font-size: 1.2em;
        }
        
        .alert-success {
            background-color: #28a745;
            border-left: 5px solid #218838;
        }
        
        .alert-error {
            background-color: #dc3545;
            border-left: 5px solid #c82333;
        }
        
        .alert-info {
            background-color: #17a2b8;
            border-left: 5px solid #138496;
        }
        
        @keyframes slideIn {
            to { transform: translateX(0); }
        }
        
        @keyframes fadeOut {
            to { opacity: 0; }
        }
        
        /* Enhanced Button Styles */
        .btn {
            transition: all 0.3s ease;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            border: none;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #0069d9;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background-color: #218838;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .btn-info {
            background-color: #17a2b8;
            color: white;
        }
        
        .btn-info:hover {
            background-color: #138496;
        }
        
        /* Enhanced Popup Styles */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            z-index: 1001;
            animation: popupFadeIn 0.3s ease-out;
        }
        
        @keyframes popupFadeIn {
            from { opacity: 0; transform: translate(-50%, -45%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }
        
        .popup-content {
            margin-top: 20px;
        }
        
        .close-popup {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 24px;
            cursor: pointer;
            color: #aaa;
            transition: color 0.2s;
        }
        
        .close-popup:hover {
            color: #333;
        }
        
        /* Action History Styles */
        .action-timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .action-timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #e0e0e0;
        }
        
        .action-item {
            position: relative;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #f9f9f9;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .action-item::before {
            content: '';
            position: absolute;
            left: -30px;
            top: 20px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #2196F3;
            border: 2px solid white;
        }
        
        .action-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-weight: bold;
        }
        
        .action-user {
            color: #007bff;
            font-weight: 600;
        }
        
        .action-date {
            color: #6c757d;
            font-size: 0.85em;
        }
        
        .action-content {
            margin-top: 10px;
            color: #495057;
        }
        
        /* Status Badges */
        .status-badge {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .status-Submited {
            background-color: #ff9800;
            color: white;
        }
        
        .status-In_progress {
            background-color: #2196F3;
            color: white;
        }
        
        .status-Resolved {
            background-color: #4CAF50;
            color: white;
        }
        
        .status-Rejected {
            background-color: #f44336;
            color: white;
        }
        
        .status-Under_review {
            background-color: #9c27b0;
            color: white;
        }
        
        /* Table Enhancements */
        #complaintsTable tbody tr {
            transition: background-color 0.2s;
        }
        
        #complaintsTable tbody tr:hover {
            background-color: #f8f9fa;
        }
        
        .description-cell {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: help;
        }
        
        /* Filter Section */
        .filters {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .filters form {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .filters label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #495057;
        }
        
        .filters select, 
        .filters input[type="text"],
        .filters input[type="date"] {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            transition: border-color 0.15s;
        }
        
        .filters select:focus, 
        .filters input[type="text"]:focus,
        .filters input[type="date"]:focus {
            border-color: #80bdff;
            outline: 0;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
        }
        
        /* No Complaints Message */
        .no-complaints {
            text-align: center;
            padding: 40px;
            background-color: #f8f9fa;
            border-radius: 8px;
            color: #6c757d;
        }
        
        .no-complaints i {
            font-size: 3em;
            margin-bottom: 15px;
            color: #adb5bd;
        }
         /* Add to your existing styles */
         .help-modal {
            display: none;
            position: fixed;
            z-index: 1002;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }
        
        .help-modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            width: 80%;
            max-width: 700px;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .close-help {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-help:hover {
            color: black;
        }
        
        .help-section {
            margin-bottom: 20px;
        }
        
        .help-section h4 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
            margin-bottom: 12px;
        }
        
        .help-section ul {
            padding-left: 20px;
        }
        
        .help-section li {
            margin-bottom: 8px;
        }
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .filters form {
                grid-template-columns: 1fr;
            }
            
            .popup {
                width: 95%;
                padding: 15px;
            }
            
            #alert-container {
                left: 20px;
                right: 20px;
                max-width: none;
            }
        }
    </style>
</head>
<body class="loggedin">
    <!-- Navigation Bar - Modified to add Help button -->
    <nav class="navtop">
        <div>
            <a href="../logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="../HOD/HOD_Home.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="HOD_track.php"><i class="fas fa-file-alt"></i> Track</a>
            <a href="#" id="help-btn"><i class="fas fa-question-circle"></i> Help</a>
            <a href="/PROJECT_VOS_G2/logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    
    <!-- Help Modal -->
    <div id="helpModal" class="help-modal">
        <div class="help-modal-content">
            <span class="close-help">&times;</span>
            <h3><i class="fas fa-question-circle"></i> HOD Complaint Tracking Help</h3>
            
            <div class="help-section">
                <h4>Using the Tracking System</h4>
                <p>This dashboard allows you to track and manage exam-related complaints in your department.</p>
                
                <h4>Key Features:</h4>
                <ul>
                    <li><strong>Filter Complaints:</strong> Use the filters at the top to find specific complaints by status, type, date range, course, or student ID.</li>
                    <li><strong>View Details:</strong> Click on any complaint row to see full details.</li>
                    <li><strong>Action History:</strong> Click the "View Actions" button to see all actions taken on a complaint.</li>
                    <li><strong>Export Data:</strong> Select complaints using checkboxes and click "Export to CSV" to download data.</li>
                </ul>
            </div>
            
            <div class="help-section">
                <h4>Status Meanings:</h4>
                <ul>
                    <li><span class="status-badge status-Submited"><i class="fas fa-paper-plane"></i> Submitted</span> - Complaint received but not yet reviewed</li>
                    <li><span class="status-badge status-In_progress"><i class="fas fa-spinner fa-pulse"></i> In_progress</span> - Complaint is being processed</li>
                    <li><span class="status-badge status-Under_review"><i class="fas fa-search"></i> Under_review</span> - Complaint is under review by committee</li>
                    <li><span class="status-badge status-Resolved"><i class="fas fa-check-circle"></i> Resolved</span> - Complaint has been resolved</li>
                    <li><span class="status-badge status-Rejected"><i class="fas fa-times-circle"></i> Rejected</span> - Complaint was rejected</li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- Alert Container -->
    <div id="alert-container"></div>
    
    <!-- Loading Overlay -->
    <div id="loading-overlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 2000; justify-content: center; align-items: center;">
        <div style="background: white; padding: 30px; border-radius: 8px; text-align: center;">
            <div class="loader-lg" style="margin: 0 auto 15px;"></div>
            <p id="loading-message">Processing your request...</p>
        </div>
    </div>
    
    <div class="content">
        <h2><i class="fas fa-building"></i> <?php echo $department_name; ?> Department HOD Dashboard - Track Complaints</h2>
        <p><i class="fas fa-user"></i> Welcome, <?= htmlspecialchars($_SESSION['name'] ?? 'HOD', ENT_QUOTES) ?></p>
        
    <!-- Filters -->
    <div class="filters">
        <form method="GET" action="" id="filter-form">
            <div>
                <label for="status"><i class="fas fa-filter"></i> Status:</label>
                <select name="status" id="status" class="filter-select">
                    <option value="">All</option>
                    <option value="Submitted" <?= ($filters['status'] ?? '') === 'Submitted' ? 'selected' : '' ?>>Submitted</option>
                    <option value="In_progress" <?= ($filters['status'] ?? '') === 'In_progress' ? 'selected' : '' ?>>In Progress</option>
                    <option value="Resolved" <?= ($filters['status'] ?? '') === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
                    <option value="Rejected" <?= ($filters['status'] ?? '') === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                    <option value="Under_review" <?= ($filters['status'] ?? '') === 'Under_review' ? 'selected' : '' ?>>Under Review</option>
                </select>
            </div>
            
            <div>
                <label for="type"><i class="fas fa-tag"></i> Type:</label>
                <select name="type" id="type" class="filter-select">
                    <option value="">All</option>
                    <option value="midterm_exam" <?= ($filters['type'] ?? '') === 'midterm_exam' ? 'selected' : '' ?>>Midterm</option>
                    <option value="final_exam" <?= ($filters['type'] ?? '') === 'final_exam' ? 'selected' : '' ?>>Final Exam</option>
                </select>
            </div>
            
            <div>
                <label for="course"><i class="fas fa-book"></i> Course Name:</label>
                <input type="text" name="course" id="course" 
                    value="<?= htmlspecialchars($filters['course'] ?? '', ENT_QUOTES) ?>" 
                    placeholder="Enter course name">
            </div>
            
            <div>
                <label for="student_id"><i class="fas fa-id-card"></i> Student ID:</label>
                <input type="text" name="student_id" id="student_id" 
                    value="<?= htmlspecialchars($filters['student_id'] ?? '', ENT_QUOTES) ?>" 
                    placeholder="Enter student ID">
            </div>
            
            <div>
                <label for="start_date"><i class="fas fa-calendar-alt"></i> Start Date:</label>
                <input type="date" name="start_date" id="start_date" 
                    value="<?= htmlspecialchars($filters['start_date'] ?? '', ENT_QUOTES) ?>">
            </div>
            
            <div>
                <label for="end_date"><i class="fas fa-calendar-alt"></i> End Date:</label>
                <input type="date" name="end_date" id="end_date" 
                    value="<?= htmlspecialchars($filters['end_date'] ?? '', ENT_QUOTES) ?>">
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check"></i> Apply Filters
                </button>
            </div>
        </form>
    </div>
        
        <!-- Display Complaints -->
        <?php if (!empty($complaints)): ?>
            <div class="table-responsive">
                <table id="complaintsTable" class="display">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="select-all"></th>
                            <th><i class="fas fa-hashtag"></i> Complaint ID</th>
                            <th><i class="fas fa-user"></i> Student Name</th>
                            <th><i class="fas fa-id-badge"></i> Student ID</th>
                            <th><i class="fas fa-tag"></i> Type</th>
                            <th><i class="fas fa-book"></i> Course Name</th>
                            <th><i class="fas fa-align-left"></i> Description</th>
                            <th><i class="fas fa-info-circle"></i> Status</th>
                            <th><i class="fas fa-calendar-plus"></i> Date Submitted</th>
                            <th><i class="fas fa-calendar-check"></i> Last Updated</th>
                            <th><i class="fas fa-cog"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($complaints as $complaint): ?>
                            <tr>
                                <td><input type="checkbox" class="complaint-checkbox" data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>"></td>
                                <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['student_name'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                                <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                                <td class="description-cell" title="<?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?>">
                                    <?= strlen($complaint['complaint_description']) > 50 ? 
                                        htmlspecialchars(substr($complaint['complaint_description'], 0, 50) . '...' ): 
                                        htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?>
                                </td>
                                <td>
                                    <span class="status-badge status-<?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?>">
                                        <?php 
                                            $status_icon = [
                                                'Submited' => 'fa-paper-plane',
                                                'In_progress' => 'fa-spinner fa-pulse',
                                                'Resolved' => 'fa-check-circle',
                                                'Rejected' => 'fa-times-circle',
                                                'Under_review' => 'fa-search'
                                            ][$complaint['status']] ?? 'fa-info-circle';
                                        ?>
                                        <i class="fas <?= $status_icon ?>"></i>
                                        <?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y h:i A', strtotime($complaint['created_at'])) ?></td>
                                <td><?= date('M d, Y h:i A', strtotime($complaint['updated_at'])) ?></td>
                                <td>
                                    <?php if (isset($actions_by_complaint[$complaint['complaint_id']])): ?>
                                        <button class="btn btn-info view-actions-btn" data-complaint-id="<?= $complaint['complaint_id'] ?>">
                                            <i class="fas fa-eye"></i> View Actions (<?= count($actions_by_complaint[$complaint['complaint_id']]) ?>)
                                        </button>
                                    <?php else: ?>
                                        <span class="no-actions"><i class="fas fa-ban"></i> No actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="action-buttons mt-3">
                <button id="export-csv-btn" class="btn btn-success">
                    <i class="fas fa-file-export"></i> Export to CSV
                </button>
            </div>
        <?php else: ?>
            <div class="no-complaints">
                <i class="fas fa-exclamation-circle"></i>
                <p>No complaints found assigned to you in the <?= htmlspecialchars($department_name, ENT_QUOTES) ?> department.</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Popup for displaying complaint details -->
    <div class="popup" id="details-popup">
        <span class="close-popup" onclick="closePopup()">&times;</span>
        <h3><i class="fas fa-info-circle"></i> Complaint Details</h3>
        <div class="popup-content" id="popup-content"></div>
    </div>
    
    <!-- Popup for displaying actions -->
    <div class="popup" id="actions-popup">
        <span class="close-popup" onclick="closeActionsPopup()">&times;</span>
        <h3><i class="fas fa-history"></i> Action History</h3>
        <div class="popup-content">
            <div class="action-timeline" id="actions-content"></div>
        </div>
    </div>
    
    <div class="overlay" id="overlay" onclick="closePopup(); closeActionsPopup()"></div>
    
    <script>
        $(document).ready(function() {
            // Initialize DataTable with enhanced options
            $('#complaintsTable').DataTable({
                "pageLength": 10,
                "order": [[8, "desc"]], // Sort by created_at by default
                "responsive": true,
                "dom": '<"top"<"d-flex justify-content-between align-items-center"f<"ms-3"l>>>rt<"bottom"<"d-flex justify-content-between align-items-center"ip>>',
                "language": {
                    "search": "<i class='fas fa-search'></i> Search:",
                    "lengthMenu": "Show _MENU_ entries",
                    "info": "Showing _START_ to _END_ of _TOTAL_ entries",
                    "paginate": {
                        "previous": "<i class='fas fa-chevron-left'></i>",
                        "next": "<i class='fas fa-chevron-right'></i>"
                    }
                },
                "initComplete": function() {
                    $('.dataTables_filter input').addClass('form-control');
                    $('.dataTables_length select').addClass('form-select');
                }
            });
            
            // Select All Checkbox Logic
            $('#select-all').change(function() {
                $('.complaint-checkbox').prop('checked', this.checked);
            });
            
            // View Actions button click handler
            $(document).on('click', '.view-actions-btn', function() {
                const complaintId = $(this).data('complaint-id');
                showActionsPopup(complaintId);
            });
            
            // Tooltip for description cells
            $('.description-cell').hover(function() {
                $(this).attr('data-tooltip', $(this).attr('title'));
                $(this).removeAttr('title');
            }, function() {
                $(this).attr('title', $(this).attr('data-tooltip'));
            });
            
            // Filter form submission with loading indicator
            $('#filter-form').submit(function(e) {
                showLoading('Applying filters...');
            });
        });
        
        // Function to show alerts
        function showAlert(message, type = 'info', duration = 3000) {
            const alertContainer = $('#alert-container');
            const icon = {
                'success': 'fa-check-circle',
                'error': 'fa-exclamation-circle',
                'info': 'fa-info-circle'
            }[type] || 'fa-info-circle';
            
            const alertDiv = $(`
                <div class="alert alert-${type}">
                    <i class="fas ${icon}"></i> ${message}
                </div>
            `);
            
            alertContainer.append(alertDiv);
            
            // Remove alert after duration
            setTimeout(() => {
                alertDiv.fadeOut(500, () => alertDiv.remove());
            }, duration);
        }
        
        // Function to show loading overlay
        function showLoading(message = 'Processing your request...') {
            $('#loading-message').text(message);
            $('#loading-overlay').fadeIn(200);
        }
        
        // Function to hide loading overlay
        function hideLoading() {
            $('#loading-overlay').fadeOut(200);
        }
        
        
        // Function to close the details popup
        function closePopup() {
            $('#details-popup, #overlay').hide();
        }
        
        // Function to open the actions popup
        function showActionsPopup(complaintId) {
            showLoading('Loading action history...');
            
            $.ajax({
                url: 'get_actions.php',
                method: 'GET',
                data: { complaint_id: complaintId },
                success: function(response) {
                    $('#actions-content').html(response);
                    $('#actions-popup, #overlay').show();
                    hideLoading();
                },
                error: function(xhr, status, error) {
                    let errorMsg = 'Error loading actions';
                    if (xhr.responseText) {
                        errorMsg += ': ' + xhr.responseText;
                    }
                    $('#actions-content').html(`
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-triangle"></i> ${errorMsg}
                        </div>
                    `);
                    $('#actions-popup, #overlay').show();
                    hideLoading();
                    showAlert(errorMsg, 'error');
                }
            });
        }
        
        // Function to close the actions popup
        function closeActionsPopup() {
            $('#actions-popup, #overlay').hide();
        }
        
        // Get selected complaint IDs
        function getSelectedComplaintIds() {
            return $('.complaint-checkbox:checked').map(function() {
                return $(this).data('complaint-id');
            }).get();
        }
        
        // Export to CSV button click handler
        $('#export-csv-btn').click(function() {
            const selectedIds = getSelectedComplaintIds();
            if (selectedIds.length === 0) {
                showAlert('Please select at least one complaint to export.', 'error');
                return;
            }
            
            showLoading('Preparing CSV export...');
            
            // Create a temporary form to submit
            const form = document.createElement('form');
            form.method = 'GET';
            form.action = '../HOD/services/CSV.php';
            
            // Add selected IDs as hidden input
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'ids';
            input.value = selectedIds.join(',');
            form.appendChild(input);
            
            // Submit the form
            document.body.appendChild(form);
            form.submit();
            
            // The page will navigate away, so we don't need to hide loading
        });
        
        // Add click handler for complaint rows to show details
        $('#complaintsTable tbody').on('click', 'tr', function(e) {
            // Don't trigger if clicking on checkbox or action button
            if (!$(e.target).is('input[type="checkbox"]') && !$(e.target).closest('.view-actions-btn').length) {
                const complaintId = $(this).find('td:eq(1)').text();
                openPopup(complaintId);
            }
        });
        
        // Show initial alert if there's a message in the URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('message')) {
            const message = urlParams.get('message');
            const type = urlParams.get('type') || 'info';
            showAlert(decodeURIComponent(message), type);
        }
        $(document).ready(function() {
            // [Previous JavaScript code remains the same]
            
            // Help modal functionality
            const helpModal = document.getElementById("helpModal");
            const helpBtn = document.getElementById("help-btn");
            const closeHelp = document.getElementsByClassName("close-help")[0];
            
            helpBtn.onclick = function() {
                helpModal.style.display = "block";
            }
            
            closeHelp.onclick = function() {
                helpModal.style.display = "none";
            }
            
            window.onclick = function(event) {
                if (event.target == helpModal) {
                    helpModal.style.display = "none";
                }
            }
        });
        
    </script>
</body>
</html>