<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$DATABASE_HOST;dbname=$DATABASE_NAME", $DATABASE_USER, $DATABASE_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_GET['complaint_id'])) {
        throw new Exception('Complaint ID not provided');
    }

    $complaint_id = $_GET['complaint_id'];
    
    $query = "SELECT * FROM complaint_actions WHERE complaint_id = :complaint_id ORDER BY action_date DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute([':complaint_id' => $complaint_id]);
    $actions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($actions)) {
        echo '<div class="no-actions"><i class="fas fa-info-circle"></i> No actions found for this complaint.</div>';
        exit;
    }

    echo '<style>
        .actions-container {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .actions-header {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .actions-list {
            max-height: 500px;
            overflow-y: auto;
            padding-right: 10px;
        }
        .action-item {
            background-color: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 0 4px 4px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .action-item p {
            margin: 8px 0;
            color: #34495e;
        }
        .action-item strong {
            color: #2c3e50;
        }
        .no-actions {
            text-align: center;
            padding: 20px;
            color: #7f8c8d;
            background-color: #ecf0f1;
            border-radius: 4px;
        }
        .error {
            color: #e74c3c;
            padding: 15px;
            background-color: #fadbd8;
            border-radius: 4px;
            text-align: center;
        }
        .fas {
            margin-right: 8px;
        }
        .loading {
            text-align: center;
            padding: 20px;
            color: #3498db;
        }
        .loading-spinner {
            animation: spin 1s linear infinite;
            font-size: 24px;
            margin-bottom: 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #3498db;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #2980b9;
        }
    </style>';

    echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">';
    
    echo '<div class="actions-container">';
    echo '<div class="actions-header">';
    echo '<h3><i class="fas fa-list-alt"></i> Actions for Complaint #' . htmlspecialchars($complaint_id) . '</h3>';
    echo '</div>';
    
    echo '<div class="actions-list">';
    
    foreach ($actions as $action) {
        echo '<div class="action-item">';
        
        // Action Type with icon
        $action_icon = '';
        switch(strtolower($action['action_type'])) {
            case 'submitted':
                $action_icon = 'fa-paper-plane';
                break;
            case 'reviewed':
                $action_icon = 'fa-search';
                break;
            case 'resolved':
                $action_icon = 'fa-check-circle';
                break;
            default:
                $action_icon = 'fa-tasks';
        }
        echo '<p><strong><i class="fas ' . $action_icon . '"></i> Action Type:</strong> ' . htmlspecialchars($action['action_type']) . '</p>';
        
        // Date with calendar icon
        echo '<p><strong><i class="fas fa-calendar-alt"></i> Date:</strong> ' . htmlspecialchars($action['action_date']) . '</p>';
        
        // Comments with different icons and colors
        if (!empty($action['AA_comment'])) {
            echo '<p class="comment"><strong><i class="fas fa-user-tie" style="color: #16a085;"></i> Advisor Comment:</strong> ' . 
                 '<span style="color: #27ae60;">' . htmlspecialchars($action['AA_comment']) . '</span></p>';
        }
        
        if (!empty($action['HOD_comment'])) {
            echo '<p class="comment"><strong><i class="fas fa-user-shield" style="color: #2980b9;"></i> HOD Comment:</strong> ' . 
                 '<span style="color: #3498db;">' . htmlspecialchars($action['HOD_comment']) . '</span></p>';
        }
        
        if (!empty($action['MRC_comment'])) {
            echo '<p class="comment"><strong><i class="fas fa-users" style="color: #8e44ad;"></i> MRC Comment:</strong> ' . 
                 '<span style="color: #9b59b6;">' . htmlspecialchars($action['MRC_comment']) . '</span></p>';
        }
        
        if (!empty($action['AAU_comment'])) {
            echo '<p class="comment"><strong><i class="fas fa-university" style="color: #e67e22;"></i> AAU Comment:</strong> ' . 
                 '<span style="color: #d35400;">' . htmlspecialchars($action['AAU_comment']) . '</span></p>';
        }
        
        echo '</div>';
    }
    
    echo '</div>'; // Close actions-list
    echo '</div>'; // Close actions-container

} catch (PDOException $e) {
    echo '<div class="error"><i class="fas fa-exclamation-triangle"></i> Database Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
} catch (Exception $e) {
    echo '<div class="error"><i class="fas fa-exclamation-circle"></i> Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
}
?>

<script>
// This would be called from your main page's JavaScript
function showLoading() {
    document.getElementById('actions-content').innerHTML = `
        <div class="loading">
            <div class="loading-spinner"><i class="fas fa-spinner"></i></div>
            Loading actions...
        </div>
    `;
}
</script>