<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: ../index.html');
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty';
$username = 'root';
$password = 'Root';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Check if viewing a specific complaint
$complaint_id = isset($_GET['complaint_id']) ? (int)$_GET['complaint_id'] : null;

if ($complaint_id) {
    // Get complaint details with actions
    $query = "
        SELECT 
            c.*,
            s.student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            ca.action_id,
            ca.action_type,
            ca.action_by,
            ca.action_date,
            ca.AA_comment,
            ca.HOD_comment,
            ca.MRC_comment,
            ca.AAU_comment,
            ca.action_by_AA,
            ca.action_by_HOD,
            ca.action_by_MRC,
            ca.action_by_AAU
        FROM complaints c
        JOIN students s ON c.complainant_id = s.student_id
        LEFT JOIN complaint_actions ca ON c.complaint_id = ca.complaint_id
        WHERE c.complaint_id = ?
        ORDER BY ca.action_date DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([$complaint_id]);
    $complaint_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($complaint_details)) {
        die('Complaint not found');
    }
    
    // Display complaint details
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Complaint Details</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { padding: 20px; }
            .action-card { margin-bottom: 20px; border-left: 4px solid #007bff; }
            .action-Rejected { border-left-color: #dc3545; }
            .action-Resolved { border-left-color: #28a745; }
            .action-Forwarded { border-left-color: #17a2b8; }
        </style>
    </head>
    <body>
        <div class="container">
            <a href="test.php" class="btn btn-secondary mb-3">← Back to list</a>
            <h2>Complaint #'.$complaint_details[0]['complaint_id'].' Details</h2>
            <div class="card mb-4">
                <div class="card-header">
                    <h3>Basic Information</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Student:</strong> '.htmlspecialchars($complaint_details[0]['student_name']).'</p>
                            <p><strong>Student ID:</strong> '.htmlspecialchars($complaint_details[0]['student_id']).'</p>
                            <p><strong>Complaint Type:</strong> '.htmlspecialchars($complaint_details[0]['complaint_type']).'</p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Course:</strong> '.htmlspecialchars($complaint_details[0]['course_name']).'</p>
                            <p><strong>Status:</strong> <span class="badge bg-'.($complaint_details[0]['status'] == 'Resolved' ? 'success' : ($complaint_details[0]['status'] == 'Rejected' ? 'danger' : 'warning')).'">'.htmlspecialchars($complaint_details[0]['status']).'</span></p>
                            <p><strong>Submitted:</strong> '.date('M j, Y g:i a', strtotime($complaint_details[0]['created_at'])).'</p>
                        </div>
                    </div>
                    <div class="mt-3">
                        <h5>Description</h5>
                        <p>'.htmlspecialchars($complaint_details[0]['complaint_description']).'</p>
                    </div>
                </div>
            </div>
            
            <h3 class="mt-4">Action History</h3>';
            
            if (!empty($complaint_details[0]['action_id'])) {
                foreach ($complaint_details as $action) {
                    echo '<div class="card action-card action-'.$action['action_type'].' mb-3">
                        <div class="card-body">
                            <h5 class="card-title">'.htmlspecialchars($action['action_type']).'</h5>
                            <p class="card-text"><small class="text-muted">'.date('M j, Y g:i a', strtotime($action['action_date'])).'</small></p>';
                            
                            if (!empty($action['AA_comment'])) {
                                echo '<p><strong>Academic Advisor Comment:</strong> '.htmlspecialchars($action['AA_comment']).'</p>';
                            }
                            if (!empty($action['HOD_comment'])) {
                                echo '<p><strong>HOD Comment:</strong> '.htmlspecialchars($action['HOD_comment']).'</p>';
                            }
                            if (!empty($action['MRC_comment'])) {
                                echo '<p><strong>MRC Comment:</strong> '.htmlspecialchars($action['MRC_comment']).'</p>';
                            }
                            if (!empty($action['AAU_comment'])) {
                                echo '<p><strong>AAU Comment:</strong> '.htmlspecialchars($action['AAU_comment']).'</p>';
                            }
                            
                            echo '</div>
                    </div>';
                }
            } else {
                echo '<div class="alert alert-info">No actions recorded for this complaint</div>';
            }
            
            echo '</div>
        </body>
        </html>';
    exit;
}

// Default view - list of complaints
$faculty_id = $_SESSION['faculty_id'];
$stmt = $pdo->prepare("SELECT department_id FROM faculty_members WHERE faculty_id = ?");
$stmt->execute([$faculty_id]);
$department_id = $stmt->fetchColumn();

if (!$department_id) {
    die('Department not found for this faculty member');
}

// Get department name
$stmt = $pdo->prepare("SELECT department_name FROM departments WHERE department_id = ?");
$stmt->execute([$department_id]);
$department_name = $stmt->fetchColumn();

// Fetch complaints for the IT department (both active and inactive)
$query = "
    SELECT 
        c.complaint_id,
        c.complainant_id,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.created_at,
        c.updated_at,
        c.active_complaints,
        s.student_id,
        CONCAT(s.first_name, ' ', s.last_name) AS student_name
    FROM complaints c
    JOIN students s ON c.complainant_id = s.student_id
    WHERE c.complaint_department = 'IT'
    AND (c.active_complaints = 1 OR c.active_complaints = 0)  -- Show both active and inactive
    ORDER BY c.created_at DESC
";

$stmt = $pdo->prepare($query);
$stmt->execute();
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Department Complaints</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; }
        .table-responsive { margin-top: 20px; }
        .status-active { color: #28a745; }
        .status-inactive { color: #6c757d; }
        .complaint-row { cursor: pointer; }
        .complaint-row:hover { background-color: #f8f9fa; }
        .navbar { margin-bottom: 20px; }
        .filters { margin-bottom: 20px; }
        .icon { font-size: 1.2rem; margin-right: 8px; }
    </style>
</head>
<body>
        <!-- Navigation Bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <i class="fas fa-home icon"></i>Complaint Management
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="HOD_Home.php">
                            <i class="fas fa-list icon"></i>Home
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h2><?= htmlspecialchars($department_name) ?> Department Complaints</h2>
        
        <?php if (!empty($complaints)): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student</th>
                            <th>Type</th>
                            <th>Course</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Submitted</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($complaints as $complaint): ?>
                            <tr class="complaint-row status-<?= $complaint['active_complaints'] ? 'active' : 'inactive' ?>"
                                onclick="window.location.href='test.php?complaint_id=<?= $complaint['complaint_id'] ?>'">
                                <td><?= htmlspecialchars($complaint['complaint_id']) ?></td>
                                <td>
                                    <?= htmlspecialchars($complaint['student_name']) ?>
                                    <small class="text-muted d-block">ID: <?= htmlspecialchars($complaint['student_id']) ?></small>
                                </td>
                                <td><?= htmlspecialchars($complaint['complaint_type']) ?></td>
                                <td><?= htmlspecialchars($complaint['course_name']) ?></td>
                                <td><?= htmlspecialchars(substr($complaint['complaint_description'], 0, 50)) ?>...</td>
                                <td>
                                    <span class="badge bg-<?= $complaint['status'] == 'Resolved' ? 'success' : ($complaint['status'] == 'Rejected' ? 'danger' : 'warning') ?>">
                                        <?= htmlspecialchars($complaint['status']) ?>
                                    </span>
                                </td>
                                <td><?= date('M j, Y', strtotime($complaint['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                No complaints found for this department.
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>