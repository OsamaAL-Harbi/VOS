<?php
require_once 'vendor/autoload.php';
require_once '../../../admin/db.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;

// Start session and verify authentication
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Content-Type: application/json');
    http_response_code(401);
    exit(json_encode(['error' => 'Unauthorized access - Please login first']));
}

/**
 * Fetch department complaints with action details based on HOD's department
 */
function fetchDepartmentComplaintsWithActions(PDO $pdo, int $hodFacultyId): array {
    try {
        // First get the HOD's department with department code (IT, CS, DS)
        $deptQuery = "SELECT d.department_id, d.department_name, 
                     (SELECT faculty FROM faculty_members WHERE faculty_id = d.department_head_id) as department_code
                     FROM departments d
                     WHERE d.department_head_id = :hod_id";
        
        $deptStmt = $pdo->prepare($deptQuery);
        $deptStmt->execute([':hod_id' => $hodFacultyId]);
        $department = $deptStmt->fetch(PDO::FETCH_ASSOC);

        if (!$department) {
            throw new Exception("You are not assigned as Head of any department");
        }

        // Get all complaints for this department using department code (IT, CS, DS)
        $query = "SELECT 
                    c.complaint_id, 
                    c.complainant_id,
                    c.complaint_type,
                    c.course_name,
                    c.complaint_description, 
                    c.status, 
                    DATE_FORMAT(c.created_at, '%Y-%m-%d %H:%i:%s') AS created_at,
                    DATE_FORMAT(c.updated_at, '%Y-%m-%d %H:%i:%s') AS updated_at,
                    c.recipient,
                    c.active_complaints,
                    s.student_id, 
                    s.email AS student_email, 
                    CONCAT(s.first_name, ' ', s.last_name) AS student_name,
                    f.faculty_id AS advisor_id,
                    CONCAT(f.first_name, ' ', f.last_name) AS advisor_name
                FROM complaints c
                JOIN students s ON c.complainant_id = s.student_id
                LEFT JOIN faculty_members f ON s.academic_advisor = f.faculty_id
                WHERE c.complaint_department = :dept_code
                AND c.status != 'Cancelled'
                ORDER BY c.created_at DESC";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([':dept_code' => $department['department_code']]);
        $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Initialize actions array for all complaints
        foreach ($complaints as &$complaint) {
            $complaint['actions'] = [];
        }

        if (!empty($complaints)) {
            // Get all complaint IDs
            $complaintIds = array_column($complaints, 'complaint_id');
            $placeholders = implode(',', array_fill(0, count($complaintIds), '?'));
            
            // Fetch all actions for these complaints
            $actionQuery = "SELECT 
                            ca.complaint_id,
                            ca.action_type,
                            COALESCE(CONCAT(u.first_name, ' ', u.last_name), ca.action_by) AS action_by,
                            DATE_FORMAT(ca.action_date, '%Y-%m-%d %H:%i:%s') AS action_date,
                            COALESCE(ca.AA_comment, 'N/A') AS AA_comment,
                            COALESCE(ca.HOD_comment, 'N/A') AS HOD_comment,
                            COALESCE(ca.MRC_comment, 'N/A') AS MRC_comment,
                            COALESCE(ca.AAU_comment, 'N/A') AS AAU_comment,
                            ca.action_by_AA,
                            ca.action_by_HOD,
                            ca.action_by_MRC,
                            ca.action_by_AAU
                        FROM complaint_actions ca
                        LEFT JOIN faculty_members u ON ca.action_by = u.faculty_id
                        WHERE ca.complaint_id IN ($placeholders)
                        ORDER BY ca.action_date DESC";
            
            $actionStmt = $pdo->prepare($actionQuery);
            $actionStmt->execute($complaintIds);
            $actions = $actionStmt->fetchAll(PDO::FETCH_ASSOC);

            // Group actions by complaint ID
            $actionsByComplaint = [];
            foreach ($actions as $action) {
                $actionsByComplaint[$action['complaint_id']][] = $action;
            }

            // Merge actions into complaints
            foreach ($complaints as &$complaint) {
                if (isset($actionsByComplaint[$complaint['complaint_id']])) {
                    $complaint['actions'] = $actionsByComplaint[$complaint['complaint_id']];
                }
            }
        }

        return [
            'department' => $department,
            'complaints' => $complaints ?: []
        ];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        throw new Exception("Database operation failed: " . $e->getMessage());
    }
}

/**
 * Generate formatted Excel export with action details
 */
function generateComplaintsExportWithActions(array $data): void {
    try {
        $department = $data['department'];
        $complaints = $data['complaints'];

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Complaints Overview');

        // Set document metadata
        $spreadsheet->getProperties()
            ->setCreator($_SESSION['name'] ?? 'Department HOD')
            ->setTitle("{$department['department_name']} Department Complaints Report")
            ->setDescription("Generated on " . date('Y-m-d H:i:s'));

        // Setup page layout
        $sheet->getPageSetup()
            ->setOrientation(PageSetup::ORIENTATION_LANDSCAPE)
            ->setPaperSize(PageSetup::PAPERSIZE_A4)
            ->setFitToWidth(1);

        // Define headers
        $headers = [
            'Complaint ID', 
            'Student ID',
            'Student Name',
            'Course',
            'Complaint Type',
            'Description',
            'Status',
            'Created Date',
            'Last Updated',
            'Active',
            'Recipient',
            'Action Count',
            'Latest Action',
            'Latest Action Date'
        ];
        
        $sheet->fromArray($headers, null, 'A1');

        // Style headers
        $headerStyle = [
            'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF'], 'size' => 12],
            'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
            'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '4472C4']],
            'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN]]
        ];
        $sheet->getStyle('A1:M1')->applyFromArray($headerStyle);

        // Add complaint data
        $row = 2;
        foreach ($complaints as $complaint) {
            // Safely handle actions data
            $actions = $complaint['actions'] ?? [];
            $actionCount = count($actions);
            $latestAction = $actionCount > 0 ? ($actions[0]['action_type'] ?? 'No actions') : 'No actions';
            $latestActionDate = $actionCount > 0 ? ($actions[0]['action_date'] ?? 'N/A') : 'N/A';

            $sheet->fromArray([
                $complaint['complaint_id'],
                $complaint['student_id'],
                $complaint['student_name'],
                $complaint['course_name'] ?? 'N/A',
                $complaint['complaint_type'],
                $complaint['complaint_description'],
                $complaint['status'],
                $complaint['created_at'],
                $complaint['updated_at'],
                $complaint['active_complaints'] ? 'Yes' : 'No',
                $complaint['recipient'],
                $actionCount,
                $latestAction,
                $latestActionDate
            ], null, "A{$row}");

            // Apply status-based formatting
            $statusColor = match($complaint['status']) {
                'Pending', 'In_progress' => 'FFFF00', // Yellow
                'Resolved' => '00FF00', // Green
                'Rejected' => 'FF0000', // Red
                default => 'FFFFFF'   // White
            };
            
            $sheet->getStyle("A{$row}:M{$row}")
                ->getFill()
                ->setFillType(Fill::FILL_SOLID)
                ->setStartColor(new Color($statusColor));

            $row++;
        }

        // Add Actions sheet if there are any actions
        if (!empty(array_filter(array_column($complaints, 'actions')))) {
            $actionSheet = $spreadsheet->createSheet();
            $actionSheet->setTitle('Action Details');
            
            // Action details headers
            $actionHeaders = [
                'Complaint ID',
                'Action Type',
                'Action By',
                'Action Date',
                'AA Comment',
                'HOD Comment',
                'MRC Comment',
                'AAU Comment',
                'Action By AA',
                'Action By HOD',
                'Action By MRC',
                'Action By AAU'
            ];
            $actionSheet->fromArray($actionHeaders, null, 'A1');
            $actionSheet->getStyle('A1:L1')->applyFromArray($headerStyle);
            
            // Add action data
            $actionRow = 2;
            foreach ($complaints as $complaint) {
                foreach ($complaint['actions'] as $action) {
                    $actionSheet->fromArray([
                        $complaint['complaint_id'],
                        $action['action_type'],
                        $action['action_by'],
                        $action['action_date'],
                        $action['AA_comment'],
                        $action['HOD_comment'],
                        $action['MRC_comment'],
                        $action['AAU_comment'],
                        $action['action_by_AA'],
                        $action['action_by_HOD'],
                        $action['action_by_MRC'],
                        $action['action_by_AAU']
                    ], null, "A{$actionRow}");
                    $actionRow++;
                }
            }

            // Auto-size columns for action sheet
            foreach (range('A', 'L') as $col) {
                $actionSheet->getColumnDimension($col)->setAutoSize(true);
            }
        }

        // Auto-size columns for main sheet
        foreach (range('A', 'M') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Set main sheet as active
        $spreadsheet->setActiveSheetIndex(0);

        // Generate filename with department name and timestamp
        $filename = "{$department['department_name']}_Complaints_Export_" . date('Y-m-d_His') . '.xlsx';

        // Output headers
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Save spreadsheet
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');

    } catch (Exception $e) {
        error_log("Excel generation error: " . $e->getMessage());
        header('Content-Type: application/json');
        http_response_code(500);
        exit(json_encode(['error' => $e->getMessage()]));
    }
}

// Main execution
try {
    if (!isset($_SESSION['faculty_id'])) {
        throw new Exception("Faculty ID not found in session");
    }

    $data = fetchDepartmentComplaintsWithActions($pdo, $_SESSION['faculty_id']);
    
    if (empty($data['complaints'])) {
        // Generate empty report with message instead of throwing error
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', "No active complaints found for {$data['department']['department_name']} department");
        $sheet->mergeCells('A1:M1');
        $sheet->getStyle('A1')->getFont()->setBold(true);
        
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.$data['department']['department_name'].'_Complaints_Empty_'.date('Y-m-d').'.xlsx"');
        
        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;
    }
    
    generateComplaintsExportWithActions($data);
} catch (Exception $e) {
    header('Content-Type: application/json');
    http_response_code(500);
    exit(json_encode(['error' => $e->getMessage()]));
}