<?php
require_once '../db.php';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query("
        SELECT co.course_name, COUNT(ce.enrollment_id) AS enrollment_count
        FROM enrollments ce
        JOIN courses co ON ce.course_id = co.course_id
        GROUP BY co.course_name
        ORDER BY enrollment_count DESC
        LIMIT 5
    ");
    $popular_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Most Popular Courses</title>
    <link rel="stylesheet" href="../CSS/popular_courses.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        // Theme Toggle
        document.addEventListener('DOMContentLoaded', () => {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;

            // Load saved theme from localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            } else {
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }

            // Toggle theme on button click
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
            });
        });
    </script>
</head>
<body>
    <header>
        <h1><i class="fas fa-chart-bar"></i> Most Popular Courses</h1>
        <!-- Back to Main Navigation Button -->
        <div class="back-to-main">
            <a href="../main-nav/index.php" class="btn btn-back">
                <i class="fas fa-arrow-left"></i> Back to Main Navigation
            </a>
        </div>
    </header>

    <!-- Theme Toggle -->
    <div class="theme-toggle">
        <button id="theme-toggle-btn" aria-label="Toggle theme">
            <span class="theme-icon"><i class="fas fa-sun"></i></span>
        </button>
    </div>

    <!-- Most Popular Courses -->
    <section id="popular-courses">
        <h2><i class="fas fa-chart-line"></i> Most Popular Courses</h2>
        <div class="table-container">
            <table class="complaint-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-book"></i> Course Name</th>
                        <th><i class="fas fa-users"></i> Enrollment Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_courses)): ?>
                        <?php foreach ($popular_courses as $course): ?>
                            <tr>
                                <td><i class="fas fa-book-open"></i> <?= htmlspecialchars($course['course_name']) ?></td>
                                <td><i class="fas fa-user-check"></i> <?= htmlspecialchars($course['enrollment_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="no-data">
                                <i class="fas fa-exclamation-circle"></i> No popular courses found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p><i class="fas fa-copyright"></i> 2025 Admin Panel. All rights reserved.</p>
    </footer>
</body>
</html>