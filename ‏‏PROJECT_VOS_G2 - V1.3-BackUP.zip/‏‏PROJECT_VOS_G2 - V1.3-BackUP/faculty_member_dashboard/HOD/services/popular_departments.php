<?php
require_once '../db.php';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Default sorting: Most Faculty
    $orderBy = isset($_GET['sort']) ? $_GET['sort'] : 'faculty_count';
    $validSortOptions = ['faculty_count', 'course_count', 'student_count'];
    if (!in_array($orderBy, $validSortOptions)) {
        $orderBy = 'faculty_count'; // Default fallback
    }

    $stmt = $pdo->prepare("SELECT 
            d.department_name, 
            COUNT(DISTINCT f.faculty_id) AS faculty_count,
            COUNT(DISTINCT c.course_id) AS course_count,
            COUNT(DISTINCT s.student_id) AS student_count
        FROM departments d
        LEFT JOIN faculty_members f ON d.department_id = f.department_id
        LEFT JOIN courses c ON d.department_id = c.department_id
        LEFT JOIN students s ON d.department_id = s.department_id
        GROUP BY d.department_name
        ORDER BY $orderBy DESC
        LIMIT 5");
    $stmt->execute();
    $popular_departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Popular Departments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            height: 100vh; /* Full viewport height */
            overflow: hidden; /* Prevent scrolling */
        }

        /* Main Container */
        .container {
            text-align: center;
            max-width: 600px; /* Limit width for readability */
            padding: 2rem;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Navigation Bar */
        nav {
            background-color: #2c3e50;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px;
            margin-bottom: 1rem;
        }

        nav .btn-home {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 0.7rem 1.5rem;
            font-size: 1rem;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav .btn-home:hover {
            background-color: #2980b9;
        }

        /* Tooltip Styling */
        nav div {
            position: relative;
        }

        nav div i {
            color: white;
            margin-left: 1rem;
            cursor: pointer;
            font-size: 1.2rem;
            transition: color 0.3s ease;
        }

        nav div i:hover {
            color: #3498db;
        }

        /* Tooltip Container */
        .tooltip {
            position: relative;
            display: inline-block;
        }

        /* Tooltip Text */
        .tooltip .tooltiptext {
            visibility: hidden;
            width: max-content;
            max-width: 200px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 5px 10px;
            position: absolute;
            z-index: 1;
            bottom: 125%; /* Position above the icon */
            left: 50%;
            transform: translateX(-50%);
            opacity: 0;
            transition: opacity 0.3s ease, visibility 0.3s ease;
            font-size: 0.9rem;
            white-space: nowrap;
        }

        /* Tooltip Arrow */
        .tooltip .tooltiptext::after {
            content: "";
            position: absolute;
            top: 100%;
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        /* Show Tooltip on Hover */
        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        /* Section Styling */
        section#popular-departments {
            margin-top: 1rem;
        }

        h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #2c3e50;
        }

        /* Filter Buttons */
        .filters {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .filters button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 0.7rem 1.5rem;
            font-size: 1rem;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .filters button.active {
            background-color: #2980b9;
        }

        .filters button:hover {
            background-color: #2980b9;
        }

        /* Search Input */
        input#search {
            width: 100%;
            padding: 0.7rem;
            margin-bottom: 1.5rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input#search:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tbody tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        /* Icons */
        td i {
            margin-right: 0.5rem;
        }
    </style>
    <script>
        function filterTable() {
            let input = document.getElementById("search").value.toLowerCase();
            let rows = document.querySelectorAll("tbody tr");
            rows.forEach(row => {
                let deptName = row.cells[0].textContent.toLowerCase();
                row.style.display = deptName.includes(input) ? "" : "none";
            });
        }
    </script>
</head>
<body>
    <!-- Main Container -->
    <div class="container">
        <!-- Navigation Bar -->
        <nav>
            <button onclick="window.location.href='../main-nav/index.php'" class="btn-home">Back to Home</button>
            <div>
                <div class="tooltip">
                    <i class="fas fa-filter"></i>
                    <span class="tooltiptext">Filter departments based on faculty, courses, or students.</span>
                </div>
                <div class="tooltip">
                    <i class="fas fa-info-circle"></i>
                    <span class="tooltiptext">View detailed statistics about department performance.</span>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <section id="popular-departments">
            <h2><i class="fas fa-university"></i> Most Popular Departments</h2>

            <!-- Filters -->
            <div class="filters">
                <button class="<?= ($orderBy === 'faculty_count') ? 'active' : '' ?>" 
                        onclick="window.location.href='?sort=faculty_count'">Most Faculty</button>
                <button class="<?= ($orderBy === 'course_count') ? 'active' : '' ?>" 
                        onclick="window.location.href='?sort=course_count'">Most Courses</button>
                <button class="<?= ($orderBy === 'student_count') ? 'active' : '' ?>" 
                        onclick="window.location.href='?sort=student_count'">Most Students</button>
            </div>


            <!-- Table -->
            <table>
                <thead>
                    <tr>
                        <th><i class="fas fa-building"></i> Department Name</th>
                        <th><i class="fas fa-chalkboard-teacher"></i> Faculty Count</th>
                        <th><i class="fas fa-book"></i> Course Count</th>
                        <th><i class="fas fa-users"></i> Student Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_departments)): ?>
                        <?php foreach ($popular_departments as $department): ?>
                            <tr>
                                <td><i class="fas fa-building"></i> <?= htmlspecialchars($department['department_name']) ?></td>
                                <td><i class="fas fa-chalkboard-teacher"></i> <?= htmlspecialchars($department['faculty_count']) ?></td>
                                <td><i class="fas fa-book"></i> <?= htmlspecialchars($department['course_count']) ?></td>
                                <td><i class="fas fa-users"></i> <?= htmlspecialchars($department['student_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4"><i class="fas fa-exclamation-triangle"></i> No departments found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>
</body>
</html>