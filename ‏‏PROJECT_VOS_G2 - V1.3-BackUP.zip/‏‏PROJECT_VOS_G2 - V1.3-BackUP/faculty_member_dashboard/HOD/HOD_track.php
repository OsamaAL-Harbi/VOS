<?php
// Start PHP section
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start the session
session_start();

// Check if the user is logged in, otherwise redirect to the login page
if (!isset($_SESSION['loggedin'])) {
    header('Location: ../index.html'); // Redirect to login page
    exit;
}

// Database connection
$host = 'localhost';
$dbname = 'faculty'; // Replace with your database name
$username = 'root';  // Replace with your database username
$password = 'Root';  // Replace with your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
}

// Handle POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $complaint_id = intval($data['complaint_id'] ?? 0);
    $action = $data['action'] ?? ''; // 'forward' or 'reject'
    $comment = trim($data['comment'] ?? '');
    $faculty_id = $_SESSION['faculty_id'] ?? null;

    // Validate input data
    if (!$complaint_id || !in_array($action, ['forward', 'reject']) || empty($comment) || !$faculty_id) {
        http_response_code(400); // Bad Request
        die(json_encode(['success' => false, 'message' => 'Invalid request data']));
    }

    try {
        // Begin transaction
        $pdo->beginTransaction();

        if ($action === 'forward') {
            // Fetch the Head of Review Committee ID
            $stmt_fetch_mrc = $pdo->prepare("
                SELECT faculty_id 
                FROM faculty_members 
                WHERE role = 'head of review_committee'
            ");
            $stmt_fetch_mrc->execute();
            $mrc_id = $stmt_fetch_mrc->fetchColumn();

            if (!$mrc_id) {
                throw new Exception('Head of Review Committee not found');
            }

            // Update complaint status to 'Under_review' and assign to MRC
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'Under_review', recipient = :mrc_id, updated_at = NOW()
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([
                ':complaint_id' => $complaint_id,
                ':mrc_id' => $mrc_id
            ]);

            $action_type = 'Forwarded';

        } elseif ($action === 'reject') {
            // Update complaint status to 'Rejected'
            $stmt1 = $pdo->prepare("
                UPDATE complaints 
                SET status = 'Rejected', active_complaints = 0, updated_at = NOW()
                WHERE complaint_id = :complaint_id AND active_complaints = 1
            ");
            $stmt1->execute([':complaint_id' => $complaint_id]);

            $action_type = 'Rejected';
        }

        // Check if update was successful
        if ($stmt1->rowCount() === 0) {
            throw new Exception('Failed to update complaint status or invalid complaint ID');
        }

    // Update action record in complaint_actions
    $stmt2 = $pdo->prepare("
        UPDATE complaint_actions
        SET 
            action_type = :action_type,
            action_by = :action_by,
            action_date = NOW(),
            HOD_comment = :HOD_comment,
            action_by_HOD = :action_by_HOD,
            is_readed = 0
        WHERE complaint_id = :complaint_id
    ");
    $stmt2->execute([
        ':complaint_id' => $complaint_id,
        ':action_type' => $action_type,
        ':action_by' => $faculty_id,
        ':action_by_HOD' => $faculty_id,
        ':HOD_comment' => $comment
    ]);

        // Commit transaction
        $pdo->commit();
        echo json_encode([
            'success' => true,
            'message' => 'Complaint status updated successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        http_response_code(500); // Internal Server Error
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Fetch complaints for students assigned to the logged-in academic advisor
$faculty_id = $_SESSION['faculty_id'] ?? null; // Assume the faculty ID is stored in the session

if (!$faculty_id) {
    http_response_code(401); // Unauthorized
    die(json_encode(['success' => false, 'message' => 'User session expired or invalid faculty ID']));
}

$query = "
    SELECT 
        c.*, 
        s.student_id, 
        s.first_name AS student_first_name, 
        s.last_name AS student_last_name,
        f.first_name AS advisor_first_name, 
        f.last_name AS advisor_last_name
    FROM complaints c
    INNER JOIN students s ON c.complainant_id = s.student_id
    LEFT JOIN departments d ON s.department_id = d.department_id
    LEFT JOIN faculty_members f ON d.department_head_id = f.faculty_id
    WHERE c.recipient = :faculty_id -- Only fetch complaints assigned to the logged-in faculty member
    AND c.status = 'In_progress' -- Only fetch complaints with the status 'In Progress'
    AND c.active_complaints = 1 -- Only fetch active complaints
    ORDER BY c.created_at DESC
";

try {
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':faculty_id', $faculty_id, PDO::PARAM_INT);
    $stmt->execute();
    $complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
}
?>


<!-- Start HTML Section -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="../../faculty_member_dashboard/CSS/track_FM.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        /* Simple styling for alerts */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            z-index: 1000;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Styling for the modal */
        .modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            width: 400px;
            max-width: 90%;
            font-family: Arial, sans-serif;
            text-align: center;
            max-height: 80vh;
            overflow-y: auto;
        }

        .backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }

        /* Styling for buttons */
        .action-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .action-btn:hover {
            background-color: #0056b3;
        }

        /* Styling for complaint table */
        .complaints-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .complaints-table th, .complaints-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .complaints-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="/logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="HOD_Home.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="HOD_profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    <div id="alert-container"></div>
    <div class="content">
        <h2>Faculty Dashboard - Track Complaints</h2>
        <p>Hello, <?= htmlspecialchars($_SESSION['name'] ?? 'Guest', ENT_QUOTES) ?></p>
        <!-- Display Complaints -->
        <?php if (!empty($complaints)): ?>
            <table class="complaints-table">
                <thead>
                    <tr>
                        <th>Complaint ID</th>
                        <th>Student Name</th>
                        <th>Student ID</th>
                        <th>Complaint Type</th>
                        <th>Course Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Date Submitted</th>
                        <th>Active</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($complaints as $complaint): ?>
                        <tr data-complaint-id="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                            <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['student_first_name'] . ' ' . $complaint['student_last_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['student_id'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_type'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['course_name'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['complaint_description'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['status'], ENT_QUOTES) ?></td>
                            <td><?= htmlspecialchars($complaint['created_at'], ENT_QUOTES) ?></td>
                            <td><?= $complaint['active_complaints'] ? 'Yes' : 'No' ?></td>
                            <td>
                                <button class="action-btn" onclick="handleComplaint(<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>)">
                                    Action
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No complaints found.</p>
        <?php endif; ?>
    </div>
    <script>
        // Function to handle complaint actions
        function handleComplaint(complaintId) {
            const modal = createModal(complaintId);
            const backdrop = createBackdrop(modal);
            document.body.append(backdrop, modal);
        }

        // Helper function to create the modal
        function createModal(complaintId) {
            const modal = document.createElement('div');
            modal.classList.add('modal');
            modal.innerHTML = `
                <h3>Complaint ID: ${complaintId}</h3>
                <button id="forwardBtn">Forward</button>
                <button id="rejectBtn">Reject</button>
            `;
            modal.querySelector('#forwardBtn').onclick = () => showModalForm(modal, complaintId, 'forward', 'Add Comment for Forwarding', 'Submit Forward');
            modal.querySelector('#rejectBtn').onclick = () => showModalForm(modal, complaintId, 'reject', 'Add Reason for Rejection', 'Submit Rejection');
            return modal;
        }

        // Helper function to create the backdrop
        function createBackdrop(modal) {
            const backdrop = document.createElement('div');
            backdrop.classList.add('backdrop');
            backdrop.onclick = () => {
                modal.remove();
                backdrop.remove();
            };
            return backdrop;
        }

        // Helper function to show the form in the modal
        function showModalForm(modal, complaintId, action, heading, buttonText) {
            // Remove any existing form before adding a new one
            const existingForm = modal.querySelector('.modal-form');
            if (existingForm) existingForm.remove();
            const form = document.createElement('div');
            form.classList.add('modal-form');
            form.innerHTML = `
                <h4>${heading}</h4>
                <textarea id="commentBox" rows="4" cols="50"></textarea>
                <button id="submitBtn">${buttonText}</button>
            `;
            modal.appendChild(form);
            form.querySelector('#submitBtn').onclick = () => {
                const comment = form.querySelector('#commentBox').value.trim();
                if (!comment) {
                    showAlert('Comment is required.', 'error');
                    return;
                }
                sendRequest('../../faculty_member_dashboard/HOD/HOD_track.php', { complaint_id: complaintId, action, comment });
            };
        }

        // Function to send AJAX request to the backend
        function sendRequest(url, data) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', url, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                showAlert(response.message, 'success');
                                // Remove the complaint row from the UI
                                const row = document.querySelector(`tr[data-complaint-id="${data.complaint_id}"]`);
                                if (row) row.remove();
                            } else {
                                showAlert(response.message, 'error');
                            }
                        } catch (e) {
                            console.error('Invalid response:', xhr.responseText);
                            showAlert('An unexpected error occurred. Please try again.', 'error');
                        }
                    } else {
                        showAlert('An error occurred while processing your request. Please try again.', 'error');
                    }
                }
            };
            xhr.send(JSON.stringify(data));
        }

        // Function to show alerts
        function showAlert(message, type) {
            const alertContainer = document.getElementById('alert-container');
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert ${type === 'success' ? 'alert-success' : 'alert-error'}`;
            alertDiv.textContent = message;
            alertContainer.appendChild(alertDiv);
            // Automatically remove the alert after 3 seconds
            setTimeout(() => {
                alertDiv.remove();
            }, 3000);
        }
    </script>
</body>
</html>