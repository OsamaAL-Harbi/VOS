<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== TRUE) {
    header('Location: ../index.html');
    exit();
}

// Fetch user details from the database including department
$stmt = $con->prepare('SELECT faculty_id, first_name, last_name, email, department_id FROM faculty_members WHERE faculty_id = ?');
$stmt->bind_param('i', $_SESSION['faculty_id']);
$stmt->execute();
$stmt->bind_result($faculty_id, $first_name, $last_name, $email, $department_id);
$stmt->fetch();
$stmt->close();

// Get department name from department_id
$dept_stmt = $con->prepare('SELECT department_name FROM departments WHERE department_id = ?');
$dept_stmt->bind_param('i', $department_id);
$dept_stmt->execute();
$dept_stmt->bind_result($department_name);
$dept_stmt->fetch();
$dept_stmt->close();

// Update session variables
$_SESSION['name'] = $first_name . ' ' . $last_name; // Full name
$_SESSION['email'] = $email;
$_SESSION['faculty_id'] = $faculty_id;
$_SESSION['department_id'] = $department_id;
$_SESSION['department_name'] = $department_name; // Store department name in session

// Fetch department-specific complaint statistics
$query = "
    SELECT 
        COUNT(*) AS total_complaints,
        SUM(CASE WHEN status = 'Submitted' THEN 1 ELSE 0 END) AS Submitted_complaints,
        SUM(CASE WHEN status = 'In_progress' THEN 1 ELSE 0 END) AS in_progress_complaints,
        SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) AS resolved_complaints,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected_complaints
    FROM complaints
    WHERE complaint_department = ?
";
$stmt = $con->prepare($query);
$stmt->bind_param('s', $department_id);
$stmt->execute();
$result = $stmt->get_result();
$stats = $result->fetch_assoc();
$stmt->close();

// Provide default values if no rows are returned
$stats['total_complaints'] = $stats['total_complaints'] ?? 0;
$stats['Submitted_complaints'] = $stats['Submitted_complaints'] ?? 0;
$stats['in_progress_complaints'] = $stats['in_progress_complaints'] ?? 0;
$stats['resolved_complaints'] = $stats['resolved_complaints'] ?? 0;
$stats['rejected_complaints'] = $stats['rejected_complaints'] ?? 0;

// Check for unread actions assigned to this HOD
$unread_actions_query = "
    SELECT COUNT(*) AS unread_actions
    FROM complaint_actions
    WHERE action_by_HOD = ? 
    AND is_readed = 0
    AND complaint_id IN (SELECT complaint_id FROM complaints WHERE complaint_department = ?)
";
$stmt = $con->prepare($unread_actions_query);
$stmt->bind_param('is', $_SESSION['faculty_id'], $department_id);
$stmt->execute();
$stmt->bind_result($unread_actions);
$stmt->fetch();
$stmt->close();

// Check for Submitted complaints in the department
$Submitted_complaints_query = "
    SELECT COUNT(*) AS Submitted_complaints
    FROM complaints
    WHERE complaint_department = ?
    AND status = 'Submitted'
";
$stmt = $con->prepare($Submitted_complaints_query);
$stmt->bind_param('s', $department_id);
$stmt->execute();
$stmt->bind_result($Submitted_complaints);
$stmt->fetch();
$stmt->close();

// Determine if an alert should be displayed
$show_new_actions_alert = ($unread_actions > 0 && !isset($_SESSION['alert_shown_actions']));
$show_Submitted_complaints_alert = ($Submitted_complaints > 0 && !isset($_SESSION['alert_shown_Submitted']));

// Mark alerts as shown
if ($show_new_actions_alert) {
    $_SESSION['alert_shown_actions'] = true;
}
if ($show_Submitted_complaints_alert) {
    $_SESSION['alert_shown_Submitted'] = true;
}

// Calculate resolution rate
$resolution_rate = ($stats['total_complaints'] > 0) 
    ? round(($stats['resolved_complaints'] / $stats['total_complaints']) * 100) 
    : 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($department_name, ENT_QUOTES) ?> HOD Dashboard - Voice of Student</title>
    <link href="HOD_Home.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: <?php 
                switch($department_name) {
                    case 'Information Technology': echo '#4e73df'; break;
                    case 'Computer Science': echo '#1cc88a'; break;
                    case 'Data Science': echo '#f6c23e'; break;
                    default: echo '#858796';
                }
            ?>;
            --primary-light: <?php 
                switch($department_name) {
                    case 'Information Technology': echo '#a6b7e8'; break;
                    case 'Computer Science': echo '#8ddfc0'; break;
                    case 'Data Science': echo '#f9d781'; break;
                    default: echo '#b5b7c4';
                }
            ?>;
        }
        
        .department-badge {
            background-color: var(--primary-color);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
            display: inline-block;
            margin-left: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .stats-card {
            border-left: 5px solid var(--primary-color);
            transition: all 0.3s ease;
            background: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        
        .stats-card h3 {
            color: var(--primary-color);
        }
        
        .stats-card p {
            font-size: 2rem;
            font-weight: bold;
            margin: 10px 0;
        }
        
        /* Action Buttons Container */
        .action-buttons-container {
            display: flex;
            gap: 20px;
            margin: 30px 0;
            flex-wrap: wrap;
        }

        /* Base Button Styles */
        .action-button {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 15px 25px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            min-width: 200px;
            text-align: center;
            border: none;
            cursor: pointer;
        }

        /* Track Button Specific Styles */
        .track-button {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            border: 2px solid #4e73df;
        }

        /* Report Button Specific Styles */
        .report-button {
            background: linear-gradient(135deg, #1cc88a 0%, #13855c 100%);
            border: 2px solid #1cc88a;
        }

        /* Alert Badge */
        .alert-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #e74a3b;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
            animation: pulse 2s infinite;
            box-shadow: 0 0 0 rgba(231, 74, 59, 0.4);
        }

        /* Hover Effects */
        .action-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }

        .track-button:hover {
            background: linear-gradient(135deg, #3b5fd4 0%, #1a3bb0 100%);
            border-color: #3b5fd4;
        }

        .report-button:hover {
            background: linear-gradient(135deg, #17b57d 0%, #0e6d4a 100%);
            border-color: #17b57d;
        }

        /* Ripple Effect */
        .action-button:after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(231, 74, 59, 0.4);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(231, 74, 59, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(231, 74, 59, 0);
            }
        }

        /* Click Animation */
        .action-button:focus:not(:active)::after {
            animation: ripple 1s ease-out;
        }

        @keyframes ripple {
            0% {
                transform: scale(0, 0);
                opacity: 0.5;
            }
            100% {
                transform: scale(20, 20);
                opacity: 0;
            }
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .action-buttons-container {
                flex-direction: column;
                gap: 15px;
            }
            
            .action-button {
                width: 100%;
            }
        }
        
        .department-summary {
            background-color: #f8f9fa;
            border-left: 4px solid var(--primary-color);
            padding: 20px;
            border-radius: 5px;
            margin-top: 30px;
        }
        
        .alert-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e74a3b;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
        }
    </style>
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="../logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="HOD_profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="HOD_track.php" class="nav-item">
                <i class="fas fa-file-alt"></i> Track
                <?php if ($unread_actions > 0): ?>
                    <span class="alert-badge"><?= $unread_actions ?></span>
                <?php endif; ?>
            </a>
            <a href="HOD_report.php"><i class="fas fa-chart-pie"></i> Reports</a>
            <a href="/PROJECT_VOS_G2/logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>

    <div class="content">
        <h2>Head of Department Dashboard 
            <span class="department-badge"><?= htmlspecialchars($department_name, ENT_QUOTES) ?></span>
        </h2>
        <p class="welcome-message">Welcome back, <strong><?= htmlspecialchars($_SESSION['name'], ENT_QUOTES) ?></strong>!</p>

        <?php if ($show_new_actions_alert || $show_Submitted_complaints_alert): ?>
            <script>
                // Display a custom SweetAlert2 alert
                <?php if ($show_new_actions_alert && $show_Submitted_complaints_alert): ?>
                    Swal.fire({
                        title: 'Department Updates!',
                        html: `<p>You have <strong><?= $unread_actions ?></strong> new actions requiring your attention.</p>
                               <p>There are <strong><?= $Submitted_complaints ?></strong> complaints Submitted in your department.</p>`,
                        icon: 'info',
                        confirmButtonText: 'Review Now',
                        showCancelButton: true,
                        cancelButtonText: 'Later',
                        confirmButtonColor: 'var(--primary-color)'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'HOD_track.php';
                        }
                    });
                <?php elseif ($show_new_actions_alert): ?>
                    Swal.fire({
                        title: 'New Actions!',
                        text: "You have <?= $unread_actions ?> new actions requiring your attention.",
                        icon: 'info',
                        confirmButtonText: 'Review Now',
                        showCancelButton: true,
                        cancelButtonText: 'Later',
                        confirmButtonColor: 'var(--primary-color)'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'HOD_track.php';
                        }
                    });
                <?php else: ?>
                    Swal.fire({
                        title: 'Submitted Complaints!',
                        text: "There are <?= $Submitted_complaints ?> complaints Submitted in your department.",
                        icon: 'warning',
                        confirmButtonText: 'View Complaints',
                        showCancelButton: true,
                        cancelButtonText: 'Later',
                        confirmButtonColor: 'var(--primary-color)'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'HOD_track.php?status=Submitted';
                        }
                    });
                <?php endif; ?>
            </script>
        <?php endif; ?>

        <div class="stats-container">
            <div class="stats-card">
                <h3>Submitted Actions</h3>
                <p><?= $unread_actions ?></p>
                <small>Requiring your review</small>
            </div>
            <div class="stats-card">
                <h3>Total Complaints</h3>
                <p><?= $stats['total_complaints'] ?></p>
                <small>In <?= $department_name ?></small>
            </div>
            <div class="stats-card">
                <h3>In Progress</h3>
                <p><?= $stats['in_progress_complaints'] ?></p>
                <small>Being processed</small>
            </div>
            <div class="stats-card">
                <h3>Resolved</h3>
                <p><?= $stats['resolved_complaints'] ?></p>
                <small>Successfully closed</small>
            </div>
            <div class="stats-card">
                <h3>Rejected</h3>
                <p><?= $stats['rejected_complaints'] ?></p>
                <small>Not approved</small>
            </div>
        </div>

        <!-- Action Buttons Container -->
        <div class="action-buttons-container">
            <!-- Track Button with Alert -->
            <a href="HOD_track.php" class="action-button track-button">
                <i class="fas fa-tasks"></i>
                Track Complaints
                <?php if ($unread_actions > 0): ?>
                    <span class="alert-badge"><?= min($unread_actions, 9) ?><?= $unread_actions > 9 ? '+' : '' ?></span>
                <?php endif; ?>
            </a>
        

        <!-- Department Summary Section -->
        <div class="department-summary">
            <h3><i class="fas fa-chart-line"></i> <?= $department_name ?> Performance Overview</h3>
            <div class="summary-content">
                <div class="summary-item">
                    <i class="fas fa-bell summary-icon" style="color: var(--primary-color);"></i>
                    <div>
                        <h4>Submitted Actions</h4>
                        <p><?= $unread_actions ?> actions need your review</p>
                    </div>
                </div>
                <div class="summary-item">
                    <i class="fas fa-clock summary-icon" style="color: var(--primary-color);"></i>
                    <div>
                        <h4>Submitted Complaints</h4>
                        <p><?= $stats['Submitted_complaints'] ?> complaints awaiting processing</p>
                    </div>
                </div>
                <div class="summary-item">
                    <i class="fas fa-percentage summary-icon" style="color: var(--primary-color);"></i>
                    <div>
                        <h4>Resolution Rate</h4>
                        <p><?= $resolution_rate ?>% of complaints resolved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="dashboard-footer">
        <p>&copy; <?= date('Y') ?> Voice of Student. All rights reserved.</p>
    </footer>
    <script>
        // Add animation to stats cards on page load
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.stats-card');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100 * index);
            });
        });

        // Track button hover effect
        const trackButton = document.querySelector('.track-button');
        if (trackButton) {
            trackButton.addEventListener('mouseenter', () => {
                trackButton.innerHTML = '<i class="fas fa-arrow-right"></i> Go to Tracking';
            });
            trackButton.addEventListener('mouseleave', () => {
                trackButton.innerHTML = '<i class="fas fa-tasks"></i> Track Complaints';
            });
        }
    </script>
</body>
</html>