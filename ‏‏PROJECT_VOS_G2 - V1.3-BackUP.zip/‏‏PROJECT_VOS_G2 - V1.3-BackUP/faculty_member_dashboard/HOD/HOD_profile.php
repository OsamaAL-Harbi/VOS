<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
    // If there is an error with the connection, stop the script and display the error.
    exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== TRUE) {
    header('Location: ../index.html');
    exit();
}

// Get user details from the database (id, first_name, last_name, email)
$stmt = $con->prepare('SELECT faculty_id, first_name, last_name, email FROM faculty_members WHERE faculty_id = ?');
$stmt->bind_param('i', $_SESSION['faculty_id']); // Ensure no extra spaces in the key
$stmt->execute();
$stmt->bind_result($faculty_id, $first_name, $last_name, $email);
$stmt->fetch();
$stmt->close();

// Update session variables
$_SESSION['name'] = $first_name . ' ' . $last_name; // Full name
$_SESSION['email'] = $email;
$_SESSION['faculty_id'] = $faculty_id; // Ensure no extra spaces in the key
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="HOD_profile.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
</head>
<body class="loggedin">
    <nav class="navtop">
        <div>
            <a href="../index.html" class="logo">
                <img src="../logo.png" alt="Logo">
            </a>
            <h1>Voice of Student</h1>
            <a href="../HOD/HOD_Home.php"><i class="fas fa-home"></i> Back to Home</a>
            <a href="../../logout/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </nav>
    <div class="content">
        <div class="card">
            <h2>Profile Page</h2>
            <p>Your account details are below:</p>
            <table>
                <tr>
                    <td><strong>Faculty ID:</strong></td>
                    <td><?= htmlspecialchars($_SESSION['faculty_id']) ?></td>
                </tr>
                <tr>
                    <td><strong>Username:</strong></td>
                    <td><?= htmlspecialchars($_SESSION['name']) ?></td>
                </tr>
                <tr>
                    <td><strong>Email:</strong></td>
                    <td><?= htmlspecialchars($_SESSION['email']) ?></td>
                </tr>
                <tr>
                    <td><strong>Edit Password:</strong></td>
                    <td>
                        <a href="../../faculty_member_dashboard/password_update.php" class="button">Update</a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>