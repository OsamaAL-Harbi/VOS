<?php
session_start();

// Database connection details
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

try {
    // Use PDO for database connection
    $pdo = new PDO("mysql:host=$DATABASE_HOST;dbname=$DATABASE_NAME", $DATABASE_USER, $DATABASE_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ensure user is logged in
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== TRUE) {
        die(json_encode(['success' => false, 'message' => 'User not logged in']));
    }

    // Get the complaint ID from the request
    if (!isset($_GET['complaint_id'])) {
        die(json_encode(['success' => false, 'message' => 'Complaint ID is missing']));
    }
    $complaint_id = $_GET['complaint_id'];

    // Query to fetch complaint details and associated actions
    $query = "
        SELECT 
            c.complaint_id,
            c.complainant_id,
            c.complaint_type,
            c.course_name,
            c.complaint_description,
            c.status,
            c.created_at,
            c.active_complaints,
            s.student_id AS student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            ca.action_id,
            ca.action_type,
            ca.action_by,
            ca.action_date,
            ca.AA_comment,
            ca.HOD_comment,
            ca.MRC_comment
        FROM complaints c
        INNER JOIN students s ON c.complainant_id = s.student_id
        LEFT JOIN complaint_actions ca ON c.complaint_id = ca.complaint_id
        WHERE c.complaint_id = :complaint_id AND c.status != 'Cancelled'
    ";

    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':complaint_id', $complaint_id, PDO::PARAM_INT);
    $stmt->execute();
    $details = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$details) {
        die(json_encode(['success' => false, 'message' => 'No details found for the given complaint ID']));
    }

    // Return the details as JSON
    echo json_encode(['success' => true, 'data' => $details]);
} catch (PDOException $e) {
    // Log the error for debugging
    error_log('Database error: ' . $e->getMessage());
    die(json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]));
} catch (Exception $e) {
    // Log other exceptions
    error_log('Unexpected error: ' . $e->getMessage());
    die(json_encode(['success' => false, 'message' => 'An unexpected error occurred']));
}
?>