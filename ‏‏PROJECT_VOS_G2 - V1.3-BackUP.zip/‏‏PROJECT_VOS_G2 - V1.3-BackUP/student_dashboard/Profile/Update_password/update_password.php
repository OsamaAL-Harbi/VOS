<?php
session_start();
// connection info.
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	// If there is an error with the connection, stop the script and display the error.
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}

// Ensure user is logged in
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit();
}

// Get current password hash from the database
$stmt = $con->prepare('SELECT password FROM students WHERE student_id = ?');
$stmt->bind_param('i', $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($currentPassword);
$stmt->fetch();
$stmt->close();

// Check if the form data is submitted
if (isset($_POST['new_password'], $_POST['confirm_password'])) {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    // Check if the new password and confirm password match
    if ($newPassword !== $confirmPassword) {
        echo '<script>';
        echo 'alert("Password do not match. Please try again.");';
        echo 'window.location.href = "Password_Update.html";';
        echo '</script>';
        exit();
    }
    
    // Check if the new password is the same as the current password
    if (password_verify($newPassword, $currentPassword)) {
        // New password matches the current password
        echo '<script>';
        echo 'alert("The new password is the same as the current password. Please choose a different one.");';
        echo 'window.location.href = "Password_Update.html";'; // Redirect back to the password update page
        echo '</script>';
        exit(); // Stop the script to prevent further execution
    }

    


        // Update the password in the database
        $stmt = $con->prepare('UPDATE students SET password = ? WHERE student_id = ?');
        $stmt->bind_param('si', $newPassword, $_SESSION['student_id']); // 's' for string (password), 'i' for integer (user id)
        $stmt->execute();

    // Check if the update was successful
    if ($stmt->affected_rows > 0) {
        echo '<script>';
        echo 'alert("Password updated successfully.");';
        echo 'window.location.href = "profile.php";';
        echo '</script>';
        exit();
    } 

    else {
        echo '<script>';
        echo 'alert("Failed to update password. Please try again.");';
        echo 'window.location.href = "profile.php";';
        echo '</script>';
        exit();
    }
}
?>
