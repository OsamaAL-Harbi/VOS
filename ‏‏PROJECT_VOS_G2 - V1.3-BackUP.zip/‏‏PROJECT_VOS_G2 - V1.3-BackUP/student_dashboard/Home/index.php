<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voice of Student - Login</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css"> <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="../CSS/style.css"> <!-- Link to your CSS file -->
</head>
<style>
    /* General Reset */
* {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
    font-size: 16px;
    margin: 0;
    padding: 0;
}

/* Body Styling */
body {
    background-color: #435165; /* Background color for the page */
    color: #5b6574; /* Default text color */
    line-height: 1.6;
}

/* Login Container */
.login {
    width: 400px; /* Fixed width for the login form */
    background-color: #ffffff; /* White background for the form */
    box-shadow: 0 0 9px 0 rgba(0, 0, 0, 0.3); /* Subtle shadow effect */
    margin: 100px auto; /* Center the form vertically and horizontally */
    padding: 20px; /* Padding inside the form */
    border-radius: 8px; /* Rounded corners */
}

/* Login Heading */
.login h1 {
    text-align: center; /* Center-align the heading */
    color: #5b6574; /* Text color */
    font-size: 24px; /* Font size */
    padding: 20px 0; /* Padding above and below the heading */
    border-bottom: 1px solid #dee0e4; /* Bottom border */
}

/* Input Group */
.input-group {
    display: flex;
    align-items: center; /* Align items vertically in the center */
    margin-bottom: 20px; /* Spacing below each input group */
}

/* Input Labels (Icons) */
.input-group label {
    display: flex;
    justify-content: center; /* Center the icon horizontally */
    align-items: center; /* Center the icon vertically */
    width: 50px; /* Fixed width for the icon container */
    height: 50px; /* Fixed height for the icon container */
    background-color: #3274d6; /* Blue background for the icon */
    color: #ffffff; /* White color for the icon */
    border-radius: 4px 0 0 4px; /* Rounded corners on the left side */
}

/* Input Fields */
.input-group input[type="text"],
.input-group input[type="password"] {
    flex: 1; /* Allow the input to take up remaining space */
    height: 50px; /* Height of the input fields */
    border: 1px solid #dee0e4; /* Border color */
    padding: 0 15px; /* Padding inside the input fields */
    border-radius: 0 4px 4px 0; /* Rounded corners on the right side */
    font-size: 16px; /* Font size */
}

/* Password Container */
.password-container {
    position: relative; /* Required for positioning the button */
}

/* Show Password Button */
.show-password-button {
    position: absolute; /* Position the button inside the input group */
    right: 0; /* Align to the right */
    top: 0; /* Align to the top */
    height: 50px; /* Match the height of the input field */
    width: 50px; /* Fixed width for the button */
    background-color: #5b6574; /* Neutral gray background */
    color: #ffffff; /* White text */
    border: 0; /* No border */
    border-radius: 0 4px 4px 0; /* Rounded corners on the right side */
    cursor: pointer; /* Pointer cursor on hover */
    display: flex; /* Use flexbox to center the icon */
    justify-content: center; /* Center the icon horizontally */
    align-items: center; /* Center the icon vertically */
    transition: background-color 0.2s; /* Smooth hover transition */
    box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
}

.show-password-button:hover {
    background-color: #4a536e; /* Slightly darker gray on hover */
    transition: background-color 0.2s; /* Smooth hover transition */
}

/* Submit Button */
.login form input[type="submit"] {
    width: 100%; /* Full-width button */
    padding: 15px; /* Padding inside the button */
    margin-top: 20px; /* Spacing above the button */
    background-color: #3274d6; /* Blue background */
    border: 0; /* No border */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    font-weight: bold; /* Bold text */
    color: #ffffff; /* White text */
    transition: background-color 0.2s; /* Smooth hover transition */
}

.login form input[type="submit"]:hover {
    background-color: #2868c7; /* Slightly darker blue on hover */
    transition: background-color 0.2s; /* Smooth hover transition */
}

/* Forgot Password Button */
.forgot-password-button {
    width: 100%; /* Full-width button */
    padding: 15px; /* Padding inside the button */
    margin-top: 10px; /* Spacing above the button */
    background-color: #5b6574; /* Neutral gray background */
    color: #ffffff; /* White text */
    border: 0; /* No border */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    font-weight: bold; /* Bold text */
    font-size: 16px; /* Font size */
    text-align: center; /* Center-align the text */
    transition: background-color 0.2s; /* Smooth hover transition */
    box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
}

.forgot-password-button:hover {
    background-color: #4a536e; /* Slightly darker gray on hover */
    transition: background-color 0.2s; /* Smooth hover transition */
}

/* Error Message */
.error-message {
    background-color: #ffebee; /* Light red background */
    color: #c62828; /* Red text */
    padding: 10px; /* Padding inside the error message */
    margin-bottom: 20px; /* Spacing below the error message */
    border: 1px solid #ffcdd2; /* Red border */
    border-radius: 4px; /* Rounded corners */
    text-align: center; /* Center-align the text */
    font-size: 14px; /* Font size */
}
</style>
<body>
    <div class="login">
        <h1>Login</h1>

        <!-- Error Message (Optional) -->
        <?php if (isset($_GET['error'])): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <form action="authenticate.php" method="post">
            <!-- ID Field -->
            <label for="ID" aria-label="ID Icon">
                <i class="fas fa-user"></i>
            </label>
            <input 
                type="text" 
                name="student_id" 
                placeholder="ID" 
                id="ID" 
                required 
                autocomplete="off"
            >

            <!-- Password Field with Show/Hide Button -->
            <label for="password" aria-label="Password Icon">
                <i class="fas fa-lock"></i>
            </label>
            <div class="password-container">
                <input 
                    type="password" 
                    name="password" 
                    placeholder="Password" 
                    id="password" 
                    required 
                    autocomplete="off"
                >
                <button 
                    type="button" 
                    class="show-password-button" 
                    onclick="togglePasswordVisibility()"
                    aria-label="Toggle Password Visibility"
                >
                    <i class="fas fa-eye"></i> <!-- Default icon is "eye" -->
                </button>
            </div>

            <!-- Submit Button -->
            <input type="submit" value="Login">

            <!-- Forgot Password Link -->
            <button 
                type="button" 
                class="forgot-password-button" 
                onclick="location.href='../../OTP/request_otp/index.html'" 
                aria-label="Forgot Password"
            >
                Forgot Password?
            </button>
        </form>
    </div>

    <!-- JavaScript for Password Visibility Toggle -->
    <script>
        function togglePasswordVisibility() {
            const passwordField = document.getElementById('password');
            const showPasswordButton = document.querySelector('.show-password-button i');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                showPasswordButton.classList.remove('fa-eye'); // Remove "eye" icon
                showPasswordButton.classList.add('fa-eye-slash'); // Add "eye-slash" icon
            } else {
                passwordField.type = 'password';
                showPasswordButton.classList.remove('fa-eye-slash'); // Remove "eye-slash" icon
                showPasswordButton.classList.add('fa-eye'); // Add "eye" icon
            }
        }
    </script>
</body>
</html>