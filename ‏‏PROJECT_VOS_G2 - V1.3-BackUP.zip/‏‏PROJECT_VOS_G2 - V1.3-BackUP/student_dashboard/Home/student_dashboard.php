<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "Root";
$dbname = "faculty";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error, ENT_QUOTES));
}

// Ensure student_id is set in the session
$student_id = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Voice of Student</title>
    <link href="../CSS/style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <style>
        /* General Card Styling */
        .card {
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            margin-bottom: 24px;
            padding: 24px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
        }

        .card h3 {
            margin: 0 0 16px 0;
            font-size: 20px;
            color: #2c3e50;
            font-weight: 600;
        }

        .card p {
            margin: 0 0 16px 0;
            color: #5b6574;
            line-height: 1.5;
        }

        .download-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            background-color: #4361ee;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
            font-weight: 500;
        }

        .download-button:hover {
            background-color: #3a56d4;
            transform: translateY(-1px);
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 1000;
            width: 85%;
            max-width: 900px;
            height: 85%;
            background-color: white;
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .modal-content {
            width: 100%;
            height: 100%;
        }

        .modal iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        /* Overlay Styling */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(4px);
            z-index: 999;
        }

        /* Close Button Styling */
        .close-modal {
            position: absolute;
            top: 16px;
            right: 16px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            cursor: pointer;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1001;
            transition: all 0.2s;
        }

        .close-modal:hover {
            background-color: #e04444;
            transform: rotate(90deg);
        }
        
        /* Chatbot Button Styling */
        .chatbot-button {
            position: fixed;
            bottom: 32px;
            right: 32px;
            width: 64px;
            height: 64px;
            background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
            color: white;
            border-radius: 50%;
            text-align: center;
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.3);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: none;
        }
        
        .chatbot-button:hover {
            transform: scale(1.1) rotate(10deg);
            box-shadow: 0 8px 25px rgba(67, 97, 238, 0.4);
        }
        
        .chatbot-button i {
            font-size: 28px;
        }
        
        /* Chatbot Modal */
        .chatbot-modal {
            display: none;
            position: fixed;
            bottom: 112px;
            right: 32px;
            width: 380px;
            height: 560px;
            background-color: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            z-index: 101;
            flex-direction: column;
            overflow: hidden;
            transform: translateY(20px);
            opacity: 0;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .chatbot-modal.active {
            transform: translateY(0);
            opacity: 1;
        }
        
        .chatbot-header {
            background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
            color: white;
            padding: 18px 24px;
            font-weight: 600;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .chatbot-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            font-size: 18px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        
        .chatbot-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: rotate(90deg);
        }
        
        .chatbot-body {
            flex: 1;
            padding: 16px;
            overflow-y: auto;
            background-color: #f8f9fa;
            scrollbar-width: thin;
            scrollbar-color: #4361ee #f8f9fa;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .chatbot-body::-webkit-scrollbar {
            width: 6px;
        }
        
        .chatbot-body::-webkit-scrollbar-track {
            background: #f8f9fa;
        }
        
        .chatbot-body::-webkit-scrollbar-thumb {
            background-color: #4361ee;
            border-radius: 3px;
        }
        
        .chatbot-footer {
            padding: 16px;
            border-top: 1px solid rgba(0, 0, 0, 0.05);
            display: flex;
            background-color: white;
        }
        
        .chatbot-input {
            flex: 1;
            padding: 12px 16px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 24px;
            outline: none;
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .chatbot-input:focus {
            border-color: #4361ee;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        .chatbot-send {
            margin-left: 12px;
            background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
            color: white;
            border: none;
            border-radius: 50%;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .chatbot-send:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(67, 97, 238, 0.3);
        }
        
        /* Welcome message styling */
        .welcome-message {
            text-align: center;
            color: #666;
            margin: auto;
            padding: 24px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .welcome-message i {
            font-size: 48px;
            color: #4361ee;
            margin-bottom: 16px;
            opacity: 0.8;
        }
        
        /* Typing indicator */
        .typing-indicator {
            display: flex;
            align-items: center;
            margin: 8px 0;
            padding: 12px 16px;
            background-color: #f1f1f1;
            border-radius: 18px;
            width: fit-content;
            max-width: 80%;
        }
        
        .typing-dot {
            width: 8px;
            height: 8px;
            background-color: #666;
            border-radius: 50%;
            margin: 0 2px;
            animation: typingAnimation 1.4s infinite ease-in-out;
        }
        
        .typing-dot:nth-child(1) {
            animation-delay: 0s;
        }
        
        .typing-dot:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-dot:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        /* Quick Select Styles */
        .quick-select-container {
            padding: 10px;
            background: #f8f9fa;
            border-radius: 12px;
            margin: 10px 0;
        }

        .quick-select-btn {
            padding: 6px 12px;
            border-radius: 16px;
            border: 1px solid #4361ee;
            background: transparent;
            color: #4361ee;
            cursor: pointer;
            font-size: 0.8em;
            transition: all 0.2s;
            margin: 3px;
        }

        .quick-select-btn:hover {
            background: #4361ee;
            color: white;
        }

        /* Responsive adjustments */
        @media (max-width: 600px) {
            .quick-select-container {
                flex-direction: column;
            }
            
            .quick-select-btn {
                width: 100%;
            }
        }
        @keyframes typingAnimation {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-5px); }
        }
    </style>
</head>

<body class="loggedin">
    <nav class="navtop">
        <div>
            <!-- Logo added here -->
            <a href="../../../logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>
            <h1>Voice of Student</h1>
            <a href="../Profile/profile.php"><i class="fas fa-user-circle"></i>Profile</a>
            <a href="../../phpsubmit/index.php"><i class="fas fa-arrow-right"></i>Submit Complaint</a>
            <a href="../track/track.php" class="track-link"><i class="fas fa-sign-out-alt"></i>Track</a>
            <a href="../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i>Logout</a>
        </div>
    </nav>

    <div class="content">
        <h2>Student Dashboard</h2>
        <p>Welcome back, <?= htmlspecialchars($_SESSION['name'], ENT_QUOTES) ?>!</p>

        <!-- Card with download button for the guide -->
        <div class="card">
            <h3>Download Guidelines</h3>
            <p>Click the button below to view or download the student guide in PDF format:</p>
            <button id="viewPdfButton" class="download-button">
                <i class="fas fa-eye"></i> View PDF Guide
            </button>
        </div>

        <!-- Modal for displaying the PDF -->
        <div id="pdfModal" class="modal">
            <button id="closeModalButton" class="close-modal">×</button>
            <div class="modal-content">
                <iframe src="../../Guidelines.pdf"></iframe>
            </div>
        </div>

        <!-- Overlay for the modal -->
        <div id="overlay" class="overlay"></div>
    </div>
    
    <!-- Chatbot Button -->
    <button class="chatbot-button" id="chatbotButton" aria-label="Open chatbot">
        <i class="fas fa-robot"></i>
    </button>
    
    <!-- Chatbot Modal -->
    <div class="chatbot-modal" id="chatbotModal">
        <div class="chatbot-header">
            <span>VOS Support Bot</span>
            <button class="chatbot-close" id="chatbotClose" aria-label="Close chatbot">×</button>
        </div>
        <div class="chatbot-body" id="chatbotBody">
            <!-- Welcome message -->
            <div class="welcome-message">
                <i class="fas fa-robot"></i>
                <h3>Hello! I'm your VOS Support Bot</h3>
                <p>How can I help you today? You can ask me about complaints, guidelines, or general help.</p>
            </div>
        </div>
        <div class="chatbot-footer">
            <input type="text" class="chatbot-input" id="chatbotInput" placeholder="Type your question..." aria-label="Type your message">
            <button class="chatbot-send" id="chatbotSend" aria-label="Send message">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
</body>
<script>
    // Improved query parameter parsing
    function getQueryParams() {
        return Object.fromEntries(
            new URLSearchParams(window.location.search).entries()
        );
    }

    // Modal functionality with better accessibility
    const viewPdfButton = document.getElementById('viewPdfButton');
    const pdfModal = document.getElementById('pdfModal');
    const closeModalButton = document.getElementById('closeModalButton');
    const overlay = document.getElementById('overlay');

    function openModal() {
        pdfModal.style.display = 'block';
        overlay.style.display = 'block';
        document.body.style.overflow = 'hidden';
        closeModalButton.focus();
    }

    function closeModal() {
        pdfModal.style.display = 'none';
        overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
        viewPdfButton.focus();
    }

    viewPdfButton.addEventListener('click', openModal);
    closeModalButton.addEventListener('click', closeModal);
    overlay.addEventListener('click', closeModal);

    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && pdfModal.style.display === 'block') {
            closeModal();
        }
    });

    // Enhanced Chatbot with better state management
    const chatbot = {
        elements: {
            button: document.getElementById('chatbotButton'),
            modal: document.getElementById('chatbotModal'),
            close: document.getElementById('chatbotClose'),
            body: document.getElementById('chatbotBody'),
            input: document.getElementById('chatbotInput'),
            send: document.getElementById('chatbotSend')
        },
        state: {
            isOpen: false,
            typing: false
        },
        messages: {
            predefined: {
                GREETING: ["Hello!", "مرحباً", "Hi there!"],
                COMPLAINT: ["How do I submit a complaint?", "كيف أقدم شكوى؟", "Complaint process"],
                GRADES: ["When will grades be available?", "متى ستكون الدرجات متاحة؟", "Grade inquiry"],
                DEADLINE: ["What's the deadline for complaints?", "ما هو الموعد النهائي لتقديم الشكاوى؟", "Important dates"],
                HELP: ["What can you help me with?", "بماذا يمكنك مساعدتي؟", "Show help options"]
            },
            welcome: {
                title: "Hello! I'm your VOS Support Bot",
                text: "How can I help you today? You can ask me about complaints, guidelines, or general help."
            }
        },
        init() {
            this.setupEventListeners();
            this.renderWelcomeMessage();
        },
        setupEventListeners() {
            // Toggle chatbot
            this.elements.button.addEventListener('click', () => this.toggleChatbot());
            
            // Close chatbot
            this.elements.close.addEventListener('click', () => this.closeChatbot());
            
            // Send message on button click or Enter key
            this.elements.send.addEventListener('click', () => this.handleSendMessage());
            this.elements.input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.handleSendMessage();
            });
            
            // Focus management when opening/closing
            this.elements.modal.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') this.closeChatbot();
            });
        },
        toggleChatbot() {
            if (this.state.isOpen) {
                this.closeChatbot();
            } else {
                this.openChatbot();
            }
        },
        openChatbot() {
            this.state.isOpen = true;
            this.elements.modal.style.display = 'flex';
            setTimeout(() => {
                this.elements.modal.classList.add('active');
                this.elements.input.focus();
            }, 10);
            this.initQuickSelect();
        },
        closeChatbot() {
            this.state.isOpen = false;
            this.elements.modal.classList.remove('active');
            setTimeout(() => {
                this.elements.modal.style.display = 'none';
            }, 300);
        },
        renderWelcomeMessage() {
            const welcomeDiv = document.createElement('div');
            welcomeDiv.className = 'welcome-message';
            welcomeDiv.innerHTML = `
                <i class="fas fa-robot"></i>
                <h3>${this.messages.welcome.title}</h3>
                <p>${this.messages.welcome.text}</p>
            `;
            this.elements.body.appendChild(welcomeDiv);
        },
        initQuickSelect() {
            const container = document.createElement('div');
            container.className = 'quick-select-container';
            
            Object.entries(this.messages.predefined).forEach(([category, messages]) => {
                messages.forEach(msg => {
                    const button = document.createElement('button');
                    button.className = 'quick-select-btn';
                    button.textContent = msg;
                    button.addEventListener('click', () => {
                        this.elements.input.value = msg;
                        this.handleSendMessage();
                    });
                    container.appendChild(button);
                });
            });
            
            const welcomeMsg = this.elements.body.querySelector('.welcome-message');
            if (welcomeMsg) {
                welcomeMsg.after(container);
            } else {
                this.elements.body.prepend(container);
            }
        },
        async handleSendMessage() {
            const message = this.elements.input.value.trim();
            if (!message) return;
            
            this.addMessage(message, 'user');
            this.elements.input.value = '';
            
            // Show typing indicator
            this.showTypingIndicator();
            
            // Simulate processing delay
            await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 800));
            
            // Remove typing indicator and send response
            this.removeTypingIndicator();
            const response = this.generateResponse(message);
            this.addMessage(response, 'bot');
        },
        showTypingIndicator() {
            this.state.typing = true;
            const typingDiv = document.createElement('div');
            typingDiv.className = 'typing-indicator';
            typingDiv.innerHTML = `
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            `;
            this.elements.body.appendChild(typingDiv);
            this.scrollToBottom();
        },
        removeTypingIndicator() {
            this.state.typing = false;
            const indicator = this.elements.body.querySelector('.typing-indicator');
            if (indicator) indicator.remove();
        },
        addMessage(text, sender) {
            // Remove welcome message if it's the first user message
            if (sender === 'user') {
                const welcomeMsg = this.elements.body.querySelector('.welcome-message');
                if (welcomeMsg) welcomeMsg.remove();
            }
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${sender}`;
            messageDiv.style.display = 'flex';
            messageDiv.style.margin = '8px 0';
            messageDiv.style.flexDirection = sender === 'user' ? 'row-reverse' : 'row';
            messageDiv.style.opacity = '0';
            messageDiv.style.transform = sender === 'user' ? 'translateX(20px)' : 'translateX(-20px)';
            messageDiv.style.transition = 'all 0.3s ease-out';
            
            const bubble = document.createElement('div');
            bubble.className = 'message-bubble';
            bubble.textContent = text;
            
            messageDiv.appendChild(bubble);
            this.elements.body.appendChild(messageDiv);
            
            // Animate message appearance
            setTimeout(() => {
                messageDiv.style.opacity = '1';
                messageDiv.style.transform = 'translateX(0)';
                this.scrollToBottom();
            }, 10);
        },
        scrollToBottom() {
            this.elements.body.scrollTo({
                top: this.elements.body.scrollHeight,
                behavior: 'smooth'
            });
        },
        generateResponse(userMessage) {
            // Check if this is a predefined message
            const isPredefined = Object.values(this.messages.predefined)
                .flat()
                .includes(userMessage);
            
            if (isPredefined) {
                return this.getPredefinedResponse(userMessage);
            }
            
            return this.getDynamicResponse(userMessage);
        },
        getPredefinedResponse(message) {
            // Greetings
            if (this.messages.predefined.GREETING.includes(message)) {
                return `Thank you for your greeting! How can I assist you with academic services today? 
                        / شكرًا على التحية! كيف يمكنني مساعدتك في الخدمات الأكاديمية اليوم؟`;
            }
            
            // Complaints
            if (this.messages.predefined.COMPLAINT.includes(message)) {
                return `Complaint Process:
1. Discuss with instructor first
2. If unresolved, contact advisor within 1 week
3. Submit formally via Voice of Student system
                        
عملية الشكوى:
1. ناقش مع الأستاذ أولاً
2. إذا لم يتم الحل، اتصل بالمرشد خلال أسبوع
3. قدمها رسميًا عبر نظام صوت الطالب`;
            }
            
            // Grades
            if (this.messages.predefined.GRADES.includes(message)) {
                return `Grade Release Timeline:
- Year work: Within 2 weeks after submission
- Midterms: Within 2 weeks after exams
- Finals: First week of next semester
                        
مواعيد إعلان الدرجات:
- أعمال السنة: خلال أسبوعين من التسليم
- منتصف الفصل: خلال أسبوعين بعد الاختبارات
- النهائية: الأسبوع الأول من الفصل التالي`;
            }
            
            // Deadlines
            if (this.messages.predefined.DEADLINE.includes(message)) {
                return `Important Deadlines:
- Year work complaints: 1 week after grades
- Midterm complaints: 2 weeks after exams
- Final exam complaints: 1st week next semester
                        
المواعيد النهائية المهمة:
- شكاوى أعمال السنة: أسبوع بعد الدرجات
- شكاوى منتصف الفصل: أسبوعان بعد الاختبارات
- شكاوى النهائية: الأسبوع الأول الفصل التالي`;
            }
            
            // Help
            if (this.messages.predefined.HELP.includes(message)) {
                return `I can help with:
1. Complaint procedures / إجراءات الشكوى
2. Grade inquiries / استفسارات الدرجات
3. Deadline information / معلومات المواعيد
4. Academic guidelines / الإرشادات الأكاديمية

For detailed help, select a specific option above.
/ للحصول على مساعدة مفصلة، اختر أحد الخيارات أعلاه.`;
            }
            
            return this.getDynamicResponse(message);
        },
        getDynamicResponse(userMessage) {
            const lowerMsg = userMessage.toLowerCase();
            
            // Greetings
            if (/(hello|hi|hey|greetings|sup|مرحبا|اهلا|السلام عليكم|سلام)/i.test(lowerMsg)) {
                const greetings = [
                    "Hello there! How can I assist you today? / مرحبًا! كيف يمكنني مساعدتك اليوم؟",
                    "Hi! What can I help you with? / أهلاً! كيف يمكنني مساعدتك؟",
                    "السلام عليكم! كيف يمكنني مساعدتك اليوم؟ / Peace be upon you! How can I help you today?"
                ];
                return greetings[Math.floor(Math.random() * greetings.length)];
            }
            
            // Goodbyes
            if (/(bye|goodbye|see you|later|مع السلامة|الى اللقاء|وداعا)/i.test(lowerMsg)) {
                const goodbyes = [
                    "Goodbye! Feel free to come back if you have more questions. / مع السلامة! لا تتردد في العودة إذا كان لديك المزيد من الأسئلة",
                    "See you later! / إلى اللقاء!",
                    "مع السلامة! تواصل معنا إذا احتجت مساعدة / Goodbye! Contact us if you need help"
                ];
                return goodbyes[Math.floor(Math.random() * goodbyes.length)];
            }
            
            // Default responses
            const defaultResponses = [
                "I didn't understand. Could you rephrase? / لم أفهم. هل يمكنك إعادة الصياغة؟",
                "I help with complaints, grades, and guidelines. / أساعد في الشكاوى والدرجات والإرشادات",
                "For specific questions, contact your advisor. / للأسئلة المحددة، اتصل بمرشدك",
                "Check the guidelines PDF for official procedures. / راجع دليل PDF للإجراءات الرسمية"
            ];
            
            return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
        }
    };

    // Initialize the chatbot when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        chatbot.init();
        
        // Check for any query parameters that might require special handling
        const params = getQueryParams();
        if (params.chat === 'open') {
            chatbot.openChatbot();
        }
    });
</script>
</html>