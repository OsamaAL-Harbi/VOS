<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "Root";
$dbname = "faculty";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;

// Fetch all complaints for the logged-in student (including Cancelled)
if ($student_id) {
    $query = "SELECT * FROM complaints WHERE complainant_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

$conn->close();

/**
 * Get the CSS class for the status based on the status value.
 * @param {string} $status - The status of the complaint.
 * @returns {string} - The CSS class for the status.
 */
function getStatusClass($status) {
    switch ($status) {
        case 'Submited':
            return 'status-submitted';
        case 'Cancelled':
            return 'status-cancelled';
        case 'Resolved':
            return 'status-resolved';
        case 'In_progress':
            return 'status-in-progress';
        default:
            return '';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Complaints</title>
    <link href="../../CSS/all_complaints.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* CSS Variables */
        :root {
            --primary-color: #3274d6;
            --secondary-color: #5b6574;
            --text-color: #333;
            --background-color: #f4f4f9;
            --border-color: #ccc;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --hover-color: #2868c7;
            --error-color: #ff4757;
            --success-color: #2ed573;
            --warning-color: #ffa502;
        }

        /* Body Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navigation Bar */
        .navtop {
            background-color: #2f3947;
            height: 60px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navtop div {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            height: 100%;
        }

        .navtop div h1 {
            flex: 1;
            font-size: 24px;
            color: #eaebed;
            font-weight: normal;
            margin: 0;
        }

        .navtop div a {
            padding: 0 20px;
            text-decoration: none;
            color: #c1c4c8;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .navtop div a:hover,
        .navtop div a:focus {
            color: #eaebed;
        }

        .logout-link:hover,
        .logout-link:focus {
            color: #e74c3c;
        }

        /* Content Section */
        .content {
            flex: 1;
            width: 100%;
            max-width: 1200px;
            margin: 80px auto 0;
            padding: 20px;
        }

        .content h2 {
            margin-bottom: 20px;
            font-size: 28px;
            color: var(--secondary-color);
        }

        /* Complaint Containers */
        .complaint-container {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: var(--box-shadow);
            cursor: pointer;
            transition: transform 0.2s ease;
        }

        .complaint-container:hover {
            transform: translateY(-5px);
        }

        .complaint-container p {
            margin: 5px 0;
        }

        .complaint-details {
            display: none;
            padding: 10px;
            background-color: #f9f9f9;
            border-top: 1px solid var(--border-color);
            margin-top: 10px;
        }

        .complaint-details.open {
            display: block;
        }

        /* Status Colors */
        .status-submitted {
            color: #ffc107; /* Yellow */
        }

        .status-cancelled {
            color: #dc3545; /* Red */
        }

        .status-resolved {
            color: #28a745; /* Green */
        }

        .status-in-progress {
            color: #17a2b8; /* Teal */
        }

        /* Buttons */
        .cancel-btn {
            background-color: var(--error-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .cancel-btn:hover {
            background-color: #e74c3c;
        }

        /* Alert Styling */
        .alert {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            font-family: Arial, sans-serif;
            z-index: 1000;
        }

        .alert-success {
            background-color: var(--success-color);
            color: white;
        }

        .alert-error {
            background-color: var(--error-color);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navtop">
        <div>
            <!-- Logo added here -->
                <img src="../../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
        
            <h1>Voice of Student</h1>
            <div>
                <a href="../../Home/student_dashboard.php"><i class="fas fa-home"></i> Home</a>
                <a href="../../Profile/profile.php"><i class="fas fa-user-circle"></i> Profile</a>
                <a href="../track.php"><i class="fas fa-search"></i> Track</a>
                <a href="../../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </nav>

    <div id="alert-container"></div>
    <div class="content">
        <h2>All Complaints</h2>
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success">Complaint canceled successfully!</div>
        <?php elseif (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <div class="alert alert-error">Failed to cancel the complaint. Please try again.</div>
        <?php elseif (isset($_GET['error']) && $_GET['error'] == 2): ?>
            <div class="alert alert-error">This complaint cannot be canceled because its status is not "Submited".</div>
        <?php elseif (isset($_GET['error']) && $_GET['error'] == 3): ?>
            <div class="alert alert-error">Complaint not found or you do not have permission to cancel it.</div>
        <?php endif; ?>

        <div class="complaints-list">
            <?php if ($student_id && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="complaint-container" onclick="toggleDetails(<?= $row['complaint_id']; ?>)" aria-expanded="false">
                        <p><strong>Type:</strong> <?= htmlspecialchars($row['complaint_type']); ?></p>
                        <p><strong>Course:</strong> <?= htmlspecialchars($row['course_name']); ?></p>
                        <p><strong>Status:</strong> 
                            <span class="<?= getStatusClass($row['status']); ?>">
                                <?= htmlspecialchars($row['status']); ?>
                            </span>
                        </p>
                        <div class="complaint-details" id="details-<?= $row['complaint_id']; ?>">
                            <p><strong>Description:</strong> <?= htmlspecialchars($row['complaint_description']); ?></p>
                            <p><strong>Created At:</strong> <?= $row['created_at']; ?></p>
                            <?php if ($row['status'] === 'Submited'): ?>
                                <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this complaint?');">
                                    <input type="hidden" name="complaint_id" value="<?= $row['complaint_id']; ?>">
                                    <button type="submit" name="cancel_complaint" class="cancel-btn">Cancel Complaint</button>
                                </form>
                            <?php elseif ($row['status'] === 'Cancelled'): ?>
                                <p><strong>This complaint is already cancelled.</strong></p>
                            <?php else: ?>
                                <p><strong>This complaint cannot be canceled because its status is "<?= htmlspecialchars($row['status']); ?>".</strong></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No complaints available.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        /**
         * Toggle complaint details with smooth animation.
         * @param {number} complaintId - The ID of the complaint to toggle.
         */
        function toggleDetails(complaintId) {
            const details = document.getElementById(`details-${complaintId}`);
            const container = details.closest('.complaint-container');
            const isOpen = details.classList.toggle('open');
            container.setAttribute('aria-expanded', isOpen);
        }
    </script>
</body>
</html>