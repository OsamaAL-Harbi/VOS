<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: index.html');
    exit;
}

$servername = "localhost";
$username = "root";
$password = "Root";
$dbname = "faculty";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;

// Handle closing a complaint
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['close_complaint'])) {
    $complaint_id = intval($_POST['complaint_id']);

    // Fetch the current status of the complaint before updating
    $status_query = "SELECT status FROM complaints WHERE complaint_id = ? AND complainant_id = ?";
    $stmt_status = $conn->prepare($status_query);
    $stmt_status->bind_param("ii", $complaint_id, $student_id);
    $stmt_status->execute();
    $result_status = $stmt_status->get_result();

    if ($result_status->num_rows > 0) {
        $row_status = $result_status->fetch_assoc();
        $current_status = $row_status['status'];

        // Allow closing only if the status is "Submited" (single "t")
        if ($current_status === 'Submited') {
            $update_query = "UPDATE complaints SET status = 'Cancelled', active_complaints = 0 WHERE complaint_id = ? AND complainant_id = ?";
            $stmt_update = $conn->prepare($update_query);
            $stmt_update->bind_param("ii", $complaint_id, $student_id);

            if ($stmt_update->execute()) {
                error_log("Complaint $complaint_id updated successfully.");
                header("Location: track.php?success=1"); // Pass success flag
                exit;
            } else {
                error_log("Error updating complaint $complaint_id: " . $stmt_update->error);
                header("Location: track.php?error=1"); // Pass error flag
                exit;
            }

            $stmt_update->close();
        } else {
            error_log("Attempted to close complaint $complaint_id with invalid status: $current_status");
            header("Location: track.php?error=2"); // Invalid status error
            exit;
        }
    } else {
        error_log("Complaint $complaint_id not found for student $student_id");
        header("Location: track.php?error=3"); // Complaint not found error
        exit;
    }

    $stmt_status->close();
}

// Fetch complaints for the logged-in student
if ($student_id) {
    $query = "SELECT * FROM complaints WHERE complainant_id = ? AND active_complaints = 1 ORDER BY created_at DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Complaints</title>
    <link href="../CSS/track.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
    <nav class="navtop">
        <div>
            <!-- Logo added here -->
            <a href="/logo.png" class="logo">
                <img src="../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
            </a>

            <h1>Voice of Student</h1>
            <div>
                <a href="../Home/student_dashboard.php"><i class="fas fa-home"></i>Home</a>
                <a href="../Profile/profile.php"> <i class="fas fa-user-circle"></i> Profile</a>
                <a href="Track_previous/all_complaints.php"><i class="fas fa-list"></i>All Complaints</a>
                <a href="../track/Complaint_Decision/complaint_decisions.php" aria-label="Complaint Decisions">
                    <i class="fas fa-check-circle"></i> Complaint Decisions
                </a>
                <a href="../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> Logout</a>               
            </div>
        </div>
    </nav>

    <div class="content">
        <h2>Your Complaints</h2>
        <div class="complaints-list">
            <?php if ($student_id && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="complaint-container" onclick="toggleDetails(<?= $row['complaint_id']; ?>)" aria-expanded="false">
                        <p><strong>Type:</strong> <?= htmlspecialchars($row['complaint_type']); ?></p>
                        <p><strong>Course:</strong> <?= htmlspecialchars($row['course_name']); ?></p>
                        <p><strong>Status:</strong> 
                            <span style="color: 
                                <?php 
                                    switch ($row['status']) {
                                        case 'Submited':
                                            echo '#ffc107'; // Yellow for Submitted
                                            break;
                                        case 'In_progress':
                                            echo '#17a2b8'; // Teal for In Progress
                                            break;
                                        case 'Resolved':
                                            echo '#28a745'; // Green for Resolved
                                            break;
                                        case 'Cancelled':
                                            echo '#dc3545'; // Red for Cancelled
                                            break;
                                        default:
                                            echo '#6c757d'; // Gray for unknown status
                                    }
                                ?>;">
                                <?= htmlspecialchars($row['status']); ?>
                            </span>
                        </p>
                        <div class="complaint-details" id="details-<?= $row['complaint_id']; ?>">
                            <p><strong>Description:</strong> <?= htmlspecialchars($row['complaint_description']); ?></p>
                            <p><strong>Created At:</strong> <?= $row['created_at']; ?></p>
                            <?php if ($row['status'] === 'Submited'): ?>
                                <form method="POST" onsubmit="return confirm('Are you sure you want to Cancel this complaint?');">
                                    <input type="hidden" name="complaint_id" value="<?= $row['complaint_id']; ?>">
                                    <button type="submit" name="close_complaint" class="close-btn"> Cancel Complaint</button>
                                </form>
                            <?php elseif ($row['status'] === 'Cancelled'): ?>
                                <p><strong>This complaint is already cancelled.</strong></p>
                            <?php else: ?>
                                <p><strong>This complaint cannot be cancelled because its status is "<?= htmlspecialchars($row['status']); ?>".</strong></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No complaints available.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        /**
         * Toggle complaint details with smooth animation.
         * @param {number} complaintId - The ID of the complaint to toggle.
         */
        function toggleDetails(complaintId) {
            const details = document.getElementById(`details-${complaintId}`);
            const container = details.closest('.complaint-container');
            const isOpen = details.classList.toggle('open');
            container.setAttribute('aria-expanded', isOpen);
        }
    </script>
</body>
</html>