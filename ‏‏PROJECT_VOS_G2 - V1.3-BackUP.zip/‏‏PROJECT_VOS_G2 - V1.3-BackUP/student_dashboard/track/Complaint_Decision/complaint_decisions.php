<?php
session_start();

// Database configuration
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'root';
$DATABASE_PASS = 'Root';
$DATABASE_NAME = 'faculty';

try {
    // Create a PDO connection
    $pdo = new PDO("mysql:host=$DATABASE_HOST;dbname=$DATABASE_NAME;charset=utf8", $DATABASE_USER, $DATABASE_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}

// Redirect to login if not authenticated
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

/**
 * Marks a complaint action as "read" in the database.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param int $complaint_id The ID of the complaint to mark as read.
 * @throws Exception If the database update fails.
 */
function markActionAsRead(PDO $pdo, int $complaint_id): void {
    try {
        // Validate the complaint ID
        if ($complaint_id <= 0) {
            throw new InvalidArgumentException('Invalid complaint ID.');
        }

        // Prepare the SQL query to update the complaint status
        $stmt = $pdo->prepare("UPDATE complaint_actions SET is_readed = 1 WHERE complaint_id = :complaint_id");

        // Bind the complaint ID parameter
        $stmt->bindParam(':complaint_id', $complaint_id, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Log success (optional)
        error_log("Complaint ID {$complaint_id} marked as read successfully.");
    } catch (PDOException $e) {
        // Log the error and rethrow an exception
        error_log('Database error marking complaint as read: ' . $e->getMessage());
        throw new Exception('Failed to mark complaint as read. Please try again later.');
    } catch (InvalidArgumentException $e) {
        // Log invalid input errors
        error_log('Invalid input error: ' . $e->getMessage());
        throw new Exception('Invalid complaint ID provided.');
    }
}

/**
 * Fetches all complaint actions (both read and unread) for a specific user, filtered by "Rejected" and "Resolved" actions.
 *
 * @param PDO $pdo The PDO database connection object.
 * @param int $student_id The ID of the student whose complaints are being fetched.
 * @return array An array of filtered complaint actions.
 */
function fetchAllComplaintActions(PDO $pdo, int $student_id): array {
    try {
        // Validate the student ID
        if ($student_id <= 0) {
            throw new InvalidArgumentException('Invalid student ID.');
        }

        // Prepare the SQL query to fetch only "Rejected" and "Resolved" complaints for the student
        $stmt = $pdo->prepare("
            SELECT ca.action_id, ca.complaint_id, ca.action_type, ca.action_by, ca.action_date,
                   ca.AA_comment, ca.HOD_comment, ca.MRC_comment, ca.AAU_comment, ca.is_readed
            FROM complaint_actions ca
            JOIN complaints c ON ca.complaint_id = c.complaint_id
            WHERE c.complainant_id = :student_id
            AND ca.action_type IN ('Rejected', 'Resolved')
        ");

        // Bind the student ID parameter
        $stmt->bindParam(':student_id', $student_id, PDO::PARAM_INT);

        // Execute the query
        $stmt->execute();

        // Fetch all results as an associative array
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Log the error and return an empty array
        error_log('Database error fetching complaint actions: ' . $e->getMessage());
        return [];
    } catch (InvalidArgumentException $e) {
        // Log invalid input errors
        error_log('Invalid input error: ' . $e->getMessage());
        return [];
    }
}

// Handle "Mark as Read" action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_as_read'])) {
    $complaint_id = filter_input(INPUT_POST, 'complaint_id', FILTER_VALIDATE_INT);
    if ($complaint_id > 0) {
        try {
            markActionAsRead($pdo, $complaint_id);
        } catch (Exception $e) {
            // Handle errors gracefully
            $_SESSION['error_message'] = $e->getMessage();
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Fetch all complaints for the logged-in student
$student_id = $_SESSION['student_id'];
$complaints = fetchAllComplaintActions($pdo, $student_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Decisions</title>
    <link href="../../CSS/complaint_decisions.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navtop">
        <img src="../../logo.png" alt="Logo" style="height: 40px; vertical-align: middle;">
        </a>
        <div>
            <h1>Voice of Student</h1>
        </div>
        <div>
            
            <a href="../../Home/student_dashboard.php"><i class="fas fa-home"></i> Home</a>
            <a href="../../Profile/profile.php"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="../Track_previous/all_complaints.php"><i class="fas fa-list"></i> All Complaints</a>
            <a href="../../../logout/logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i>Logout</a>
        </div>
    </nav>

    <h3>Complaint Decisions</h3>

    <?php if (!empty($_SESSION['error_message'])): ?>
        <p class="alert-error"><?= htmlspecialchars($_SESSION['error_message'], ENT_QUOTES) ?></p>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <?php if (empty($complaints)): ?>
        <p>No decisions available for your complaints.</p>
    <?php else: ?>
        <?php
        // Determine if HOD, MRC, and AAU comments should be shown
        $show_hod_comment = false;
        $show_mrc_comment = false;
        $show_aau_comment = false;
        $show_action = false;

        foreach ($complaints as $complaint) {
            if ($complaint['HOD_comment'] !== 'N/A' && !empty($complaint['HOD_comment'])) {
                $show_hod_comment = true;
            }
            if ($complaint['MRC_comment'] !== 'N/A' && !empty($complaint['MRC_comment'])) {
                $show_mrc_comment = true;
            }
            if ($complaint['AAU_comment'] !== 'N/A' && !empty($complaint['AAU_comment'])) {
                $show_aau_comment = true;
            }
            if (!$complaint['is_readed']) {
                $show_action = true;
            }
        }
        ?>
        <table>
            <thead>
                <tr>
                    <th>Complaint ID</th>
                    <th>Action Type</th>
                    <th>Action By</th>
                    <th>Action Date</th>
                    <th>AA Comment</th>
                    <?php if ($show_hod_comment): ?>
                        <th>HOD Comment</th>
                    <?php endif; ?>
                    <?php if ($show_mrc_comment): ?>
                        <th>MRC Comment</th>
                    <?php endif; ?>
                    <?php if ($show_aau_comment): ?>
                        <th>AAU Comment</th>
                    <?php endif; ?>
                    <th>Status</th>
                    <?php if ($show_action): ?>
                        <th>Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($complaints as $complaint): ?>
                    <tr>
                        <td><?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?></td>
                        <td>
                            <?php if ($complaint['action_type'] === 'Rejected'): ?>
                                <i class="fas fa-times-circle" style="color: red;"></i> Rejected
                            <?php elseif ($complaint['action_type'] === 'Resolved'): ?>
                                <i class="fas fa-check-circle" style="color: green;"></i> Resolved
                            <?php else: ?>
                                <?= htmlspecialchars($complaint['action_type'], ENT_QUOTES) ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            // Fetch faculty member's name based on action_by (assuming action_by is the faculty ID)
                            $action_by_id = $complaint['action_by'];
                            $faculty_name = 'Unknown'; // Default value
                            if ($action_by_id > 0) {
                                try {
                                    // Prepare the query to fetch faculty member's name
                                    $stmt = $pdo->prepare("SELECT first_name, last_name FROM faculty_members WHERE faculty_id = :faculty_id");
                                    $stmt->bindParam(':faculty_id', $action_by_id, PDO::PARAM_INT);
                                    $stmt->execute();
                                    $faculty = $stmt->fetch(PDO::FETCH_ASSOC);

                                    // If faculty member found, use their name; otherwise, keep "Unknown"
                                    if ($faculty && !empty($faculty['first_name'])) {
                                        $faculty_name = htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name'], ENT_QUOTES);
                                    } else {
                                        error_log("Faculty member with ID {$action_by_id} not found.");
                                    }
                                } catch (PDOException $e) {
                                    // Log database errors
                                    error_log('Error fetching faculty name: ' . $e->getMessage());
                                }
                            } else {
                                error_log("Invalid action_by ID: {$action_by_id}");
                            }
                            echo $faculty_name;
                            ?>
                        </td>
                        <td><?= htmlspecialchars($complaint['action_date'], ENT_QUOTES) ?></td>
                        <td><?= !empty($complaint['AA_comment']) ? htmlspecialchars($complaint['AA_comment'], ENT_QUOTES) : 'N/A' ?></td>
                        <?php if ($show_hod_comment): ?>
                            <td>
                                <?php if ($complaint['HOD_comment'] !== 'N/A' && !empty($complaint['HOD_comment'])): ?>
                                    <?= htmlspecialchars($complaint['HOD_comment'], ENT_QUOTES) ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <?php if ($show_mrc_comment): ?>
                            <td>
                                <?php if ($complaint['MRC_comment'] !== 'N/A' && !empty($complaint['MRC_comment'])): ?>
                                    <?= htmlspecialchars($complaint['MRC_comment'], ENT_QUOTES) ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <?php if ($show_aau_comment): ?>
                            <td>
                                <?php if ($complaint['AAU_comment'] !== 'N/A' && !empty($complaint['AAU_comment'])): ?>
                                    <?= htmlspecialchars($complaint['AAU_comment'], ENT_QUOTES) ?>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                        <td class="<?= $complaint['is_readed'] ? 'status-read' : 'status-unread' ?>">
                            <?php if ($complaint['is_readed']): ?>
                                <i class="fas fa-check" style="color: green;"></i> Read
                            <?php else: ?>
                                <i class="fas fa-times" style="color: red;"></i> Unread
                            <?php endif; ?>
                        </td>
                        <?php if ($show_action): ?>
                            <td>
                                <?php if (!$complaint['is_readed']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="complaint_id" value="<?= htmlspecialchars($complaint['complaint_id'], ENT_QUOTES) ?>">
                                        <button type="submit" name="mark_as_read">
                                            <i class="fas fa-check"></i> Mark as Read
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- Footer -->
    <footer>
        &copy; 2025 Voice of Student. All rights reserved.
    </footer>
</body>
</html>