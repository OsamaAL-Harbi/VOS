from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

# Initialize Flask app and database
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///university.db'  # SQLite database
db = SQLAlchemy(app)

# Models (Database Tables)
class Faculty(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=False)

class Department(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey('department.id'), nullable=False)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)

# API Endpoints
@app.route('/faculty', methods=['POST'])
def add_faculty():
    data = request.json
    new_faculty = Faculty(name=data['name'], email=data['email'], department_id=data['department_id'])
    db.session.add(new_faculty)
    db.session.commit()
    return jsonify({'message': 'Faculty added successfully'}), 201

@app.route('/department', methods=['POST'])
def add_department():
    data = request.json
    new_department = Department(name=data['name'])
    db.session.add(new_department)
    db.session.commit()
    return jsonify({'message': 'Department added successfully'}), 201

@app.route('/course', methods=['POST'])
def add_course():
    data = request.json
    new_course = Course(name=data['name'], department_id=data['department_id'])
    db.session.add(new_course)
    db.session.commit()
    return jsonify({'message': 'Course added successfully'}), 201

@app.route('/student', methods=['POST'])
def add_student():
    data = request.json
    new_student = Student(name=data['name'], email=data['email'])
    db.session.add(new_student)
    db.session.commit()
    return jsonify({'message': 'Student added successfully'}), 201

@app.route('/enroll', methods=['POST'])
def enroll_student():
    data = request.json
    new_enrollment = Enrollment(student_id=data['student_id'], course_id=data['course_id'])
    db.session.add(new_enrollment)
    db.session.commit()
    return jsonify({'message': 'Student enrolled in course successfully'}), 201

# Run the app
if __name__ == '__main__':
    db.create_all()  # Create database tables
    app.run(debug=True)