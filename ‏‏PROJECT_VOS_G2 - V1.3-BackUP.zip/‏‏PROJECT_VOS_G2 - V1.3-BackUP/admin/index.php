<?php
session_start();
require_once 'db.php';

try {
    // Create a PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch Faculty Members
    $faculty_query = "
        SELECT 
            faculty_id,
            first_name,
            last_name,
            role
        FROM 
            faculty_members
        ORDER BY 
            last_name ASC;
    ";
    $faculty_stmt = $pdo->query($faculty_query);
    $faculty_members = $faculty_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Update Faculty Role (if form submitted)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
        $faculty_id = filter_var($_POST['faculty_id'], FILTER_VALIDATE_INT);
        $new_role = filter_var($_POST['new_role'], FILTER_SANITIZE_STRING);

        if ($faculty_id === false || empty($new_role)) {
            die("Invalid input.");
        }

        $update_query = "
            UPDATE faculty_members
            SET role = :role
            WHERE faculty_id = :faculty_id;
        ";
        $update_stmt = $pdo->prepare($update_query);
        $update_stmt->execute([':role' => $new_role, ':faculty_id' => $faculty_id]);

        if ($update_stmt->rowCount() > 0) {
            header('Location: index.php'); // Redirect to refresh the page
            exit;
        } else {
            echo "No rows were updated. Faculty ID may not exist.";
        }
    }

    // Fetch Complaints Report
    $complaints_query = "
        SELECT  
            c.complaint_id AS complaint_id,
            c.complaint_description AS complaint_description,
            c.status,
            c.created_at,
            c.complainant_id AS student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            c.course_name,
            c.complaint_department AS department_name
        FROM 
            complaints c
        LEFT JOIN 
            students s ON c.complainant_id = s.student_id
        ORDER BY 
            c.created_at DESC;
    ";
    $complaints_stmt = $pdo->query($complaints_query);
    $complaints = $complaints_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Complaint Counts Grouped by Status
    $counts_query = "
        SELECT status, COUNT(*) AS count
        FROM complaints
        GROUP BY status
    ";
    $counts_stmt = $pdo->query($counts_query);
    $complaint_counts = $counts_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Most Popular Courses
    $popular_courses_query = "
        SELECT co.course_name, COUNT(ce.enrollment_id) AS enrollment_count
        FROM enrollments ce
        JOIN courses co ON ce.course_id = co.course_id
        GROUP BY co.course_name
        ORDER BY enrollment_count DESC
        LIMIT 5
    ";
    $popular_courses_stmt = $pdo->query($popular_courses_query);
    $popular_courses = $popular_courses_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Most Complained About Courses
    $complained_courses_query = "
        SELECT c.course_name, COUNT(*) AS complaint_count
        FROM complaints c
        GROUP BY c.course_name
        ORDER BY complaint_count DESC
        LIMIT 5
    ";
    $complained_courses_stmt = $pdo->query($complained_courses_query);
    $complained_courses = $complained_courses_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Most Popular Departments
    $departments_query = "
        SELECT d.department_name, COUNT(f.faculty_id) AS faculty_count
        FROM faculty_members f
        JOIN departments d ON f.department_id = d.department_id
        GROUP BY d.department_name
        ORDER BY faculty_count DESC
        LIMIT 5
    ";
    $departments_stmt = $pdo->query($departments_query);
    $popular_departments = $departments_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    die("An error occurred while processing your request.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container admin-panel">
        <h1>Admin Panel</h1>

        <!-- Faculty Management -->
        <section id="faculty-management">
            <h2>Faculty Management</h2>
            <form method="POST" action="">
                <label for="faculty_id">Select Faculty Member:</label>
                <select name="faculty_id" id="faculty_id" required>
                    <option value="">Select a faculty member</option>
                    <?php foreach ($faculty_members as $faculty): ?>
                        <option value="<?= htmlspecialchars($faculty['faculty_id']) ?>">
                            <?= htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="new_role">New Role:</label>
                <select name="new_role" id="new_role" required>
                    <option value="">Select a role</option>
                    <option value="Academic Advisor">Academic Advisor</option>
                    <option value="Head of Department">Head of Department</option>
                    <option value="Admin">Admin</option>
                </select>
                <button type="submit" name="update_role">Update Role</button>
            </form>
            <table>
        </section>

        <?php
require_once '../db.php';

try {
    // Fetch Complaints Report
    $complaints_query = "
        SELECT  
            c.complaint_id AS complaint_id,
            c.complaint_description AS complaint_description,
            c.status,
            c.created_at,
            c.updated_at, -- Added updated_at column
            c.complainant_id AS student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            c.course_name,
            c.complaint_department AS department_name,
            c.complaint_type, -- Added complaint_type column
            c.file_path -- Added file_path column
        FROM 
            complaints c
        LEFT JOIN 
            students s ON c.complainant_id = s.student_id
        ORDER BY 
            c.created_at DESC;
    ";

    $complaints_stmt = $pdo->query($complaints_query);
    $complaints = $complaints_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    die("An error occurred while processing your request.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints Report</title>
    <link rel="stylesheet" href="../style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Filter Section */
        .filter-section {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-section label {
            font-weight: bold;
        }

        .filter-section select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .filter-section button {
            padding: 8px 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .filter-section button:hover {
            background: #0056b3;
        }

        /* Card Layout */
        .complaint-cards {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between; /* Ensure even spacing between cards */
        }

        .complaint-card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            padding: 15px;
            width: calc(33.33% - 20px); /* Three cards per row with gap */
            box-sizing: border-box; /* Include padding and border in width calculation */
        }

        .complaint-card h3 {
            margin: 0 0 10px;
            font-size: 18px;
            color: #007bff;
        }

        .complaint-card p {
            margin: 5px 0;
            font-size: 14px;
            line-height: 1.5;
        }

        .complaint-card p strong {
            font-weight: bold;
            color: #333;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .complaint-card {
                width: calc(50% - 20px); /* Two cards per row on medium screens */
            }
        }

        @media (max-width: 768px) {
            .complaint-card {
                width: 100%; /* One card per row on small screens */
            }
        }

        /* Footer Styling */
        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
    </style>
</head>
<body>
    <main>
        <h1>Complaints Report</h1>

        <!-- Filter Section -->
        <div class="filter-section">
            <label for="status-filter">Filter by Status:</label>
            <select id="status-filter">
                <option value="">All</option>
                <option value="Submited">Submitted</option>
                <option value="In_progress">In Progress</option>
                <option value="Resolved">Resolved</option>
                <option value="Rejected">Rejected</option>
            </select>

            <label for="department-filter">Filter by Department:</label>
            <select id="department-filter">
                <option value="">All</option>
                <?php
                // Dynamically generate department options
                $departments = array_unique(array_column($complaints, 'department_name'));
                foreach ($departments as $department) {
                    echo '<option value="' . htmlspecialchars($department) . '">' . htmlspecialchars($department) . '</option>';
                }
                ?>
            </select>

            <label for="type-filter">Filter by Complaint Type:</label>
            <select id="type-filter">
                <option value="">All</option>
                <?php
                // Dynamically generate complaint type options
                $types = array_unique(array_column($complaints, 'complaint_type'));
                foreach ($types as $type) {
                    echo '<option value="' . htmlspecialchars($type) . '">' . htmlspecialchars($type) . '</option>';
                }
                ?>
            </select>

            <button id="clear-filters">Clear Filters</button>
        </div>

        <!-- Complaint Cards -->
        <div class="complaint-cards" id="complaints-cards-container">
            <?php if (!empty($complaints)): ?>
                <?php foreach ($complaints as $complaint): ?>
                    <div class="complaint-card"
                         data-status="<?= htmlspecialchars($complaint['status']) ?>"
                         data-department="<?= htmlspecialchars($complaint['department_name']) ?>"
                         data-type="<?= htmlspecialchars($complaint['complaint_type']) ?>">
                        <h3>Complaint ID: <?= htmlspecialchars($complaint['complaint_id']) ?></h3>
                        <p><strong>Description:</strong> <?= htmlspecialchars($complaint['complaint_description']) ?></p>
                        <p><strong>Status:</strong> <?= htmlspecialchars($complaint['status']) ?></p>
                        <p><strong>Date Created:</strong> <?= htmlspecialchars($complaint['created_at']) ?></p>
                        <p><strong>Date Updated:</strong> <?= htmlspecialchars($complaint['updated_at'] ?? 'N/A') ?></p>
                        <p><strong>Student ID:</strong> <?= htmlspecialchars($complaint['student_id']) ?></p>
                        <p><strong>Student Name:</strong> <?= htmlspecialchars($complaint['student_name']) ?></p>
                        <p><strong>Course Name:</strong> <?= htmlspecialchars($complaint['course_name']) ?></p>
                        <p><strong>Department:</strong> <?= htmlspecialchars($complaint['department_name']) ?></p>
                        <p><strong>Complaint Type:</strong> <?= htmlspecialchars($complaint['complaint_type']) ?></p>
                        <p><strong>File Path:</strong> 
                            <?= !empty($complaint['file_path']) ? '<a href="' . htmlspecialchars($complaint['file_path']) . '">View File</a>' : 'No file' ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No complaints found.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2023 Admin Panel. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const statusFilter = document.getElementById('status-filter');
            const departmentFilter = document.getElementById('department-filter');
            const typeFilter = document.getElementById('type-filter');
            const clearFiltersButton = document.getElementById('clear-filters');
            const complaintCards = document.querySelectorAll('.complaint-card');

            // Function to filter cards
            function filterCards() {
                const selectedStatus = statusFilter.value.toLowerCase();
                const selectedDepartment = departmentFilter.value.toLowerCase();
                const selectedType = typeFilter.value.toLowerCase();

                complaintCards.forEach(card => {
                    const cardStatus = card.dataset.status.toLowerCase();
                    const cardDepartment = card.dataset.department.toLowerCase();
                    const cardType = card.dataset.type.toLowerCase();

                    const matchesStatus = selectedStatus === '' || cardStatus === selectedStatus;
                    const matchesDepartment = selectedDepartment === '' || cardDepartment === selectedDepartment;
                    const matchesType = selectedType === '' || cardType === selectedType;

                    if (matchesStatus && matchesDepartment && matchesType) {
                        card.style.display = '';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }

            // Add event listeners to filters
            statusFilter.addEventListener('change', filterCards);
            departmentFilter.addEventListener('change', filterCards);
            typeFilter.addEventListener('change', filterCards);

            // Clear filters
            clearFiltersButton.addEventListener('click', () => {
                statusFilter.value = '';
                departmentFilter.value = '';
                typeFilter.value = '';
                filterCards(); // Reset the cards
            });
        });
    </script>
</body>
</html>

        <!-- Complaint Statistics -->
        <section id="complaint-statistics">
            <h2>Complaint Status Chart</h2>
            <canvas id="complaintChart"></canvas>
            <script>
                const complaintData = <?php echo json_encode($complaint_counts); ?>;
                if (complaintData.length > 0) {
                    const labels = complaintData.map(item => item.status);
                    const counts = complaintData.map(item => item.count);

                    const backgroundColors = labels.map((_, index) => {
                        const colors = [
                            'rgba(75, 192, 192, 0.6)',   // Teal
                            'rgba(255, 99, 132, 0.6)',  // Red
                            'rgba(240, 52, 35, 0.6)',   // Dark Red
                            'rgba(204, 243, 50, 0.6)',  // Yellow-Green
                            'hsla(114, 59.50%, 51.60%, 0.60)' // Green
                        ];
                        return colors[index % colors.length];
                    });

                    const borderColors = labels.map((_, index) => {
                        const colors = [
                            'rgba(75, 192, 192, 1)',    // Teal
                            'rgba(255, 99, 132, 1)',   // Red
                            'rgb(248, 24, 24)',        // Dark Red
                            'rgb(165, 231, 66)',       // Yellow-Green
                            'rgb(71, 202, 75)'         // Green
                        ];
                        return colors[index % colors.length];
                    });

                    const ctx = document.getElementById('complaintChart').getContext('2d');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Number of Complaints',
                                data: counts,
                                backgroundColor: backgroundColors,
                                borderColor: borderColors,
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                } else {
                    document.getElementById('complaintChart').parentElement.innerHTML = '<p style="text-align: center; color: #666;">No complaint data available.</p>';
                }
            </script>
        </section>

        <!-- Most Popular Courses -->
        <section id="popular-courses">
            <h2>Most Popular Courses</h2>
            <table>
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Enrollment Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_courses)): ?>
                        <?php foreach ($popular_courses as $course): ?>
                            <tr>
                                <td><?= htmlspecialchars($course['course_name']) ?></td>
                                <td><?= htmlspecialchars($course['enrollment_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No popular courses found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>

        <!-- Most Complained About Courses -->
        <section id="complained-courses">
            <h2>Most Complained About Courses</h2>
            <table>
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Complaint Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($complained_courses)): ?>
                        <?php foreach ($complained_courses as $course): ?>
                            <tr>
                                <td><?= htmlspecialchars($course['course_name']) ?></td>
                                <td><?= htmlspecialchars($course['complaint_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No complaints found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>

        <!-- Most Popular Departments -->
        <section id="popular-departments">
            <h2>Most Popular Departments</h2>
            <table>
                <thead>
                    <tr>
                        <th>Department Name</th>
                        <th>Faculty Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_departments)): ?>
                        <?php foreach ($popular_departments as $department): ?>
                            <tr>
                                <td><?= htmlspecialchars($department['department_name']) ?></td>
                                <td><?= htmlspecialchars($department['faculty_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No departments found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>
    <footer>
    <p>&copy; 2023 Admin Panel. All rights reserved.</p>
</footer>
</body>
</html>