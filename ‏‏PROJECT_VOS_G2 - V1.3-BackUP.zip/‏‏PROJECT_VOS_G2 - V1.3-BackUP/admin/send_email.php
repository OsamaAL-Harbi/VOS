
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Send email notification about role update using PHPMailer
 */
/**
 * Send email notification about role update using PHPMailer
 */
function sendRoleUpdateEmail($to_email, $faculty_name, $new_role, $translations) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'vos.info.project@gmail.com';
        $mail->Password   = 'vzfz kwsj fccj xcoy';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;
        
        // Recipients
        $mail->setFrom('support@vos.project.com', 'VOS Admin');
        $mail->addAddress($to_email, $faculty_name);
        
        // Email content
        $mail->isHTML(true);
        $mail->Subject = $translations['email_subject'];
        
        $mail->Body = sprintf('
        <div style="font-family: \'Inter\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; 
                    max-width: 600px; margin: 20px auto; padding: 0; background: #ffffff; border-radius: 8px; 
                    overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); border: 1px solid #e5e7eb;">
            <div style="background: #4361ee; padding: 24px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
                    <i class="fas fa-user-shield" style="margin-right: 10px;"></i> %s
                </h1>
            </div>
            
            <div style="padding: 32px;">
                <p style="font-size: 16px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    Dear %s,<br><br>
                    Your faculty role has been updated in the university system.
                </p>
                
                <div style="background: #f3f4f6; padding: 20px; text-align: center; margin: 0 0 32px 0;
                            font-size: 24px; font-weight: 700; color: #1e40af;
                            border-radius: 6px; border: 1px dashed #d1d5db;">
                    New Role: <strong>%s</strong>
                </div>
                
                <div style="background: #f0fdf4; padding: 16px; border-radius: 6px; margin-bottom: 24px;
                            border-left: 4px solid #16a34a;">
                    <p style="font-size: 14px; color: #166534; margin: 0;">
                        <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                        <strong>This change is effective immediately.</strong>
                    </p>
                </div>
                
                <p style="font-size: 15px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    If you have any questions about your new responsibilities or if you believe this change
                    was made in error, please contact the administration office immediately.
                </p>
                
                <div style="background: #f9fafb; padding: 16px; border-radius: 6px; margin-top: 32px;
                            border-top: 1px solid #e5e7eb; font-size: 12px; color: #6b7280;">
                    <p style="margin: 0 0 8px 0; font-weight: 600;">SYSTEM INFORMATION</p>
                    <table style="width: 100%%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 4px 0; width: 100px;">Change ID:</td>
                            <td style="padding: 4px 0; font-family: monospace;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">Processed by:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">IP Address:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">Time:</td>
                            <td style="padding: 4px 0;">%s (UTC)</td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div style="background: #f9fafb; padding: 16px; text-align: center; font-size: 12px; 
                        color: #9ca3af; border-top: 1px solid #e5e7eb;">
                <p style="margin: 0;">This is an automated notification. Please do not reply to this email.</p>
            </div>
        </div>',
        $translations['email_subject'],
        $faculty_name,
        $new_role,
        bin2hex(random_bytes(8)), // Change ID
        $_SESSION['admin_name'] ?? 'System Administrator', // Assuming admin name is stored in session
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        gmdate('Y-m-d H:i:s') // Using UTC time
        );
        
        // Plain text fallback
        $mail->AltBody = sprintf(
            "FACULTY ROLE UPDATE NOTIFICATION\n\n" .
            "Dear %s,\n\n" .
            "Your faculty role has been updated to: %s\n\n" .
            "This change is effective immediately.\n\n" .
            "SYSTEM INFORMATION:\n" .
            "Change ID: %s\n" .
            "Processed by: %s\n" .
            "IP Address: %s\n" .
            "Time: %s (UTC)\n\n" .
            "If you have any questions about your new responsibilities or if you believe this change\n" .
            "was made in error, please contact the administration office immediately.\n\n" .
            "This is an automated notification. Please do not reply to this email.",
            $faculty_name,
            $new_role,
            bin2hex(random_bytes(8)),
            $_SESSION['admin_name'] ?? 'System Administrator',
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            gmdate('Y-m-d H:i:s')
        );
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>