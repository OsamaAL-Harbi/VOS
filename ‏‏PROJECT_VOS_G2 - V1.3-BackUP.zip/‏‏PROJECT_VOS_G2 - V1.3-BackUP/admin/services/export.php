<?php
require_once 'vendor/autoload.php';
require_once '../db.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

/**
 * Fetch all complaints and their actions from the database.
 */
function fetchComplaintsWithActions(PDO $pdo): array {
    try {
        // Verify required tables exist
        $requiredTables = ['complaints', 'students', 'complaint_actions', 'faculty_members'];
        foreach ($requiredTables as $table) {
            $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$table]);
            if (!$stmt->fetch()) {
                throw new Exception("Table '$table' does not exist in the database");
            }
        }
        $query = "SELECT 
        c.complaint_id,
        c.complainant_id,
        CONCAT(s.first_name, ' ', s.last_name) AS student_name,
        s.email AS student_email,
        c.complaint_type,
        c.course_name,
        c.complaint_description,
        c.status,
        c.complaint_department,
        c.created_at AS complaint_date,
        c.updated_at,
        c.active_complaints,
        c.file_path,
        c.term_id,
        c.recipient,
        ca.action_id,
        ca.action_type,
        ca.action_date,
        ca.AA_comment,
        ca.HOD_comment,
        ca.MRC_comment,
        ca.AAU_comment,
        ca.is_readed,
        CONCAT(fm_aa.first_name, ' ', fm_aa.last_name) AS aa_name,
        CONCAT(fm_hod.first_name, ' ', fm_hod.last_name) AS hod_name,
        CONCAT(fm_mrc.first_name, ' ', fm_mrc.last_name) AS mrc_name,
        CONCAT(fm_aau.first_name, ' ', fm_aau.last_name) AS aau_name,
        CONCAT(fm_recipient.first_name, ' ', fm_recipient.last_name) AS recipient_name
      FROM complaints c
      JOIN students s ON c.complainant_id = s.student_id
      LEFT JOIN complaint_actions ca ON c.complaint_id = ca.complaint_id
      LEFT JOIN faculty_members fm_aa ON ca.action_by_AA = fm_aa.faculty_id AND fm_aa.role = 'academic_advisor'
      LEFT JOIN faculty_members fm_hod ON ca.action_by_HOD = fm_hod.faculty_id AND fm_hod.role = 'head_of_department'
      LEFT JOIN faculty_members fm_mrc ON ca.action_by_MRC = fm_mrc.faculty_id AND fm_mrc.role = 'head of review_committee'
      LEFT JOIN faculty_members fm_aau ON ca.action_by_AAU = fm_aau.faculty_id AND fm_aau.role = 'head_of_Academic_Unit'
      LEFT JOIN faculty_members fm_recipient ON c.recipient = fm_recipient.faculty_id
      ORDER BY c.complaint_id, ca.action_date DESC";

        $stmt = $pdo->prepare($query);
        if (!$stmt->execute()) {
            throw new Exception("Query failed: " . implode(" ", $stmt->errorInfo()));
        }
        
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($results)) {
            throw new Exception("No complaints found in the database.");
        }

        // Organize data
        $organizedData = [];
        foreach ($results as $row) {
            $complaintId = $row['complaint_id'];
            
            if (!isset($organizedData[$complaintId])) {
                $organizedData[$complaintId] = [
                    'complaint_id' => $row['complaint_id'],
                    'student_id' => $row['complainant_id'],
                    'student_name' => $row['student_name'],
                    'student_email' => $row['student_email'],
                    'complaint_type' => $row['complaint_type'],
                    'course_name' => $row['course_name'],
                    'description' => $row['complaint_description'],
                    'status' => $row['status'],
                    'department' => $row['complaint_department'],
                    'created_at' => $row['complaint_date'],
                    'updated_at' => $row['updated_at'],
                    'active' => (bool)$row['active_complaints'],
                    'attachment' => !empty($row['file_path']),
                    'term_id' => $row['term_id'],
                    'recipient' => $row['recipient_name'] ?? 'None',
                    'actions' => []
                ];
            }
            
            if ($row['action_id']) {
                $organizedData[$complaintId]['actions'][] = [
                    'action_id' => $row['action_id'],
                    'type' => $row['action_type'],
                    'date' => $row['action_date'],
                    'aa_comment' => $row['AA_comment'],
                    'hod_comment' => $row['HOD_comment'],
                    'mrc_comment' => $row['MRC_comment'],
                    'aau_comment' => $row['AAU_comment'],
                    'read' => (bool)$row['is_readed'],
                    'aa_name' => $row['aa_name'] ?? 'None',
                    'hod_name' => $row['hod_name'] ?? 'None',
                    'mrc_name' => $row['mrc_name'] ?? 'None',
                    'aau_name' => $row['aau_name'] ?? 'None'
                ];
            }
        }

        return array_values($organizedData);
    } catch (PDOException $e) {
        throw new Exception("Database error: " . $e->getMessage());
    }
}

/**
 * Generate Excel report
 */
function generateExcelReport(array $complaints): void {
    try {
        if (empty($complaints)) {
            throw new Exception("No data to export");
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set metadata
        $spreadsheet->getProperties()
            ->setTitle("Complaints Report")
            ->setSubject("Complaints Management System");

        // Headers
        $headers = [
            'ID', 'Student ID', 'Student', 'Email', 'Type', 'Course', 
            'Description', 'Status', 'Department', 'Created', 'Updated',
            'Active', 'Attachment', 'Term', 'Recipient',
            'Action ID', 'Action Type', 'Action Date', 
            'AA Comment', 'HOD Comment', 'MRC Comment', 'AAU Comment',
            'Read', 'AA Name', 'HOD Name', 'MRC Name', 'AAU Name'
        ];
        $sheet->fromArray($headers, null, 'A1');

        // Style headers
        $sheet->getStyle('A1:AA1')
            ->getFont()->setBold(true);
        $sheet->getStyle('A1:AA1')
            ->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('4472C4');
        $sheet->getStyle('A1:AA1')
            ->getFont()->getColor()->setRGB('FFFFFF');

        // Add data
        $row = 2;
        foreach ($complaints as $complaint) {
            $baseData = [
                $complaint['complaint_id'],
                $complaint['student_id'],
                $complaint['student_name'],
                $complaint['student_email'],
                $complaint['complaint_type'],
                $complaint['course_name'],
                $complaint['description'],
                $complaint['status'],
                $complaint['department'],  // Fixed typo: was $complaint['department']
                $complaint['created_at'],
                $complaint['updated_at'],
                $complaint['active'] ? 'Yes' : 'No',
                $complaint['attachment'] ? 'Yes' : 'No',  // Fixed typo: was $complaint['attachment']
                $complaint['term_id'],
                $complaint['recipient']
            ];

            if (empty($complaint['actions'])) {
                $sheet->fromArray($baseData, null, "A{$row}");
                $row++;
                continue;
            }

            foreach ($complaint['actions'] as $action) {
                $actionData = [
                    $action['action_id'],
                    $action['type'],
                    $action['date'],
                    $action['aa_comment'],
                    $action['hod_comment'],
                    $action['mrc_comment'],
                    $action['aau_comment'],
                    $action['read'] ? 'Yes' : 'No',
                    $action['aa_name'],
                    $action['hod_name'],
                    $action['mrc_name'],
                    $action['aau_name']
                ];
                $sheet->fromArray(array_merge($baseData, $actionData), null, "A{$row}");
                $row++;
            }
        }

        // Auto-size columns
        foreach (range('A', 'Z') as $col) {
            $sheet->getColumnDimension($col)->setAutoSize(true);
        }

        // Output
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="complaints_report_'.date('Y-m-d').'.xlsx"');
        header('Cache-Control: max-age=0');

        $writer = new Xlsx($spreadsheet);
        $writer->save('php://output');
        exit;

    } catch (Exception $e) {
        throw new Exception("Excel generation failed: " . $e->getMessage());
    }
}

// Main execution
try {
    if (!$pdo) {
        throw new Exception("Database connection failed");
    }

    $complaints = fetchComplaintsWithActions($pdo);
    generateExcelReport($complaints);

} catch (Exception $e) {
    // Clean output buffer
    if (ob_get_length()) ob_clean();
    
    // Error response
    header('Content-Type: text/html; charset=utf-8');
    echo '<div style="padding:20px;background:#ffebee;border:1px solid #f44336;color:#b71c1c;">';
    echo '<h3>Export Failed</h3>';
    echo '<p>'.htmlspecialchars($e->getMessage()).'</p>';
    echo '<p>Please verify your database structure matches the expected schema.</p>';
    echo '</div>';
    exit;
}