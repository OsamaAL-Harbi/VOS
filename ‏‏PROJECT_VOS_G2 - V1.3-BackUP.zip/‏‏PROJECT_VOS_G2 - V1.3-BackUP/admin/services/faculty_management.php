<?php
session_start(); // Start session for language preference

// Set default language if not already set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en'; // Default to English
}

// Handle language switch
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'ar') ? 'ar' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?')); // Redirect to clean URL
    exit();
}

require_once '../db.php';
require '../vendor/autoload.php'; // Include PHPMailer autoload

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize variables
$faculty_members = [];
$error_message = '';
$success_message = '';

// Language translations
$translations = [
    'en' => [
        'title' => 'Update Faculty Role',
        'back' => 'Back',
        'select_faculty' => 'Select Faculty:',
        'new_role' => 'New Role:',
        'update_role' => 'Update Role',
        'select' => 'Select',
        'show_faculty' => 'Show All Faculty Members',
        'hide_faculty' => 'Hide Faculty Members',
        'name' => 'Name',
        'current_role' => 'Current Role',
        'email' => 'Email',
        'phone' => 'Phone',
        'department' => 'Department',
        'hire_date' => 'Hire Date',
        'hod_id' => 'HOD ID',
        'roles' => [
            'Academic Advisor' => 'Academic Advisor',
            'Head of Department' => 'Head of Department',
            'Head Marks Review Committee' => 'Head Marks Review Committee',
            'Head Academic Advisor Unit' => 'Head Academic Advisor Unit',
            'Admin' => 'Admin'
        ],
        'departments' => [
            1 => 'IT',
            2 => 'CS', 
            3 => 'DS'
        ],
        'errors' => [
            'invalid_role' => 'Invalid role selected.',
            'cannot_change' => 'The role of this faculty member cannot be changed.',
            'role_exists' => 'There is already a faculty member with this role.',
            'success' => 'Role updated successfully.',
            'email_failed' => 'Role updated but failed to send notification email.'
        ],
        'email_subject' => 'Your Role Has Been Updated',
        'email_body' => 'Dear %s,<br><br>Your role has been updated to: <strong>%s</strong>.<br><br>Best regards,<br>Administration Team',
        'footer' => 'Admin Panel. All rights reserved.'
    ],
    'ar' => [
        'title' => 'تحديث دور أعضاء هيئة التدريس',
        'back' => 'العودة',
        'select_faculty' => 'اختر عضو هيئة التدريس:',
        'new_role' => 'الدور الجديد:',
        'update_role' => 'تحديث الدور',
        'select' => 'اختر',
        'show_faculty' => 'عرض جميع أعضاء هيئة التدريس',
        'hide_faculty' => 'إخفاء أعضاء هيئة التدريس',
        'name' => 'الاسم',
        'current_role' => 'الدور الحالي',
        'email' => 'البريد الإلكتروني',
        'phone' => 'الهاتف',
        'department' => 'القسم',
        'hire_date' => 'تاريخ التعيين',
        'hod_id' => 'معرف رئيس القسم',
        'roles' => [
            'Academic Advisor' => 'المستشار الأكاديمي',
            'Head of Department' => 'رئيس القسم',
            'Head Marks Review Committee' => 'رئيس لجنة مراجعة العلامات',
            'Head Academic Advisor Unit' => 'رئيس وحدة المستشارين الأكاديميين',
            'Admin' => 'مدير النظام'
        ],
        'departments' => [
            1 => 'تكنولوجيا المعلومات',
            2 => 'علوم الحاسب',
            3 => 'علوم البيانات'
        ],
        'errors' => [
            'invalid_role' => 'تم اختيار دور غير صالح.',
            'cannot_change' => 'لا يمكن تغيير دور هذا العضو في هيئة التدريس.',
            'role_exists' => 'يوجد بالفعل عضو هيئة تدريس بهذا الدور.',
            'success' => 'تم تحديث الدور بنجاح.',
            'email_failed' => 'تم تحديث الدور ولكن فشل إرسال بريد الإخطار.'
        ],
        'email_subject' => 'تم تحديث دورك',
        'email_body' => 'السادة %s،<br><br>تم تحديث دورك إلى: <strong>%s</strong>.<br><br>مع أطيب التحيات،<br>فريق الإدارة',
        'footer' => 'لوحة التحكم. جميع الحقوق محفوظة.'
    ]
];

$lang = $_SESSION['lang'];
$t = $translations[$lang];

/**
 * Send email notification about role update using PHPMailer
 */
function sendRoleUpdateEmail($to_email, $faculty_name, $new_role, $translations) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'vos.info.project@gmail.com';
        $mail->Password   = 'vzfz kwsj fccj xcoy';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;
        
        // Recipients
        $mail->setFrom('support@vos.project.com', 'VOS Admin');
        $mail->addAddress($to_email, $faculty_name);
        
        // Email content
        $mail->isHTML(true);
        $mail->Subject = $translations['email_subject'];

        $mail->Body = sprintf('
        <div style="font-family: \'Inter\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; 
                    max-width: 600px; margin: 20px auto; padding: 0; background: #ffffff; border-radius: 8px; 
                    overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); border: 1px solid #e5e7eb;">
            <div style="background: #4361ee; padding: 24px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
                    <i class="fas fa-user-shield" style="margin-right: 10px;"></i> %s
                </h1>
            </div>
            
            <div style="padding: 32px;">
                <p style="font-size: 16px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    Dear %s,<br><br>
                    Your faculty role has been updated in the university system.
                </p>
                
                <div style="background: #f3f4f6; padding: 20px; text-align: center; margin: 0 0 32px 0;
                            font-size: 24px; font-weight: 700; color: #1e40af;
                            border-radius: 6px; border: 1px dashed #d1d5db;">
                    New Role: <strong>%s</strong>
                </div>
                
                <div style="background: #f0fdf4; padding: 16px; border-radius: 6px; margin-bottom: 24px;
                            border-left: 4px solid #16a34a;">
                    <p style="font-size: 14px; color: #166534; margin: 0;">
                        <i class="fas fa-info-circle" style="margin-right: 8px;"></i>
                        <strong>This change is effective immediately.</strong>
                    </p>
                </div>
                
                <p style="font-size: 15px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    If you have any questions about your new responsibilities or if you believe this change
                    was made in error, please contact the administration office immediately.
                </p>
                
                <!-- Like System Button -->
                <div style="text-align: center; margin: 24px 0;">
                    <a href="../../faculty_member_dashboard/index.php" 
                    style="display: inline-block; background-color: #4361ee; color: white; 
                            padding: 12px 24px; border-radius: 6px; text-decoration: none;
                            font-weight: 600; transition: background-color 0.3s;">
                    <i class="fas fa-thumbs-up" style="margin-right: 8px;"></i> Go To VOS Website
                    </a>
                </div>
                
                <div style="background: #f9fafb; padding: 16px; border-radius: 6px; margin-top: 16px;
                            border-top: 1px solid #e5e7eb; font-size: 12px; color: #6b7280;">
                    <p style="margin: 0 0 8px 0; font-weight: 600;">SYSTEM INFORMATION</p>
                    <table style="width: 100%%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 4px 0; width: 100px;">Change ID:</td>
                            <td style="padding: 4px 0; font-family: monospace;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">Processed by:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">IP Address:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">Time:</td>
                            <td style="padding: 4px 0;">%s (UTC)</td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div style="background: #f9fafb; padding: 16px; text-align: center; font-size: 12px; 
                        color: #9ca3af; border-top: 1px solid #e5e7eb;">
                <p style="margin: 0;">This is an automated notification. Please do not reply to this email.</p>
            </div>
        </div>',
        $translations['email_subject'],
        $faculty_name,
        $new_role,
        bin2hex(random_bytes(8)), // Change ID
        $_SESSION['admin_name'] ?? 'System Administrator',
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        gmdate('Y-m-d H:i:s')
        );

        // Plain text fallback with Like option
        $mail->AltBody = sprintf(
            "FACULTY ROLE UPDATE NOTIFICATION\n\n" .
            "Dear %s,\n\n" .
            "Your faculty role has been updated to: %s\n\n" .
            "This change is effective immediately.\n\n" .
            "../../faculty_member_dashboard/index.php\n\n" .
            "SYSTEM INFORMATION:\n" .
            "Change ID: %s\n" .
            "Processed by: %s\n" .
            "IP Address: %s\n" .
            "Time: %s (UTC)\n\n" .
            "If you have any questions about your new responsibilities or if you believe this change\n" .
            "was made in error, please contact the administration office immediately.\n\n" .
            "This is an automated notification. Please do not reply to this email.",
            $faculty_name,
            $new_role,
            bin2hex(random_bytes(8)),
            $_SESSION['admin_name'] ?? 'System Administrator',
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            gmdate('Y-m-d H:i:s')
        );
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

try {
    // Fetch faculty members with all fields
    $stmt = $pdo->query("SELECT faculty_id, first_name, last_name, email, phone_number, department_id, role, hire_date, hod_id FROM faculty_members ORDER BY last_name ASC");
    $faculty_members = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Role Update Logic
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['faculty_id'], $_POST['role'])) {
        $role_mapping = [
            'Academic Advisor' => 'academic_advisor',
            'Head of Department' => 'head_of_department',
            'Head Marks Review Committee' => 'head_of_review_committee',
            'Head Academic Advisor Unit' => 'head_of_Academic_Unit',
            'Admin' => 'admin'
        ];

        if (!array_key_exists($_POST['role'], $role_mapping)) {
            $error_message = $t['errors']['invalid_role'];
        } else {
            $faculty_id = $_POST['faculty_id'];
            $new_role = $role_mapping[$_POST['role']];
            $display_role = $t['roles'][$_POST['role']];
            
            // Check current role
            $stmt = $pdo->prepare("SELECT role, first_name, last_name, email FROM faculty_members WHERE faculty_id = ?");
            $stmt->execute([$faculty_id]);
            $faculty_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $current_role = $faculty_data['role'];
            $faculty_name = $faculty_data['first_name'] . ' ' . $faculty_data['last_name'];
            $faculty_email = $faculty_data['email'];

            // Prevent changing head roles to other head roles
            $head_roles = ['head_of_department', 'head_of_review_committee', 'head_of_Academic_Unit', 'admin'];
            
            if (in_array($current_role, $head_roles)) {
                $error_message = $t['errors']['cannot_change'];
            } 
            // Prevent assigning head role if already assigned to someone else
            elseif (in_array($new_role, $head_roles)) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM faculty_members WHERE role = ?");
                $stmt->execute([$new_role]);
                $count = $stmt->fetchColumn();
                
                if ($count > 0) {
                    $error_message = $t['errors']['role_exists'];
                } else {
                    $stmt = $pdo->prepare("UPDATE faculty_members SET role = ? WHERE faculty_id = ?");
                    $stmt->execute([$new_role, $faculty_id]);
                    
                    // Send email notification
                    $email_sent = sendRoleUpdateEmail($faculty_email, $faculty_name, $display_role, $t);
                    
                    if ($email_sent) {
                        $success_message = $t['errors']['success'];
                    } else {
                        $success_message = $t['errors']['email_failed'];
                    }
                }
            } else {
                $stmt = $pdo->prepare("UPDATE faculty_members SET role = ? WHERE faculty_id = ?");
                $stmt->execute([$new_role, $faculty_id]);
                
                // Send email notification
                $email_sent = sendRoleUpdateEmail($faculty_email, $faculty_name, $display_role, $t);
                
                if ($email_sent) {
                    $success_message = $t['errors']['success'];
                } else {
                    $success_message = $t['errors']['email_failed'];
                }
            }
        }
    }
} catch (PDOException $e) {
    error_log("Database error in faculty_role_update.php: " . $e->getMessage());
    $error_message = $t['errors']['general'] ?? "An error occurred while processing your request. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $lang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a76a8;
            --primary-hover: #3a5f8a;
            --secondary-color: #28a745;
            --secondary-hover: #218838;
            --error-color: #e74c3c;
            --error-hover: #c0392b;
            --warning-color: #f39c12;
            --warning-hover: #e67e22;
            --info-color: #3498db;
            --info-hover: #2980b9;
            --success-color: #2ecc71;
            --success-hover: #27ae60;
            --background-color: #f8f9fa;
            --card-background: #ffffff;
            --text-color: #212529;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }

        .dark-theme {
            --primary-color: #34495e;
            --primary-hover: #2c3e50;
            --secondary-color: #218838;
            --secondary-hover: #1e7e34;
            --error-color: #c0392b;
            --error-hover: #a5281b;
            --warning-color: #e67e22;
            --warning-hover: #d35400;
            --info-color: #2980b9;
            --info-hover: #2472a4;
            --success-color: #27ae60;
            --success-hover: #219653;
            --background-color: #1a1a1a;
            --card-background: #2d2d2d;
            --text-color: #f8f9fa;
            --text-muted: #adb5bd;
            --border-color: #444;
            --shadow-color: rgba(0, 0, 0, 0.3);
        }

        [dir="rtl"] {
            text-align: right;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header Styles */
        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem;
            box-shadow: 0 2px 10px var(--shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        h1 {
            margin: 0;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-grow: 1;
            justify-content: center;
        }

        /* Theme Toggle */
        .theme-toggle {
            position: absolute;
            right: 1rem;
        }

        [dir="rtl"] .theme-toggle {
            right: auto;
            left: 1rem;
        }

        .theme-toggle button {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .theme-toggle button:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* Back Button */
        .back-to-main {
            position: absolute;
            left: 1rem;
        }

        [dir="rtl"] .back-to-main {
            left: auto;
            right: 1rem;
        }

        .btn-back {
            color: white;
            text-decoration: none;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-back:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        /* Main Content */
        main {
            flex: 1;
            padding: 2rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        /* Form Styles */
        .form-container {
            background-color: var(--card-background);
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 2px 5px var(--shadow-color);
            max-width: 600px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--primary-color);
        }

        select, button {
            width: 100%;
            padding: 0.75rem;
            border-radius: 4px;
            border: 1px solid var(--border-color);
            background-color: var(--card-background);
            color: var(--text-color);
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        select:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: var(--primary-hover);
        }

        button:disabled {
            background-color: var(--text-muted);
            cursor: not-allowed;
        }

        /* Messages */
        .error-message {
            background-color: var(--error-color);
            color: white;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: opacity 0.5s ease;
        }

        .success-message {
            background-color: var(--success-color);
            color: white;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: opacity 0.5s ease;
        }

        .message i {
            font-size: 1.2rem;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 1.5rem;
            background-color: var(--primary-color);
            color: white;
            margin-top: 3rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
            }
            
            .back-to-main, .theme-toggle {
                position: static;
            }
            
            h1 {
                font-size: 1.5rem;
                text-align: center;
            }
        }
        
        /* Faculty list styles */
        .faculty-list-container {
            margin-top: 2rem;
            background-color: var(--card-background);
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 5px var(--shadow-color);
            max-width: 1000px;
            margin-left: auto;
            margin-right: auto;
            overflow-x: auto;
        }
        
        .faculty-list {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        
        .faculty-list.show {
            max-height: 1000px;
            transition: max-height 0.5s ease-in;
        }
        
        .faculty-list table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
            min-width: 800px;
        }
        
        .faculty-list th, .faculty-list td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .faculty-list th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .faculty-list tr:nth-child(even) {
            background-color: rgba(0, 0, 0, 0.03);
        }
        
        .show-faculty-btn {
            margin-top: 1rem;
            background-color: var(--info-color);
            width: 100%;
        }
        
        .show-faculty-btn:hover {
            background-color: var(--info-hover);
        }
        
        /* Loader styles */
        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        
        .loader-container.active {
            opacity: 1;
            visibility: visible;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Language switch styles */
        .language-switch {
            position: absolute;
            right: 4rem;
            display: flex;
            gap: 0.5rem;
        }
        
        [dir="rtl"] .language-switch {
            right: auto;
            left: 4rem;
        }
        
        .language-btn {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            font-weight: bold;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        .language-btn:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }
        
        .language-btn.active {
            background-color: rgba(255, 255, 255, 0.3);
        }
    </style>
</head>
<body>
    <!-- Loader overlay -->
    <div class="loader-container" id="loader">
        <div class="loader"></div>
    </div>

    <!-- Header Section -->
    <header>
        <div class="header-content">
            <div class="back-to-main">
                <a href="../main-nav/index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> <?= $t['back'] ?>
                </a>
            </div>
            <h1><i class="fas fa-user-edit"></i> <?= $t['title'] ?></h1>
            <div class="language-switch">
                <button class="language-btn <?= $lang === 'en' ? 'active' : '' ?>" data-lang="en">EN</button>
                <button class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>" data-lang="ar">AR</button>
            </div>
            <div class="theme-toggle">
                <button id="theme-toggle-btn"><i class="fas fa-sun"></i></button>
            </div>
        </div>
    </header>

    <main>
        <?php if (!empty($error_message)): ?>
            <div class="error-message" id="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <div><?= htmlspecialchars($error_message) ?></div>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="success-message" id="success-message">
                <i class="fas fa-check-circle"></i>
                <div><?= htmlspecialchars($success_message) ?></div>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" id="update-role-form">
                <div class="form-group">
                    <label for="faculty_id">
                        <i class="fas fa-user-tie"></i> <?= $t['select_faculty'] ?>
                    </label>
                    <select name="faculty_id" id="faculty_id" required>
                        <option value=""><?= $t['select'] ?></option>
                        <?php foreach ($faculty_members as $faculty): ?>
                            <option value="<?= htmlspecialchars($faculty['faculty_id']) ?>">
                                <?= htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']) ?> - <?= 
                                isset($t['roles'][$faculty['role']]) ? $t['roles'][$faculty['role']] : htmlspecialchars($faculty['role']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="role">
                        <i class="fas fa-user-shield"></i> <?= $t['new_role'] ?>
                    </label>
                    <select name="role" id="role" required>
                        <?php foreach ($t['roles'] as $key => $value): ?>
                            <option value="<?= $key ?>"><?= $value ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <button type="submit" id="submit-btn">
                    <i class="fas fa-save"></i> <?= $t['update_role'] ?>
                </button>
            </form>
        </div>

        <div class="faculty-list-container">
            <button type="button" class="show-faculty-btn" id="show-faculty-btn">
                <i class="fas fa-users"></i> <?= $t['show_faculty'] ?>
            </button>
            
            <div class="faculty-list" id="faculty-list">
                <table>
                    <thead>
                        <tr>
                            <th><?= htmlspecialchars($t['name'] ?? 'Name') ?></th>
                            <th><?= htmlspecialchars($t['department'] ?? 'Department') ?></th>
                            <th><?= htmlspecialchars($t['current_role'] ?? 'Current Role') ?></th>
                            <th><?= htmlspecialchars($t['email'] ?? 'Email') ?></th>
                            <th><?= htmlspecialchars($t['phone'] ?? 'Phone') ?></th>
                            <th><?= htmlspecialchars($t['hod_id'] ?? 'HOD ID') ?></th>
                            <th><?= htmlspecialchars($t['hire_date'] ?? 'Hire Date') ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($faculty_members as $faculty): ?>
                        <tr>
                            <td><?= htmlspecialchars(($faculty['first_name'] ?? '') . ' ' . ($faculty['last_name'] ?? '')) ?></td>
                            <td><?= htmlspecialchars($t['departments'][$faculty['department_id'] ?? ''] ?? ($faculty['department_id'] ?? 'N/A')) ?></td>
                            <td>
                                <?php 
                                $role = $faculty['role'] ?? '';
                                $roleText = match($role) {
                                    'academic_advisor' => $t['roles']['Academic Advisor'] ?? 'Academic Advisor',
                                    'head_of_department' => $t['roles']['Head of Department'] ?? 'Head of Department',
                                    'head of review_committee',
                                    'head_of_review_committee' => $t['roles']['Head Marks Review Committee'] ?? 'Head Marks Review Committee',
                                    'head_of_Academic_Unit' => $t['roles']['Head Academic Advisor Unit'] ?? 'Head Academic Advisor Unit',
                                    'admin' => $t['roles']['Admin'] ?? 'Admin',
                                    default => $role
                                };
                                echo htmlspecialchars($roleText);
                                ?>
                            </td>
                            <td><?= htmlspecialchars($faculty['email'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($faculty['phone_number'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($faculty['hod_id'] ?? 'N/A') ?></td>
                            <td><?= htmlspecialchars($faculty['hire_date'] ?? 'N/A') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date('Y') ?> <?= $t['footer'] ?></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;
            const facultySelect = document.getElementById('faculty_id');
            const roleSelect = document.getElementById('role');
            const submitBtn = document.getElementById('submit-btn');
            const headRoles = ['head_of_department', 'head_of_review_committee', 'head_of_Academic_Unit', 'admin'];
            const langButtons = document.querySelectorAll('.language-btn');
            const errorMessage = document.getElementById('error-message');
            const successMessage = document.getElementById('success-message');
            const showFacultyBtn = document.getElementById('show-faculty-btn');
            const facultyList = document.getElementById('faculty-list');
            const loader = document.getElementById('loader');
            const form = document.getElementById('update-role-form');

            // Theme Toggle
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
            });

            // Faculty selection handler
            facultySelect.addEventListener('change', () => {
                const selectedOption = facultySelect.options[facultySelect.selectedIndex];
                if (!selectedOption.value) return;
                
                const currentRole = selectedOption.text.split(' - ')[1].trim().toLowerCase().replace(/ /g, '_');
                
                // Disable form if current role is a head role
                if (headRoles.includes(currentRole)) {
                    roleSelect.disabled = true;
                    submitBtn.disabled = true;
                    roleSelect.value = '';
                    
                    // Show alert for 2 seconds
                    const alertDiv = document.createElement('div');
                    alertDiv.className = 'error-message';
                    alertDiv.style.position = 'fixed';
                    alertDiv.style.top = '20px';
                    alertDiv.style.left = '50%';
                    alertDiv.style.transform = 'translateX(-50%)';
                    alertDiv.style.zIndex = '1000';
                    alertDiv.innerHTML = `
                        <i class="fas fa-exclamation-triangle"></i>
                        <div><?= $t['errors']['cannot_change'] ?></div>
                    `;
                    document.body.appendChild(alertDiv);
                    
                    setTimeout(() => {
                        alertDiv.style.opacity = '0';
                        setTimeout(() => alertDiv.remove(), 500);
                    }, 2000);
                } else {
                    roleSelect.disabled = false;
                    submitBtn.disabled = false;
                }
            });

            // Language switch handler
            langButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const lang = btn.dataset.lang;
                    window.location.href = `?lang=${lang}`;
                });
            });

            // Auto-hide messages after 2 seconds
            if (errorMessage) {
                setTimeout(() => {
                    errorMessage.style.opacity = '0';
                    setTimeout(() => errorMessage.remove(), 500);
                }, 2000);
            }
            
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.opacity = '0';
                    setTimeout(() => successMessage.remove(), 500);
                }, 2000);
            }
            
            // Toggle faculty list visibility
            if (showFacultyBtn && facultyList) {
                showFacultyBtn.addEventListener('click', () => {
                    facultyList.classList.toggle('show');
                    
                    // Update button text based on visibility
                    if (facultyList.classList.contains('show')) {
                        showFacultyBtn.innerHTML = `
                            <i class="fas fa-users"></i> 
                            <?= $t['hide_faculty'] ?>
                        `;
                    } else {
                        showFacultyBtn.innerHTML = `
                            <i class="fas fa-users"></i> 
                            <?= $t['show_faculty'] ?>
                        `;
                    }
                });
            }
            
            // Form submission handler
            if (form) {
                form.addEventListener('submit', (e) => {
                    // Show loader
                    loader.classList.add('active');
                    
                    // Disable submit button to prevent multiple submissions
                    if (submitBtn) {
                        submitBtn.disabled = true;
                        submitBtn.innerHTML = `
                            <i class="fas fa-spinner fa-spin"></i> 
                            ${submitBtn.textContent.trim()}
                        `;
                    }
                    
                    // The form will continue with its normal submission
                    // The loader will disappear when the page reloads
                });
            }

            // Initialize
            facultySelect.dispatchEvent(new Event('change'));
        });
    </script>
</body>
</html>