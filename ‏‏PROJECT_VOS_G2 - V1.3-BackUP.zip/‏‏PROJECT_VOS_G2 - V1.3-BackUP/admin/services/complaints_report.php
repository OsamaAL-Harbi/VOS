<?php
session_start(); // Start session for language preference

// Set default language if not already set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en'; // Default to English
}

// Handle language switch
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'ar') ? 'ar' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?')); // Redirect to clean URL
    exit();
}

require_once '../db.php';

// Initialize variables
$complaints = [];
$actions_by_complaint = [];
$filtered = false;
$error_message = '';
$departments = [];
$types = [];
$status_counts = [
    'Submited' => 0,
    'In_progress' => 0,
    'Under_review' => 0,
    'Resolved' => 0,
    'Rejected' => 0
];

// Language translations
$translations = [
    'en' => [
        'title' => 'Complaint Report',
        'back' => 'Back to Main Navigation',
        'filterStatus' => 'Filter by Status:',
        'filterDepartment' => 'Filter by Department:',
        'filterType' => 'Filter by Type:',
        'filterDateFrom' => 'From:',
        'filterDateTo' => 'To:',
        'applyFilters' => 'Apply Filters',
        'clearFilters' => 'Clear Filters',
        'export' => 'Export to Excel',
        'showingFiltered' => 'Showing filtered results',
        'totalComplaints' => 'Total Complaints',
        'submitted' => 'Submitted',
        'inProgress' => 'In Progress',
        'underReview' => 'Under Review',
        'resolved' => 'Resolved',
        'rejected' => 'Rejected',
        'noComplaints' => 'No complaints found',
        'clearFiltersLink' => 'Clear filters',
        'complaintDetails' => 'Complaint Details',
        'actionsTaken' => 'Actions Taken',
        'noActions' => 'No actions recorded for this complaint',
        'description' => 'Description:',
        'dateCreated' => 'Date Created:',
        'dateUpdated' => 'Date Updated:',
        'studentId' => 'Student ID:',
        'studentName' => 'Student Name:',
        'courseName' => 'Course Name:',
        'department' => 'Department:',
        'complaintType' => 'Complaint Type:',
        'attachment' => 'Attachment:',
        'viewDetails' => 'View Details',
        'loading' => 'Loading complaints...',
        'footer' => 'Admin Panel. All rights reserved.',
        'statuses' => [
            'Submited' => 'Submitted',
            'In_progress' => 'In Progress',
            'Under_review' => 'Under Review',
            'Resolved' => 'Resolved',
            'Rejected' => 'Rejected'
        ],
        'error' => 'Error:',
        'tryAgain' => 'Try again',
        'contactSupport' => 'or contact support if the problem persists.',
        'allStatuses' => 'All Statuses',
        'allDepartments' => 'All Departments',
        'allTypes' => 'All Types'
    ],
    'ar' => [
        'title' => 'إحصائيات الشكاوى',
        'back' => 'العودة إلى القائمة الرئيسية',
        'filterStatus' => 'تصفية حسب الحالة:',
        'filterDepartment' => 'تصفية حسب القسم:',
        'filterType' => 'تصفية حسب النوع:',
        'filterDateFrom' => 'من:',
        'filterDateTo' => 'إلى:',
        'applyFilters' => 'تطبيق الفلتر',
        'clearFilters' => 'مسح الفلاتر',
        'export' => 'تصدير إلى إكسل',
        'showingFiltered' => 'عرض النتائج المصفاة',
        'totalComplaints' => 'إجمالي الشكاوى',
        'submitted' => 'مقدمة',
        'inProgress' => 'قيد المعالجة',
        'underReview' => 'قيد المراجعة',
        'resolved' => 'تم الحل',
        'rejected' => 'مرفوضة',
        'noComplaints' => 'لا توجد شكاوى',
        'clearFiltersLink' => 'مسح الفلاتر',
        'complaintDetails' => 'تفاصيل الشكوى',
        'actionsTaken' => 'الإجراءات المتخذة',
        'noActions' => 'لا توجد إجراءات مسجلة لهذه الشكوى',
        'description' => 'الوصف:',
        'dateCreated' => 'تاريخ الإنشاء:',
        'dateUpdated' => 'تاريخ التحديث:',
        'studentId' => 'رقم الطالب:',
        'studentName' => 'اسم الطالب:',
        'courseName' => 'اسم المقرر:',
        'department' => 'القسم:',
        'complaintType' => 'نوع الشكوى:',
        'attachment' => 'المرفق:',
        'viewDetails' => 'عرض التفاصيل',
        'loading' => 'جاري تحميل الشكاوى...',
        'footer' => 'لوحة التحكم. جميع الحقوق محفوظة.',
        'statuses' => [
            'Submited' => 'مقدمة',
            'In_progress' => 'قيد المعالجة',
            'Under_review' => 'قيد المراجعة',
            'Resolved' => 'تم الحل',
            'Rejected' => 'مرفوضة'
        ],
        'error' => 'خطأ:',
        'tryAgain' => 'حاول مرة أخرى',
        'contactSupport' => 'أو اتصل بالدعم إذا استمرت المشكلة.',
        'allStatuses' => 'جميع الحالات',
        'allDepartments' => 'جميع الأقسام',
        'allTypes' => 'جميع الأنواع'
    ]
];

$lang = $_SESSION['lang'];
$t = $translations[$lang];

try {
    // Get distinct departments and types for filters
    $meta_query = "
        SELECT DISTINCT complaint_department FROM complaints WHERE complaint_department IS NOT NULL AND complaint_department != ''
        UNION
        SELECT DISTINCT complaint_department FROM complaints WHERE status = 'Submited'
    ";
    $meta_stmt = $pdo->query($meta_query);
    $departments = $meta_stmt->fetchAll(PDO::FETCH_COLUMN);

    $types_query = "SELECT DISTINCT complaint_type FROM complaints WHERE complaint_type IS NOT NULL AND complaint_type != ''";
    $types_stmt = $pdo->query($types_query);
    $types = $types_stmt->fetchAll(PDO::FETCH_COLUMN);

    // Base query for complaints
    $complaints_query = "
        SELECT 
            c.complaint_id,
            c.complaint_description,
            c.status,
            c.created_at,
            c.updated_at,
            c.complainant_id AS student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            c.course_name,
            c.complaint_department AS department_name,
            c.complaint_type,
            c.file_path
        FROM 
            complaints c
        LEFT JOIN 
            students s ON c.complainant_id = s.student_id
    ";

    // Apply filters if they exist
    $where = [];
    $params = [];
    
    if (!empty($_GET['status'])) {
        $where[] = "c.status = ?";
        $params[] = $_GET['status'];
        $filtered = true;
    }
    
    if (!empty($_GET['department'])) {
        $where[] = "c.complaint_department = ?";
        $params[] = $_GET['department'];
        $filtered = true;
    }
    
    if (!empty($_GET['type'])) {
        $where[] = "c.complaint_type = ?";
        $params[] = $_GET['type'];
        $filtered = true;
    }

    // Date range filter
    if (!empty($_GET['start_date']) || !empty($_GET['end_date'])) {
        if (!empty($_GET['start_date']) && !empty($_GET['end_date'])) {
            $where[] = "DATE(c.created_at) BETWEEN ? AND ?";
            $params[] = $_GET['start_date'];
            $params[] = $_GET['end_date'];
        } elseif (!empty($_GET['start_date'])) {
            $where[] = "DATE(c.created_at) >= ?";
            $params[] = $_GET['start_date'];
        } elseif (!empty($_GET['end_date'])) {
            $where[] = "DATE(c.created_at) <= ?";
            $params[] = $_GET['end_date'];
        }
        $filtered = true;
    }

    // Complete query
    if (!empty($where)) {
        $complaints_query .= " WHERE " . implode(" AND ", $where);
    }
    
    $complaints_query .= " ORDER BY c.created_at DESC";

    // Execute query
    $complaints_stmt = $pdo->prepare($complaints_query);
    $complaints_stmt->execute($params);
    $complaints = $complaints_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate status counts
    foreach ($complaints as $complaint) {
        if (isset($status_counts[$complaint['status']])) {
            $status_counts[$complaint['status']]++;
        }
    }
    
    // Get actions for each complaint
    if (!empty($complaints)) {
        $complaint_ids = array_column($complaints, 'complaint_id');
        
        // Get complaint actions
        $actions_query = "
            SELECT 
                ca.*,
                CONCAT(fm_aa.first_name, ' ', fm_aa.last_name) AS action_by_AA_name,
                CONCAT(fm_hod.first_name, ' ', fm_hod.last_name) AS action_by_HOD_name,
                CONCAT(fm_mrc.first_name, ' ', fm_mrc.last_name) AS action_by_MRC_name,
                CONCAT(fm_aau.first_name, ' ', fm_aau.last_name) AS action_by_AAU_name
            FROM complaint_actions ca
            LEFT JOIN faculty_members fm_aa ON ca.action_by_AA = fm_aa.faculty_id
            LEFT JOIN faculty_members fm_hod ON ca.action_by_HOD = fm_hod.faculty_id
            LEFT JOIN faculty_members fm_mrc ON ca.action_by_MRC = fm_mrc.faculty_id
            LEFT JOIN faculty_members fm_aau ON ca.action_by_AAU = fm_aau.faculty_id
            WHERE ca.complaint_id IN (" . implode(',', array_fill(0, count($complaint_ids), '?')) . ")
            ORDER BY ca.action_date DESC
        ";
        
        $actions_stmt = $pdo->prepare($actions_query);
        $actions_stmt->execute($complaint_ids);
        $all_actions = $actions_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Organize actions by complaint_id
        $actions_by_complaint = [];
        foreach ($all_actions as $action) {
            $actions_by_complaint[$action['complaint_id']][] = $action;
        }
    }
    
} catch (PDOException $e) {
    error_log("Database error in complaints_report.php: " . $e->getMessage());
    $error_message = "An error occurred while fetching complaint data. Please try again later. If the problem persists, contact technical support.";
} catch (Exception $e) {
    error_log("General error in complaints_report.php: " . $e->getMessage());
    $error_message = "An unexpected error occurred. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $lang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Admin Panel</title>
    <link rel="stylesheet" href="../CSS/complaints_report.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <style>
        /* RTL specific styles */
        html[dir="rtl"] .filter-section select,
        html[dir="rtl"] .filter-section input[type="date"] {
            text-align: right;
        }
        html[dir="rtl"] .stat-card {
            margin-left: 10px;
            margin-right: 0;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="header-content">
            <div class="back-to-main">
                <a href="../main-nav/index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> <?= $t['back'] ?>
                </a>
            </div>
            <h1><i class="fas fa-file-alt"></i> <?= $t['title'] ?></h1>
            <div class="language-switch">
                <button class="language-btn <?= $lang === 'en' ? 'active' : '' ?>" data-lang="en">EN</button>
                <button class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>" data-lang="ar">AR</button>
            </div>
            <div class="theme-toggle">
                <button id="theme-toggle-btn"><i class="fas fa-sun"></i></button>
            </div>
        </div>
    </header>

    <main>
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong><?= $t['error'] ?></strong> <?= htmlspecialchars($error_message) ?>
                    <div style="font-size: 0.9rem; margin-top: 0.5rem;">
                        <a href="javascript:window.location.reload()" style="color: white; text-decoration: underline;"><?= $t['tryAgain'] ?></a> <?= $t['contactSupport'] ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <form method="GET" action="" id="filter-form">
            <div class="filter-section">
                <label for="status-filter"><i class="fas fa-filter"></i> <?= $t['filterStatus'] ?></label>
                <select id="status-filter" name="status">
                    <option value=""><?= $t['allStatuses'] ?></option>
                    <option value="Submited" <?= (!empty($_GET['status']) && $_GET['status'] === 'Submited') ? 'selected' : '' ?>><?= $t['statuses']['Submited'] ?></option>
                    <option value="In_progress" <?= (!empty($_GET['status']) && $_GET['status'] === 'In_progress') ? 'selected' : '' ?>><?= $t['statuses']['In_progress'] ?></option>
                    <option value="Under_review" <?= (!empty($_GET['status']) && $_GET['status'] === 'Under_review') ? 'selected' : '' ?>><?= $t['statuses']['Under_review'] ?></option>
                    <option value="Resolved" <?= (!empty($_GET['status']) && $_GET['status'] === 'Resolved') ? 'selected' : '' ?>><?= $t['statuses']['Resolved'] ?></option>
                    <option value="Rejected" <?= (!empty($_GET['status']) && $_GET['status'] === 'Rejected') ? 'selected' : '' ?>><?= $t['statuses']['Rejected'] ?></option>
                </select>

                <label for="department-filter"><i class="fas fa-building"></i> <?= $t['filterDepartment'] ?></label>
                <select id="department-filter" name="department">
                    <option value=""><?= $t['allDepartments'] ?></option>
                    <?php foreach ($departments as $department): ?>
                        <option value="<?= htmlspecialchars($department) ?>" <?= (!empty($_GET['department']) && $_GET['department'] === $department ? 'selected' : '' )?>>
                            <?= htmlspecialchars($department) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="type-filter"><i class="fas fa-tags"></i> <?= $t['filterType'] ?></label>
                <select id="type-filter" name="type">
                    <option value=""><?= $t['allTypes'] ?></option>
                    <?php foreach ($types as $type): ?>
                        <option value="<?= htmlspecialchars($type) ?>" <?= (!empty($_GET['type']) && $_GET['type'] === $type ? 'selected' : '' )?>>
                            <?= htmlspecialchars($type) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <div class="date-range-container">
                    <label for="start-date"><i class="fas fa-calendar"></i> <?= $t['filterDateFrom'] ?></label>
                    <input type="date" id="start-date" name="start_date" value="<?= !empty($_GET['start_date']) ? htmlspecialchars($_GET['start_date']) : '' ?>">
                    <label for="end-date"><?= $t['filterDateTo'] ?></label>
                    <input type="date" id="end-date" name="end_date" value="<?= !empty($_GET['end_date']) ? htmlspecialchars($_GET['end_date']) : '' ?>">
                </div>

                <button type="submit" id="apply-filters" class="btn-apply">
                    <i class="fas fa-filter"></i> <?= $t['applyFilters'] ?>
                </button>
                
                <button type="button" id="clear-filters">
                    <i class="fas fa-sync-alt"></i> <?= $t['clearFilters'] ?>
                </button>
                
                <button type="button" id="export-btn" class="btn-export">
                    <i class="fas fa-file-excel"></i> <?= $t['export'] ?>
                </button>
            </div>
        </form>

        <?php if ($filtered): ?>
            <div class="filter-indicator">
                <i class="fas fa-info-circle"></i> <?= $t['showingFiltered'] ?>
                <button onclick="window.location.href=window.location.pathname" style="margin-left: 10px; background: none; border: none; color: white; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        <?php endif; ?>

        <div class="stats-summary">
            <div class="stat-card">
                <div class="stat-label"><?= $t['totalComplaints'] ?></div>
                <div class="stat-value"><?= count($complaints) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['submitted'] ?></div>
                <div class="stat-value"><?= $status_counts['Submited'] ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['inProgress'] ?></div>
                <div class="stat-value"><?= $status_counts['In_progress'] ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['underReview'] ?></div>
                <div class="stat-value"><?= $status_counts['Under_review'] ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['resolved'] ?></div>
                <div class="stat-value"><?= $status_counts['Resolved'] ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['rejected'] ?></div>
                <div class="stat-value"><?= $status_counts['Rejected'] ?></div>
            </div>
        </div>

        <!-- Loading Spinner -->
        <div class="loading-spinner" id="loading-spinner">
            <div class="spinner"></div>
            <p><?= $t['loading'] ?></p>
        </div>

        <!-- Complaint Cards -->
        <div class="complaint-cards" id="complaints-cards-container">
            <?php if (!empty($complaints)): ?>
                <?php foreach ($complaints as $complaint): ?>
                    <div class="complaint-card"
                        data-status="<?= htmlspecialchars($complaint['status'] ?? '') ?>"
                        data-department="<?= htmlspecialchars($complaint['department_name'] ?? '') ?>"
                        data-type="<?= htmlspecialchars($complaint['complaint_type'] ?? '') ?>"
                        data-student-id="<?= htmlspecialchars($complaint['student_id'] ?? '') ?>"
                        data-course-name="<?= htmlspecialchars($complaint['course_name'] ?? '') ?>"
                        data-file-path="<?= htmlspecialchars($complaint['file_path'] ?? '') ?>">
                        <div class="card-header">
                            <h3><i class="fas fa-id-card"></i> <?= $t['complaintDetails'] ?> ID: <?= htmlspecialchars($complaint['complaint_id']) ?></h3>
                            <span class="status-badge <?= htmlspecialchars($complaint['status']) ?>">
                                <?= $t['statuses'][$complaint['status']] ?>
                            </span>
                        </div>
                        <div class="card-body">
                            <p><i class="fas fa-align-left"></i><strong><?= $t['description'] ?></strong> <?= !empty($complaint['complaint_description']) ? htmlspecialchars($complaint['complaint_description']) : 'N/A' ?></p>
                            <p><i class="fas fa-calendar-alt"></i><strong><?= $t['dateCreated'] ?></strong> <?= !empty($complaint['created_at']) ? date('M j, Y g:i A', strtotime($complaint['created_at'])) : 'N/A' ?></p>
                            <p><i class="fas fa-calendar-check"></i><strong><?= $t['dateUpdated'] ?></strong> <?= !empty($complaint['updated_at']) ? date('M j, Y g:i A', strtotime($complaint['updated_at'])) : 'N/A' ?></p>
                            <p><i class="fas fa-user-graduate"></i><strong><?= $t['studentName'] ?></strong> <?= !empty($complaint['student_name']) ? htmlspecialchars($complaint['student_name']) : 'N/A' ?></p>
                            <p><i class="fas fa-building"></i><strong><?= $t['department'] ?></strong> <?= !empty($complaint['department_name']) ? htmlspecialchars($complaint['department_name']) : 'N/A' ?></p>
                        </div>
                        <div class="card-footer">
                            <button class="view-details-btn" data-complaint-id="<?= htmlspecialchars($complaint['complaint_id']) ?>">
                                <i class="fas fa-eye"></i> <?= $t['viewDetails'] ?>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <div><?= $t['noComplaints'] ?></div>
                    <?php if ($filtered): ?>
                        <a href="javascript:window.location.href=window.location.pathname" style="color: var(--primary-color); text-decoration: underline;"><?= $t['clearFiltersLink'] ?></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Complaint Details Modal -->
    <div id="complaintModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="modal-header">
                <h2><i class="fas fa-file-alt"></i> <?= $t['complaintDetails'] ?></h2>
            </div>
            <div class="modal-body" id="modalComplaintDetails"></div>
            <div class="actions-container">
                <h3><i class="fas fa-tasks"></i> <?= $t['actionsTaken'] ?></h3>
                <div id="modalComplaintActions"></div>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date('Y') ?> <?= $t['footer'] ?></p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;
            const loadingSpinner = document.getElementById('loading-spinner');
            const filterForm = document.getElementById('filter-form');
            const applyFiltersBtn = document.getElementById('apply-filters');
            const clearFiltersBtn = document.getElementById('clear-filters');
            const exportBtn = document.getElementById('export-btn');
            const modal = document.getElementById('complaintModal');
            const modalDetails = document.getElementById('modalComplaintDetails');
            const modalActions = document.getElementById('modalComplaintActions');
            const closeBtn = document.querySelector('.close');
            const viewDetailsBtns = document.querySelectorAll('.view-details-btn');
            const langButtons = document.querySelectorAll('.language-btn');

            // Store translations from PHP
            const translations = <?php echo json_encode($translations, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
            const currentLang = '<?= $lang ?>';
            const t = translations[currentLang];

            // Store actions data from PHP
            const actionsByComplaint = <?php echo json_encode($actions_by_complaint, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;

            // Theme Toggle Functionality
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
            });

            // Language switch handler
            langButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const lang = btn.dataset.lang;
                    window.location.href = `?lang=${lang}`;
                });
            });

            // Filter Functionality
            function applyFilters() {
                loadingSpinner.style.display = 'block';
                document.getElementById('complaints-cards-container').style.display = 'none';
                
                const startDate = document.getElementById('start-date').value;
                const endDate = document.getElementById('end-date').value;
                
                if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
                    Toastify({
                        text: currentLang === 'ar' ? "يجب أن يكون تاريخ النهاية بعد تاريخ البداية" : "End date must be after start date",
                        duration: 3000,
                        close: true,
                        gravity: "top",
                        position: currentLang === 'ar' ? "left" : "right",
                        backgroundColor: "var(--error-color)",
                    }).showToast();
                    loadingSpinner.style.display = 'none';
                    document.getElementById('complaints-cards-container').style.display = 'grid';
                    return;
                }
                
                filterForm.submit();
            }

            function clearFilters() {
                window.location.href = window.location.pathname;
            }

            applyFiltersBtn.addEventListener('click', applyFilters);
            clearFiltersBtn.addEventListener('click', clearFilters);

            // Export to Excel functionality
            exportBtn.addEventListener('click', () => {
                const complaints = <?php echo json_encode($complaints, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>;
                
                // Prepare data for export
                const data = complaints.map(complaint => ({
                    'Complaint ID': complaint.complaint_id,
                    'Status': t['statuses'][complaint.status] || complaint.status,
                    'Description': complaint.complaint_description,
                    'Date Created': complaint.created_at,
                    'Date Updated': complaint.updated_at,
                    'Student ID': complaint.student_id,
                    'Student Name': complaint.student_name,
                    'Course Name': complaint.course_name,
                    'Department': complaint.department_name,
                    'Complaint Type': complaint.complaint_type,
                    'Attachment': complaint.file_path ? 'Yes' : 'No'
                }));
                
                // Create worksheet
                const ws = XLSX.utils.json_to_sheet(data);
                
                // Create workbook
                const wb = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(wb, ws, "Complaints");
                
                // Generate file and download
                const fileName = `Complaints_Report_${new Date().toISOString().slice(0,10)}.xlsx`;
                XLSX.writeFile(wb, fileName);
                
                Toastify({
                    text: currentLang === 'ar' ? "تم تصدير البيانات بنجاح" : "Data exported successfully",
                    duration: 2000,
                    close: true,
                    gravity: "top",
                    position: currentLang === 'ar' ? "left" : "right",
                    backgroundColor: "var(--success-color)",
                }).showToast();
            });

        // Modal Functionality
        function openComplaintModal(complaintId) {
            const card = document.querySelector(`.view-details-btn[data-complaint-id="${complaintId}"]`).closest('.complaint-card');
            
            // Set complaint details in modal
            modalDetails.innerHTML = `
                <p><i class="fas fa-id-card"></i><strong>${t['complaintDetails']} ID:</strong> ${complaintId}</p>
                <p><i class="fas fa-align-left"></i><strong>${t['description']}:</strong> ${card.querySelector('.card-body p:nth-child(1)').textContent.replace(t['description']+':', '').trim()}</p>
                <p><i class="fas fa-calendar-alt"></i><strong>${t['dateCreated']}:</strong> ${card.querySelector('.card-body p:nth-child(2)').textContent.replace(t['dateCreated']+':', '').trim()}</p>
                <p><i class="fas fa-calendar-check"></i><strong>${t['dateUpdated']}:</strong> ${card.querySelector('.card-body p:nth-child(3)').textContent.replace(t['dateUpdated']+':', '').trim()}</p>
                <p><i class="fas fa-user"></i><strong>${t['studentId']}:</strong> ${card.dataset.studentId || 'N/A'}</p>
                <p><i class="fas fa-user-graduate"></i><strong>${t['studentName']}:</strong> ${card.querySelector('.card-body p:nth-child(4)').textContent.replace(t['studentName']+':', '').trim()}</p>
                <p><i class="fas fa-book"></i><strong>${t['courseName']}:</strong> ${card.dataset.courseName || 'N/A'}</p>
                <p><i class="fas fa-building"></i><strong>${t['department']}:</strong> ${card.querySelector('.card-body p:nth-child(5)').textContent.replace(t['department']+':', '').trim()}</p>
                <p><i class="fas fa-tag"></i><strong>${t['complaintType']}:</strong> ${card.dataset.type || 'N/A'}</p>
                <p><i class="fas fa-file"></i><strong>${t['attachment']}:</strong> ${card.dataset.filePath ? `<a href="${card.dataset.filePath}" target="_blank">${currentLang === 'ar' ? 'عرض الملف' : 'View File'}</a>` : 'None'}</p>
            `;

            // Set actions in modal
            const actions = actionsByComplaint[complaintId] || [];
            if (actions.length > 0) {
                let actionsHTML = '';
                actions.forEach((action, index) => {
                    // Get all available comments
                    const comments = [];
                    
                    if (action.AA_comment) {
                        comments.push({
                            label: currentLang === 'ar' ? 'تعليق المستشار الأكاديمي' : 'Academic Advisor Comment',
                            text: action.AA_comment
                        });
                    }
                    
                    if (action.HOD_comment) {
                        comments.push({
                            label: currentLang === 'ar' ? 'تعليق رئيس القسم' : 'HOD Comment',
                            text: action.HOD_comment
                        });
                    }
                    
                    if (action.MRC_comment) {
                        comments.push({
                            label: currentLang === 'ar' ? 'تعليق لجنة المراجعة' : 'MRC Comment',
                            text: action.MRC_comment
                        });
                    }
                    
                    if (action.AAU_comment) {
                        comments.push({
                            label: currentLang === 'ar' ? 'تعليق وحدة المستشارين' : 'AAU Comment',
                            text: action.AAU_comment
                        });
                    }

                    // Determine who took the action
                    let actionTaker = '';
                    if (action.action_by_AA_name) {
                        actionTaker = `${currentLang === 'ar' ? 'المستشار الأكاديمي: ' : 'Academic Advisor: '}${action.action_by_AA_name}`;
                    } else if (action.action_by_HOD_name) {
                        actionTaker = `${currentLang === 'ar' ? 'رئيس القسم: ' : 'HOD: '}${action.action_by_HOD_name}`;
                    } else if (action.action_by_MRC_name) {
                        actionTaker = `${currentLang === 'ar' ? 'لجنة مراجعة العلامات: ' : 'MRC: '}${action.action_by_MRC_name}`;
                    } else if (action.action_by_AAU_name) {
                        actionTaker = `${currentLang === 'ar' ? 'وحدة المستشارين الأكاديميين: ' : 'AAU: '}${action.action_by_AAU_name}`;
                    } else {
                        actionTaker = currentLang === 'ar' ? 'غير معروف' : 'Unknown';
                    }

                    // Format the date based on language
                    const actionDate = new Date(action.action_date);
                    const formattedDate = currentLang === 'ar' ? 
                        actionDate.toLocaleString('ar-SA', { timeZone: 'Asia/Riyadh' }) : 
                        actionDate.toLocaleString();

                    actionsHTML += `
                        <div class="action-item" data-action-type="${action.action_type}">
                            <h4>${currentLang === 'ar' ? 'الإجراء #' : 'Action #'}${index + 1} (${action.action_type})</h4>
                            <p><strong>${currentLang === 'ar' ? 'تم اتخاذه بواسطة:' : 'Taken by:'}</strong> ${actionTaker}</p>
                            <p><strong>${currentLang === 'ar' ? 'التاريخ:' : 'Date:'}</strong> ${formattedDate}</p>
                            
                            <div class="action-comments">
                                ${comments.length > 0 ? 
                                    comments.map(comment => `
                                        <div class="comment">
                                            <strong>${comment.label}:</strong> ${comment.text}
                                        </div>
                                    `).join('') : 
                                    `<div class="no-comment">${currentLang === 'ar' ? 'لا يوجد تعليقات' : 'No comments'}</div>`
                                }
                            </div>
                        </div>
                    `;
                });
                modalActions.innerHTML = actionsHTML;
            } else {
                modalActions.innerHTML = `<p class="no-actions">${t['noActions']}</p>`;
            }

            modal.style.display = 'block';
        }

            // Add event listeners to view buttons
            document.querySelectorAll('.view-details-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const complaintId = e.currentTarget.dataset.complaintId;
                    openComplaintModal(complaintId);
                });
            });

            closeBtn.addEventListener('click', () => {
                modal.style.display = 'none';
            });

            window.addEventListener('click', (event) => {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            });

            // Initialize filters based on URL parameters
            function initializeFilters() {
                const urlParams = new URLSearchParams(window.location.search);
                const statusFilter = document.getElementById('status-filter');
                const departmentFilter = document.getElementById('department-filter');
                const typeFilter = document.getElementById('type-filter');
                const startDate = document.getElementById('start-date');
                const endDate = document.getElementById('end-date');
                
                if (urlParams.has('status')) statusFilter.value = urlParams.get('status');
                if (urlParams.has('department')) departmentFilter.value = urlParams.get('department');
                if (urlParams.has('type')) typeFilter.value = urlParams.get('type');
                if (urlParams.has('start_date')) startDate.value = urlParams.get('start_date');
                if (urlParams.has('end_date')) endDate.value = urlParams.get('end_date');
            }

            initializeFilters();
        });
    </script>
</body>
</html>