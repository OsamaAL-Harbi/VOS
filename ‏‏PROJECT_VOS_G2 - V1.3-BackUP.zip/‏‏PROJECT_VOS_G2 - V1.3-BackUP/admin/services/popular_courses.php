<?php
require_once '../db.php';

// Language handling
$lang = 'en'; // Default language
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ar'])) {
    $lang = $_GET['lang'];
    setcookie('lang', $lang, time() + (86400 * 30), "/"); // Store for 30 days
} elseif (isset($_COOKIE['lang'])) {
    $lang = $_COOKIE['lang'];
}

// Handle language switch
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'ar') ? 'ar' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?')); // Redirect to clean URL
    exit();
}

// Translations
$translations = [
    'en' => [
        'title' => 'Most Popular Courses',
        'back_to_main' => 'Back to Main Navigation',
        'total_courses' => 'Total Courses Tracked',
        'highest_enrollment' => 'Highest Enrollment',
        'top_courses' => 'Top 5 Most Popular Courses',
        'course_name' => 'Course Name',
        'enrollment_count' => 'Enrollment Count',
        'no_data' => 'No popular courses found',
        'filter' => 'Filter',
        'all' => 'All',
        'apply' => 'Apply',
        'reset' => 'Reset',
        'footer' => 'Admin Panel. All rights reserved.'
    ],
    'ar' => [
        'title' => 'أكثر المواد شعبية',
        'back_to_main' => 'العودة إلى القائمة الرئيسية',
        'total_courses' => 'إجمالي المواد المتابعة',
        'highest_enrollment' => 'أعلى تسجيل',
        'top_courses' => 'أهم 5 مواد شعبية',
        'course_name' => 'اسم المادة',
        'enrollment_count' => 'عدد المسجلين',
        'no_data' => 'لا توجد مواد شعبية',
        'filter' => 'تصفية',
        'all' => 'الكل',
        'apply' => 'تطبيق',
        'reset' => 'إعادة تعيين',
        'footer' => 'لوحة التحكم. جميع الحقوق محفوظة.'
    ]
];

$t = $translations[$lang];
$dir = $lang === 'ar' ? 'rtl' : 'ltr';

// Initialize variables
$popular_courses = [];
$all_courses = [];
$error_message = '';

try {
    // Get all courses for filter dropdown
    $stmt = $pdo->query("SELECT DISTINCT course_name FROM courses ORDER BY course_name");
    $all_courses = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Build base query
    $query = "
        SELECT co.course_name, COUNT(ce.enrollment_id) AS enrollment_count
        FROM enrollments ce
        JOIN courses co ON ce.course_id = co.course_id
    ";

    // Apply filters if set
    $params = [];
    if (isset($_GET['course']) && $_GET['course'] !== '') {
        $query .= " WHERE co.course_name = :course_name";
        $params[':course_name'] = $_GET['course'];
    }

    // Complete query
    $query .= " GROUP BY co.course_name ORDER BY enrollment_count DESC LIMIT 5";

    // Get the 5 most popular courses by enrollment count
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $popular_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Database error in popular_courses.php: " . $e->getMessage());
    $error_message = $lang === 'en' ? 
        "An error occurred while fetching course data. Please try again later." : 
        "حدث خطأ أثناء جلب بيانات المواد. يرجى المحاولة مرة أخرى لاحقًا.";
} catch (Exception $e) {
    error_log("General error in popular_courses.php: " . $e->getMessage());
    $error_message = $lang === 'en' ? 
        "An unexpected error occurred. Please try again later." : 
        "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى لاحقًا.";
}
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a76a8;
            --primary-hover: #3a5f8a;
            --secondary-color: #28a745;
            --secondary-hover: #218838;
            --error-color: #e74c3c;
            --error-hover: #c0392b;
            --warning-color: #f39c12;
            --warning-hover: #e67e22;
            --info-color: #3498db;
            --info-hover: #2980b9;
            --success-color: #2ecc71;
            --success-hover: #27ae60;
            --background-color: #f8f9fa;
            --card-background: #ffffff;
            --text-color: #212529;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }

        .dark-theme {
            --primary-color: #34495e;
            --primary-hover: #2c3e50;
            --secondary-color: #218838;
            --secondary-hover: #1e7e34;
            --error-color: #c0392b;
            --error-hover: #a5281b;
            --warning-color: #e67e22;
            --warning-hover: #d35400;
            --info-color: #2980b9;
            --info-hover: #2472a4;
            --success-color: #27ae60;
            --success-hover: #219653;
            --background-color: #1a1a1a;
            --card-background: #2d2d2d;
            --text-color: #f8f9fa;
            --text-muted: #adb5bd;
            --border-color: #444;
            --shadow-color: rgba(0, 0, 0, 0.3);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        [dir="rtl"] body {
            font-family: 'Tahoma', Arial, sans-serif;
        }

        /* Header Styles */
        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem;
            box-shadow: 0 2px 10px var(--shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        h1 {
            margin: 0;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-grow: 1;
            justify-content: center;
        }

        /* Theme Toggle */
        .theme-toggle {
            position: absolute;
            right: 1rem;
        }

        [dir="rtl"] .theme-toggle {
            right: auto;
            left: 1rem;
        }

        .theme-toggle button {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .theme-toggle button:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* Language Toggle */
        .language-toggle {
            position: absolute;
            right: 4rem;
        }

        [dir="rtl"] .language-toggle {
            right: auto;
            left: 4rem;
        }

        .language-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .language-btn.active {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .language-btn:hover:not(.active) {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* Back Button */
        .back-to-main {
            position: absolute;
            left: 1rem;
        }

        [dir="rtl"] .back-to-main {
            left: auto;
            right: 1rem;
        }

        .btn-back {
            color: white;
            text-decoration: none;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: background-color 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-back:hover {
            background-color: rgba(255, 255, 255, 0.3);
        }

        /* Main Content */
        main {
            flex: 1;
            padding: 2rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        /* Error Message */
        .error-message {
            background-color: var(--error-color);
            color: white;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .error-message i {
            font-size: 1.2rem;
        }

        /* Filter Section */
        .filter-section {
            background-color: var(--card-background);
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 5px var(--shadow-color);
            margin-bottom: 1.5rem;
        }

        .filter-section h2 {
            margin-top: 0;
            margin-bottom: 1rem;
            font-size: 1.25rem;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .filter-group label {
            font-weight: 600;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .filter-select {
            padding: 0.5rem;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            background-color: var(--card-background);
            color: var(--text-color);
            min-width: 200px;
        }

        .filter-buttons {
            display: flex;
            gap: 0.75rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
        }

        .btn-secondary {
            background-color: var(--border-color);
            color: var(--text-color);
        }

        .btn-secondary:hover {
            background-color: var(--text-muted);
            color: white;
        }

        /* Stats Summary */
        .stats-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background-color: var(--card-background);
            border-radius: 8px;
            padding: 1rem;
            flex: 1;
            min-width: 150px;
            box-shadow: 0 2px 5px var(--shadow-color);
            text-align: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
        }

        .stat-value {
            font-size: 1.5rem;
            font-weight: bold;
            color: var(--primary-color);
            margin: 0.5rem 0;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        /* Table Styles */
        .table-container {
            background-color: var(--card-background);
            border-radius: 8px;
            box-shadow: 0 2px 5px var(--shadow-color);
            overflow: hidden;
            margin-top: 1.5rem;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th, .data-table td {
            padding: 1rem;
            text-align: <?= $dir === 'rtl' ? 'right' : 'left' ?>;
            border-bottom: 1px solid var(--border-color);
        }

        .data-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
        }

        .data-table tr:last-child td {
            border-bottom: none;
        }

        .data-table tr:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 2rem;
            font-size: 1.2rem;
            color: var(--text-muted);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
        }

        .no-data i {
            font-size: 2rem;
            color: var(--warning-color);
        }

        /* Section Header */
        .section-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .section-header h2 {
            margin: 0;
            font-size: 1.5rem;
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 1.5rem;
            background-color: var(--primary-color);
            color: white;
            margin-top: 3rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
            }
            
            h1 {
                font-size: 1.5rem;
                order: 2;
                margin: 0.5rem 0;
            }
            
            .back-to-main {
                position: static;
                order: 1;
                align-self: flex-start;
            }
            
            .language-toggle, .theme-toggle {
                position: static;
                order: 3;
                align-self: flex-end;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-buttons {
                justify-content: flex-end;
            }
            
            .data-table {
                display: block;
                overflow-x: auto;
            }
            
            .stat-card {
                min-width: 100%;
            }
        }

        @media (max-width: 480px) {
            .data-table th, .data-table td {
                padding: 0.75rem 0.5rem;
                font-size: 0.9rem;
            }
            
            .filter-select {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="header-content">
            <div class="back-to-main">
                <a href="../main-nav/index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> <?= $t['back_to_main'] ?>
                </a>
            </div>
            <h1><i class="fas fa-chart-line"></i> <?= $t['title'] ?></h1>
            <div class="language-toggle">
                <a href="?lang=en<?= isset($_GET['course']) ? '&course=' . urlencode($_GET['course']) : '' ?>" class="language-btn <?= $lang === 'en' ? 'active' : '' ?>">EN</a>
                <a href="?lang=ar<?= isset($_GET['course']) ? '&course=' . urlencode($_GET['course']) : '' ?>" class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>">AR</a>
            </div>
            <div class="theme-toggle">
                <button id="theme-toggle-btn"><i class="fas fa-sun"></i></button>
            </div>
        </div>
    </header>

    <main>
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong><?= $lang === 'en' ? 'Error:' : 'خطأ:' ?></strong> <?= htmlspecialchars($error_message) ?>
                    <div style="font-size: 0.9rem; margin-top: 0.5rem;">
                        <a href="javascript:window.location.reload()" style="color: white; text-decoration: underline;">
                            <?= $lang === 'en' ? 'Try again' : 'حاول مرة أخرى' ?>
                        </a>
                        <?= $lang === 'en' ? 'or contact support if the problem persists.' : 'أو اتصل بالدعم إذا استمرت المشكلة.' ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filter Section -->
        <section class="filter-section">
            <h2><i class="fas fa-filter"></i> <?= $t['filter'] ?></h2>
            <form method="GET" class="filter-form">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <div class="filter-group">
                    <label for="course-filter"><i class="fas fa-book"></i> <?= $t['course_name'] ?></label>
                    <select id="course-filter" name="course" class="filter-select">
                        <option value=""><?= $t['all'] ?></option>
                        <?php foreach ($all_courses as $course): ?>
                            <option value="<?= htmlspecialchars($course) ?>" <?= isset($_GET['course']) && $_GET['course'] === $course ? 'selected' : '' ?>>
                                <?= htmlspecialchars($course) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> <?= $t['apply'] ?>
                    </button>
                    <a href="popular_courses.php?lang=<?= $lang ?>" class="btn btn-secondary">
                        <i class="fas fa-undo"></i> <?= $t['reset'] ?>
                    </a>
                </div>
            </form>
        </section>

        <!-- Stats Summary -->
        <div class="stats-summary">
            <div class="stat-card">
                <div class="stat-label"><?= $t['total_courses'] ?></div>
                <div class="stat-value"><?= count($popular_courses) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['highest_enrollment'] ?></div>
                <div class="stat-value"><?= !empty($popular_courses) ? max(array_column($popular_courses, 'enrollment_count')) : '0' ?></div>
            </div>
        </div>

        <!-- Popular Courses Table -->
        <div class="section-header">
            <i class="fas fa-list-ol"></i>
            <h2><?= $t['top_courses'] ?></h2>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-book"></i> <?= $t['course_name'] ?></th>
                        <th><i class="fas fa-users"></i> <?= $t['enrollment_count'] ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_courses)): ?>
                        <?php foreach ($popular_courses as $course): ?>
                            <tr>
                                <td><i class="fas fa-book-open"></i> <?= htmlspecialchars($course['course_name']) ?></td>
                                <td><?= htmlspecialchars($course['enrollment_count']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="no-data">
                                <i class="fas fa-exclamation-circle"></i> <?= $t['no_data'] ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date('Y') ?> <?= $t['footer'] ?></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;

            // Load saved theme from localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }

            // Toggle theme on button click
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
            });
        });
    </script>
</body>
</html>