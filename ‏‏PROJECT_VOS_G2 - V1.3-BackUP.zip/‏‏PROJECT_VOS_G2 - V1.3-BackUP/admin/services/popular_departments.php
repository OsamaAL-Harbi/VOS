<?php
require_once '../db.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Language handling
$lang = 'en'; // Default language
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ar'])) {
    $lang = $_GET['lang'];
    setcookie('lang', $lang, time() + (86400 * 30), "/"); // Store for 30 days
} elseif (isset($_COOKIE['lang'])) {
    $lang = $_COOKIE['lang'];
}

// Translations
$translations = [
    'en' => [
        'title' => 'Popular Departments',
        'back_to_main' => 'Back to Main Navigation',
        'total_departments' => 'Total Departments',
        'highest_faculty' => 'Highest Faculty',
        'highest_courses' => 'Highest Courses',
        'highest_students' => 'Highest Students',
        'most_faculty' => 'Most Faculty',
        'most_courses' => 'Most Courses',
        'most_students' => 'Most Students',
        'department_name' => 'Department Name',
        'faculty' => 'Faculty',
        'courses' => 'Courses',
        'students' => 'Students',
        'no_data' => 'No departments found',
        'footer' => 'Admin Panel. All rights reserved.',
        'error' => 'Error',
        'try_again' => 'Try again',
        'contact_support' => 'or contact support if the problem persists.',
        'loading' => 'Loading data...'
    ],
    'ar' => [
        'title' => 'الأقسام الشعبية',
        'back_to_main' => 'العودة إلى القائمة الرئيسية',
        'total_departments' => 'إجمالي الأقسام',
        'highest_faculty' => 'أعلى هيئة تدريس',
        'highest_courses' => 'أعلى عدد مواد',
        'highest_students' => 'أعلى عدد طلاب',
        'most_faculty' => 'أعضاء هيئة التدريس',
        'most_courses' => 'المواد الدراسية',
        'most_students' => 'الطلاب',
        'department_name' => 'اسم القسم',
        'faculty' => 'هيئة التدريس',
        'courses' => 'المواد',
        'students' => 'الطلاب',
        'no_data' => 'لا توجد أقسام',
        'footer' => 'لوحة التحكم. جميع الحقوق محفوظة.',
        'error' => 'خطأ',
        'try_again' => 'حاول مرة أخرى',
        'contact_support' => 'أو اتصل بالدعم إذا استمرت المشكلة.',
        'loading' => 'جاري تحميل البيانات...'
    ]
];

$t = $translations[$lang];
$dir = $lang === 'ar' ? 'rtl' : 'ltr';

// Initialize variables
$popular_departments = [];
$error_message = '';
$total_departments = 0;
$highest_faculty = 0;
$highest_courses = 0;
$highest_students = 0;

try {
    // Default sorting: Most Faculty
    $orderBy = isset($_GET['sort']) ? $_GET['sort'] : 'faculty_count';
    $validSortOptions = ['faculty_count', 'course_count', 'student_count'];
    if (!in_array($orderBy, $validSortOptions)) {
        $orderBy = 'faculty_count';
    }

    $stmt = $pdo->prepare("SELECT 
            d.department_name, 
            COUNT(DISTINCT f.faculty_id) AS faculty_count,
            COUNT(DISTINCT c.course_id) AS course_count,
            COUNT(DISTINCT s.student_id) AS student_count
        FROM departments d
        LEFT JOIN faculty_members f ON d.department_id = f.department_id
        LEFT JOIN courses c ON d.department_id = c.department_id
        LEFT JOIN students s ON d.department_id = s.department_id
        GROUP BY d.department_name
        ORDER BY $orderBy DESC
        LIMIT 5");
    $stmt->execute();
    $popular_departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate statistics
    if (!empty($popular_departments)) {
        $total_departments = count($popular_departments);
        $highest_faculty = max(array_column($popular_departments, 'faculty_count'));
        $highest_courses = max(array_column($popular_departments, 'course_count'));
        $highest_students = max(array_column($popular_departments, 'student_count'));
    }

} catch (PDOException $e) {
    error_log("Database error in popular_departments.php: " . $e->getMessage());
    $error_message = $t['error'] . ": " . ($lang === 'en' ? 
        "An error occurred while fetching department data. Please try again later." : 
        "حدث خطأ أثناء جلب بيانات الأقسام. يرجى المحاولة مرة أخرى لاحقًا.");
} catch (Exception $e) {
    error_log("General error in popular_departments.php: " . $e->getMessage());
    $error_message = $t['error'] . ": " . ($lang === 'en' ? 
        "An unexpected error occurred. Please try again later." : 
        "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى لاحقًا.");
}
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a76a8;
            --primary-hover: #3a5f8a;
            --secondary-color: #28a745;
            --secondary-hover: #218838;
            --error-color: #e74c3c;
            --error-hover: #c0392b;
            --warning-color: #f39c12;
            --warning-hover: #e67e22;
            --info-color: #3498db;
            --info-hover: #2980b9;
            --success-color: #2ecc71;
            --success-hover: #27ae60;
            --background-color: #f8f9fa;
            --card-background: #ffffff;
            --text-color: #212529;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
            --shadow-color: rgba(0, 0, 0, 0.1);
            --animation-speed: 0.3s;
        }

        .dark-theme {
            --primary-color: #34495e;
            --primary-hover: #2c3e50;
            --secondary-color: #218838;
            --secondary-hover: #1e7e34;
            --error-color: #c0392b;
            --error-hover: #a5281b;
            --warning-color: #e67e22;
            --warning-hover: #d35400;
            --info-color: #2980b9;
            --info-hover: #2472a4;
            --success-color: #27ae60;
            --success-hover: #219653;
            --background-color: #1a1a1a;
            --card-background: #2d2d2d;
            --text-color: #f8f9fa;
            --text-muted: #adb5bd;
            --border-color: #444;
            --shadow-color: rgba(0, 0, 0, 0.3);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color);
            color: var(--text-color);
            transition: background-color var(--animation-speed) ease, color var(--animation-speed) ease;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        [dir="rtl"] body {
            font-family: 'Tahoma', Arial, sans-serif;
        }

        /* Header Styles */
        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem;
            box-shadow: 0 2px 10px var(--shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        h1 {
            margin: 0;
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-grow: 1;
            justify-content: center;
        }

        /* Theme Toggle */
        .theme-toggle {
            position: absolute;
            right: 1rem;
        }

        [dir="rtl"] .theme-toggle {
            right: auto;
            left: 1rem;
        }

        .theme-toggle button {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color var(--animation-speed);
        }

        .theme-toggle button:hover {
            background-color: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
        }

        /* Language Toggle */
        .language-toggle {
            position: absolute;
            right: 4rem;
        }

        [dir="rtl"] .language-toggle {
            right: auto;
            left: 4rem;
        }

        .language-btn {
            background: none;
            border: none;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            transition: all var(--animation-speed);
        }

        .language-btn.active {
            background-color: rgba(255, 255, 255, 0.3);
        }

        .language-btn:hover:not(.active) {
            background-color: rgba(255, 255, 255, 0.2);
            transform: scale(1.05);
        }

        /* Back Button */
        .back-to-main {
            position: absolute;
            left: 1rem;
        }

        [dir="rtl"] .back-to-main {
            left: auto;
            right: 1rem;
        }

        .btn-back {
            color: white;
            text-decoration: none;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 4px;
            transition: all var(--animation-speed);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-back:hover {
            background-color: rgba(255, 255, 255, 0.3);
            transform: translateX(<?= $dir === 'rtl' ? '5px' : '-5px' ?>);
        }

        /* Main Content */
        main {
            flex: 1;
            padding: 2rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        /* Error Message */
        .error-message {
            background-color: var(--error-color);
            color: white;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .error-message i {
            font-size: 1.2rem;
        }

        /* Filter Buttons */
        .filter-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .filter-btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 30px;
            cursor: pointer;
            transition: all var(--animation-speed);
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            text-decoration: none;
            box-shadow: 0 2px 5px var(--shadow-color);
        }

        .filter-btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px var(--shadow-color);
        }

        .filter-btn.active {
            background-color: var(--secondary-color);
        }

        .filter-btn.active:hover {
            background-color: var(--secondary-hover);
        }

        /* Stats Summary */
        .stats-summary {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background-color: var(--card-background);
            border-radius: 12px;
            padding: 1.5rem;
            flex: 1;
            min-width: 180px;
            box-shadow: 0 4px 8px var(--shadow-color);
            text-align: center;
            transition: all var(--animation-speed);
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px var(--shadow-color);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background-color: var(--primary-color);
            transition: height var(--animation-speed);
        }

        .stat-card:hover::before {
            height: 8px;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
            margin: 0.5rem 0;
            transition: color var(--animation-speed);
        }

        .stat-card:hover .stat-value {
            color: var(--secondary-color);
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 0.9rem;
            transition: color var(--animation-speed);
        }

        /* Table Styles */
        .table-container {
            background-color: var(--card-background);
            border-radius: 12px;
            box-shadow: 0 4px 8px var(--shadow-color);
            overflow: hidden;
            margin-top: 2rem;
            transition: all var(--animation-speed);
        }

        .table-container:hover {
            box-shadow: 0 8px 15px var(--shadow-color);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th, .data-table td {
            padding: 1.25rem;
            text-align: <?= $dir === 'rtl' ? 'right' : 'left' ?>;
            border-bottom: 1px solid var(--border-color);
            transition: background-color var(--animation-speed);
        }

        .data-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            position: sticky;
            top: 0;
        }

        .data-table tr:last-child td {
            border-bottom: none;
        }

        .data-table tr {
            transition: all var(--animation-speed);
        }

        .data-table tr:hover {
            background-color: rgba(0, 0, 0, 0.05);
            transform: scale(1.01);
        }



        .data-table tr:hover td i {
            color: var(--secondary-color);
        }

        /* Section Header */
        .section-header {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
            color: var(--primary-color);
        }

        .section-header h2 {
            margin: 0;
            font-size: 1.75rem;
            position: relative;
            display: inline-block;
        }

        .section-header h2::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 50px;
            height: 3px;
            background-color: var(--primary-color);
            transition: width var(--animation-speed);
        }

        .section-header:hover h2::after {
            width: 100px;
        }

        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 3rem;
            font-size: 1.2rem;
            color: var(--text-muted);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
        }

        .no-data i {
            font-size: 3rem;
            color: var(--warning-color);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 2rem;
            background-color: var(--primary-color);
            color: white;
            margin-top: 3rem;
            transition: background-color var(--animation-speed);
        }

        /* Loading overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            color: white;
            font-size: 1.5rem;
            flex-direction: column;
            gap: 1rem;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 1rem;
                padding-top: 0.5rem;
                padding-bottom: 0.5rem;
            }
            
            h1 {
                font-size: 1.5rem;
                order: 2;
                margin: 0.5rem 0;
            }
            
            .back-to-main {
                position: static;
                order: 1;
                align-self: <?= $dir === 'rtl' ? 'flex-end' : 'flex-start' ?>;
            }
            
            .language-toggle, .theme-toggle {
                position: static;
                order: 3;
                align-self: <?= $dir === 'rtl' ? 'flex-start' : 'flex-end' ?>;
            }
            
            .data-table {
                display: block;
                overflow-x: auto;
            }
            
            .stat-card {
                min-width: calc(50% - 0.75rem);
            }

            .filter-buttons {
                flex-direction: column;
                align-items: center;
            }
        }

        @media (max-width: 480px) {
            .data-table th, .data-table td {
                padding: 1rem 0.75rem;
                font-size: 0.9rem;
            }
            
            .stat-card {
                min-width: 100%;
            }
            
            .filter-btn {
                width: 100%;
                justify-content: center;
            }
            
            .section-header h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Loading overlay -->
    <div class="loading-overlay" id="loading-overlay">
        <div class="spinner"></div>
        <div><?= $t['loading'] ?></div>
    </div>

    <!-- Header Section -->
    <header>
        <div class="header-content">
            <div class="back-to-main">
                <a href="../main-nav/index.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> <?= $t['back_to_main'] ?>
                </a>
            </div>
            <h1><i class="fas fa-university"></i> <?= $t['title'] ?></h1>
            <div class="language-toggle">
                <a href="?lang=en<?= isset($_GET['sort']) ? '&sort=' . $_GET['sort'] : '' ?>" class="language-btn <?= $lang === 'en' ? 'active' : '' ?>">EN</a>
                <a href="?lang=ar<?= isset($_GET['sort']) ? '&sort=' . $_GET['sort'] : '' ?>" class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>">AR</a>
            </div>
            <div class="theme-toggle">
                <button id="theme-toggle-btn">
                    <i class="fas fa-sun"></i>
                </button>
            </div>
        </div>
    </header>

    <main>
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong><?= $t['error'] ?>:</strong> <?= $error_message ?>
                    <div style="font-size: 0.9rem; margin-top: 0.5rem;">
                        <a href="javascript:window.location.reload()" style="color: white; text-decoration: underline;"><?= $t['try_again'] ?></a> <?= $t['contact_support'] ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Summary -->
        <div class="stats-summary">
            <div class="stat-card">
                <div class="stat-label"><?= $t['total_departments'] ?></div>
                <div class="stat-value"><?= $total_departments ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['highest_faculty'] ?></div>
                <div class="stat-value"><?= $highest_faculty ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['highest_courses'] ?></div>
                <div class="stat-value"><?= $highest_courses ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label"><?= $t['highest_students'] ?></div>
                <div class="stat-value"><?= $highest_students ?></div>
            </div>
        </div>

        <!-- Filter Buttons -->
        <div class="filter-buttons">
            <a href="?lang=<?= $lang ?>&sort=faculty_count" class="filter-btn <?= ($orderBy === 'faculty_count') ? 'active' : '' ?>">
                <i class="fas fa-chalkboard-teacher"></i> <?= $t['most_faculty'] ?>
            </a>
            <a href="?lang=<?= $lang ?>&sort=course_count" class="filter-btn <?= ($orderBy === 'course_count') ? 'active' : '' ?>">
                <i class="fas fa-book"></i> <?= $t['most_courses'] ?>
            </a>
            <a href="?lang=<?= $lang ?>&sort=student_count" class="filter-btn <?= ($orderBy === 'student_count') ? 'active' : '' ?>">
                <i class="fas fa-users"></i> <?= $t['most_students'] ?>
            </a>
        </div>

        <!-- Popular Departments Table -->
        <div class="section-header">
            <i class="fas fa-list-ol"></i>
            <h2><?= $t['title'] ?>: <?= 
                $orderBy === 'faculty_count' ? $t['most_faculty'] : 
                ($orderBy === 'course_count' ? $t['most_courses'] : $t['most_students']) 
            ?></h2>
        </div>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th><i class="fas fa-building"></i> <?= $t['department_name'] ?></th>
                        <th><i class="fas fa-chalkboard-teacher"></i> <?= $t['faculty'] ?></th>
                        <th><i class="fas fa-book"></i> <?= $t['courses'] ?></th>
                        <th><i class="fas fa-users"></i> <?= $t['students'] ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($popular_departments)): ?>
                        <?php foreach ($popular_departments as $department): ?>
                            <tr>
                                <td><i class="fas fa-building"></i> <?= $department['department_name'] ?></td>
                                <td><?= $department['faculty_count'] ?></td>
                                <td><?= $department['course_count'] ?></td>
                                <td><?= $department['student_count'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="no-data">
                                <i class="fas fa-exclamation-circle"></i> <?= $t['no_data'] ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <p>&copy; <?= date('Y') ?> <?= $t['footer'] ?></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Hide loading overlay with fade out effect
            const loadingOverlay = document.getElementById('loading-overlay');
            if (loadingOverlay) {
                setTimeout(() => {
                    loadingOverlay.style.opacity = '0';
                    setTimeout(() => {
                        loadingOverlay.style.display = 'none';
                    }, 500);
                }, 500);
            }

            // Theme toggle functionality
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;
            
            // Load saved theme from localStorage
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }

            // Toggle theme on button click with animation
            themeToggleBtn.addEventListener('click', () => {
                const isDark = !body.classList.contains('dark-theme');
                
                // Add transition class for smooth theme change
                body.classList.add('theme-transition');
                document.documentElement.style.setProperty('--animation-speed', '0.5s');
                
                setTimeout(() => {
                    body.classList.toggle('dark-theme');
                    themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                    localStorage.setItem('theme', isDark ? 'dark' : 'light');
                    
                    // Remove transition class after animation
                    setTimeout(() => {
                        body.classList.remove('theme-transition');
                        document.documentElement.style.setProperty('--animation-speed', '0.3s');
                    }, 500);
                }, 10);
            });

            // Add hover effects to all interactive elements
            const interactiveElements = document.querySelectorAll('a, button, .stat-card, .filter-btn, .data-table tr');
            interactiveElements.forEach(el => {
                el.style.transition = 'all var(--animation-speed) ease';
            });
            
            // Smooth scroll to top when changing language or theme
            const smoothScrollToTop = () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            };
            
            document.querySelectorAll('.language-btn, #theme-toggle-btn').forEach(btn => {
                btn.addEventListener('click', smoothScrollToTop);
            });
        });
    </script>
</body>
</html>