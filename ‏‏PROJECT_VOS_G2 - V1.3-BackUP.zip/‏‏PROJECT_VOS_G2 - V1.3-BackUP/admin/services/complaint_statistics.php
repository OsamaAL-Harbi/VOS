<?php
require_once '../db.php'; // Database connection

// Language handling
$lang = 'en'; // Default language
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ar'])) {
    $lang = $_GET['lang'];
    setcookie('lang', $lang, time() + (86400 * 30), "/"); // Store for 30 days
} elseif (isset($_COOKIE['lang'])) {
    $lang = $_COOKIE['lang'];
}
// Handle language switch
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'ar') ? 'ar' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?')); // Redirect to clean URL
    exit();
}

// Translations
$translations = [
    'en' => [
        'title' => 'Complaint Statistics',
        'back_to_main' => 'Back to Main Navigation',
        'filters' => 'Filters',
        'status' => 'Status',
        'course' => 'Course',
        'department' => 'Department',
        'all' => 'All',
        'apply' => 'Apply',
        'reset' => 'Reset',
        'complaint_count' => 'Complaint Count',
        'course_name' => 'Course Name',
        'no_data' => 'No data available',
        'complaint_status_chart' => 'Complaint Status Chart',
        'footer' => 'Admin Panel. All rights reserved.',
        'number_of_complaints' => 'Number of Complaints',
        'loading' => 'Loading...'
    ],
    'ar' => [
        'title' => 'إحصائيات الشكاوى',
        'back_to_main' => 'العودة إلى القائمة الرئيسية',
        'filters' => 'الفلاتر',
        'status' => 'الحالة',
        'course' => 'المادة',
        'department' => 'القسم',
        'all' => 'الكل',
        'apply' => 'تطبيق',
        'reset' => 'إعادة تعيين',
        'complaint_count' => 'عدد الشكاوى',
        'course_name' => 'اسم المادة',
        'no_data' => 'لا توجد بيانات متاحة',
        'complaint_status_chart' => 'رسم بياني لحالة الشكاوى',
        'footer' => 'لوحة التحكم. جميع الحقوق محفوظة.',
        'number_of_complaints' => 'عدد الشكاوى',
        'loading' => 'جاري التحميل...'
    ]
];

$t = $translations[$lang];
$dir = $lang === 'ar' ? 'rtl' : 'ltr';

try {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch Complaints Report
    $complaints_query = "
        SELECT  
            c.complaint_id AS complaint_id,
            c.complaint_description AS complaint_description,
            c.status,
            c.created_at,
            c.complainant_id AS student_id,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name,
            c.course_name,
            c.complaint_department AS department_name
        FROM complaints c
        LEFT JOIN students s ON c.complainant_id = s.student_id
        ORDER BY c.created_at DESC;
    ";
    $complaints_stmt = $pdo->query($complaints_query);
    $complaints = $complaints_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Complaint Counts Grouped by Status
    $counts_query = "
        SELECT status, COUNT(*) AS count
        FROM complaints
        GROUP BY status
    ";
    $counts_stmt = $pdo->query($counts_query);
    $complaint_counts = $counts_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Most Complained About Courses
    $complained_courses_query = "
        SELECT c.course_name, COUNT(*) AS complaint_count
        FROM complaints c
        GROUP BY c.course_name
        ORDER BY complaint_count DESC
        LIMIT 5
    ";
    $complained_courses_stmt = $pdo->query($complained_courses_query);
    $complained_courses = $complained_courses_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    die(json_encode(['error' => 'An error occurred while processing your request.']));
}
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $dir ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        .dark-theme {
            --primary-color: #34495e;
            --secondary-color: #218838;
            --dark-color: #1a1a1a;
            --light-color: #2d2d2d;
            --danger-color: #c0392b;
            --warning-color: #e67e22;
            --background-color: #121212;
            --text-color: #f8f9fa;
            --border-color: #444;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color, #f5f7fa);
            color: var(--text-color, #333);
            direction: <?= $dir ?>;
            transition: var(--transition);
        }

        body[dir="rtl"] {
            font-family: 'Tahoma', Arial, sans-serif;
        }

        .admin-header {
            background-color: var(--dark-color);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--box-shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
        }

        .admin-header h1 {
            margin: 0;
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: var(--border-radius);
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: #2980b9;
        }

        .btn-secondary {
            background-color: var(--light-color);
            color: var(--dark-color);
        }

        .btn-secondary:hover {
            background-color: #bdc3c7;
        }

        .btn-back {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            text-decoration: none;
        }

        .btn-back:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .header-controls {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-icon {
            background: none;
            border: none;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .btn-icon:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .language-switch {
            display: flex;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: var(--border-radius);
            overflow: hidden;
        }

        .language-btn {
            padding: 0.5rem 1rem;
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .language-btn.active {
            background-color: var(--primary-color);
        }

        .language-btn:hover:not(.active) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .main-content {
            padding: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }

        .filters-section, 
        .complaint-count-section,
        .chart-section {
            background-color: var(--light-color);
            padding: 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            margin-bottom: 2rem;
            color: var(--text-color);
        }

        .filters-section h2,
        .complaint-count-section h2,
        .chart-section h2 {
            margin-top: 0;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1rem;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .filter-group label {
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-select {
            padding: 0.5rem;
            border: 1px solid var(--border-color, #ddd);
            border-radius: var(--border-radius);
            font-size: 1rem;
            background-color: var(--background-color, white);
            color: var(--text-color, #333);
        }

        .filter-buttons {
            display: flex;
            gap: 1rem;
            align-items: flex-end;
        }

        .table-container {
            overflow-x: auto;
        }

        .complaint-table {
            width: 100%;
            border-collapse: collapse;
        }

        .complaint-table th, 
        .complaint-table td {
            padding: 1rem;
            text-align: <?= $dir === 'rtl' ? 'right' : 'left' ?>;
            border-bottom: 1px solid var(--border-color, #ddd);
        }

        .complaint-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
        }

        .complaint-table tr:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }

        .no-data {
            text-align: center;
            color: var(--danger-color);
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .chart-container {
            position: relative;
            height: 400px;
            width: 100%;
        }

        .loading-spinner {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-color);
        }

        .admin-footer {
            text-align: center;
            padding: 1rem;
            background-color: var(--dark-color);
            color: white;
            margin-top: 2rem;
        }

        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .filter-buttons {
                grid-column: 1;
            }
            
            .admin-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .header-controls {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="admin-header">
        <div class="header-content">
            <!-- Back Button -->
            <a href="../main-nav/index.php" class="btn btn-back">
                <i class="fas fa-arrow-left"></i> <?= $t['back_to_main'] ?>
            </a>
            <!-- Title -->
            <h1><i class="fas fa-chart-bar"></i> <?= $t['title'] ?></h1>
            <!-- Right Side Controls -->
            <div class="header-controls">
                <!-- Theme Toggle -->
                <button id="theme-toggle-btn" class="btn-icon">
                    <i class="fas fa-moon"></i>
                </button>
                <!-- Language Switch -->
                <div class="language-switch">
                    <a href="?lang=en" class="language-btn <?= $lang === 'en' ? 'active' : '' ?>">EN</a>
                    <a href="?lang=ar" class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>">AR</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Filters Section -->
        <section id="filters" class="filters-section">
            <h2><i class="fas fa-filter"></i> <?= $t['filters'] ?></h2>
            <form method="GET" action="" class="filter-form">
                <input type="hidden" name="lang" value="<?= $lang ?>">
                <?php
                $filters = [
                    'status' => ['label' => $t['status'], 'icon' => 'fa-info-circle'],
                    'course' => ['label' => $t['course'], 'icon' => 'fa-book'],
                    'department' => ['label' => $t['department'], 'icon' => 'fa-building']
                ];
                foreach ($filters as $key => $filter) {
                    echo '<div class="filter-group">';
                    echo '<label for="' . $key . '-filter"><i class="fas ' . $filter['icon'] . '"></i> ' . $filter['label'] . ':</label>';
                    echo '<select id="' . $key . '-filter" name="' . $key . '" class="filter-select">';
                    echo '<option value="">' . $t['all'] . '</option>';
                    foreach (array_unique(array_column($complaints, $key)) as $value) {
                        $selected = isset($_GET[$key]) && $_GET[$key] === $value ? 'selected' : '';
                        echo '<option value="' . htmlspecialchars($value) . '" ' . $selected . '>' . htmlspecialchars($value) . '</option>';
                    }
                    echo '</select></div>';
                }
                ?>
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> <?= $t['apply'] ?></button>
                    <button type="reset" class="btn btn-secondary" onclick="window.location.href='complaint_statistics.php?lang=<?= $lang ?>';">
                        <i class="fas fa-undo"></i> <?= $t['reset'] ?>
                    </button>
                </div>
            </form>
        </section>

        <!-- Complaint Count Section -->
        <section id="complaint-count" class="complaint-count-section">
            <h2><i class="fas fa-table"></i> <?= $t['complaint_count'] ?></h2>
            <div class="table-container">
                <table class="complaint-table">
                    <thead>
                        <tr>
                            <th><i class="fas fa-book"></i> <?= $t['course_name'] ?></th>
                            <th><i class="fas fa-exclamation-circle"></i> <?= $t['complaint_count'] ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($complained_courses)): ?>
                            <?php foreach ($complained_courses as $course): ?>
                                <tr>
                                    <td><?= htmlspecialchars($course['course_name']) ?></td>
                                    <td><?= htmlspecialchars($course['complaint_count']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="2" class="no-data"><i class="fas fa-exclamation-triangle"></i> <?= $t['no_data'] ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
        
        <!-- Complaint Statistics Chart Section -->
        <section id="complaint-statistics" class="chart-section">
            <h2><i class="fas fa-chart-pie"></i> <?= $t['complaint_status_chart'] ?></h2>
            <div class="chart-toggle-buttons">
                <button id="show-bar-chart" class="btn btn-primary"><i class="fas fa-chart-bar"></i> Bar Chart</button>
                <button id="show-pie-chart" class="btn btn-secondary"><i class="fas fa-chart-pie"></i> Pie Chart</button>
            </div>
            <div class="chart-container">
                <canvas id="complaintChart" role="img" aria-label="<?= $t['complaint_status_chart'] ?>"></canvas>
                <div id="chart-loading" class="loading-spinner"><i class="fas fa-spinner fa-spin"></i> <?= $t['loading'] ?></div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="admin-footer">
        <p>&copy; <?= date('Y') ?> <?= $t['footer'] ?></p>
    </footer>

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;

            // Theme Toggle Functionality
            const currentTheme = localStorage.getItem('theme') || 'light';
            if (currentTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
            }
            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
                if (complaintChart) updateChartColors();
            });

            // Chart Variables
            let complaintChart;
            const complaintData = <?= json_encode($complaint_counts) ?>;

            // Initialize Chart
            if (complaintData.length > 0) {
                createBarChart();
                document.getElementById('chart-loading').style.display = 'none';

                document.getElementById('show-bar-chart').addEventListener('click', function () {
                    if (complaintChart.config.type !== 'bar') {
                        complaintChart.destroy();
                        createBarChart();
                        toggleChartButtons(this, document.getElementById('show-pie-chart'));
                    }
                });

                document.getElementById('show-pie-chart').addEventListener('click', function () {
                    if (complaintChart.config.type !== 'pie') {
                        complaintChart.destroy();
                        createPieChart();
                        toggleChartButtons(this, document.getElementById('show-bar-chart'));
                    }
                });
            } else {
                document.getElementById('chart-loading').innerHTML = '<i class="fas fa-exclamation-triangle"></i> <?= $t['no_data'] ?>';
            }

            // Chart Creation Functions
            function createBarChart() {
                const labels = complaintData.map(item => item.status);
                const counts = complaintData.map(item => item.count);
                const ctx = document.getElementById('complaintChart').getContext('2d');
                complaintChart = new Chart(ctx, {
                    type: 'bar',
                    data: { labels, datasets: [{ label: '<?= $t['number_of_complaints'] ?>', data: counts, backgroundColor: getBackgroundColors(), borderColor: getBorderColors(), borderWidth: 2, borderRadius: 5 }] },
                    options: getChartOptions('bar')
                });
            }

            function createPieChart() {
                const labels = complaintData.map(item => item.status);
                const counts = complaintData.map(item => item.count);
                const ctx = document.getElementById('complaintChart').getContext('2d');
                complaintChart = new Chart(ctx, {
                    type: 'pie',
                    data: { labels, datasets: [{ label: '<?= $t['number_of_complaints'] ?>', data: counts, backgroundColor: getBackgroundColors(), borderColor: getBorderColors(), borderWidth: 2 }] },
                    options: getChartOptions('pie')
                });
            }

            // Helper Functions
            function getBackgroundColors() {
                return ['rgba(75, 192, 192, 0.8)', 'rgba(255, 99, 132, 0.8)', 'rgba(54, 162, 235, 0.8)', 'rgba(255, 206, 86, 0.8)', 'rgba(153, 102, 255, 0.8)'];
            }

            function getBorderColors() {
                return ['rgba(75, 192, 192, 1)', 'rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(153, 102, 255, 1)'];
            }

            function getChartOptions(type) {
                const isDark = body.classList.contains('dark-theme');
                const textColor = isDark ? '#f8f9fa' : '#333';
                const gridColor = isDark ? '#444' : '#ddd';
                const commonOptions = {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: true, position: 'top', labels: { color: textColor } },
                        tooltip: { enabled: true, backgroundColor: isDark ? '#1a1a1a' : '#2c3e50', titleColor: textColor, bodyColor: textColor }
                    }
                };
                if (type === 'bar') {
                    commonOptions.scales = {
                        y: { beginAtZero: true, ticks: { color: textColor }, grid: { color: gridColor } },
                        x: { grid: { display: false }, ticks: { color: textColor } }
                    };
                }
                return commonOptions;
            }

            function updateChartColors() {
                const isDark = body.classList.contains('dark-theme');
                const textColor = isDark ? '#f8f9fa' : '#333';
                if (complaintChart) {
                    complaintChart.options.plugins.legend.labels.color = textColor;
                    if (complaintChart.config.type === 'bar') {
                        complaintChart.options.scales.y.ticks.color = textColor;
                        complaintChart.options.scales.x.ticks.color = textColor;
                    }
                    complaintChart.update();
                }
            }

            function toggleChartButtons(activeBtn, inactiveBtn) {
                activeBtn.classList.add('btn-primary');
                activeBtn.classList.remove('btn-secondary');
                inactiveBtn.classList.add('btn-secondary');
                inactiveBtn.classList.remove('btn-primary');
            }
        });
    </script>
</body>
</html>