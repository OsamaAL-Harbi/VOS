<?php
require_once '../db.php';

// Check if complaint ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: complaints_report.php");
    exit();
}

$complaint_id = (int)$_GET['id'];
$complaint = [];
$actions = [];
$error_message = '';

try {
    // Get complaint details
    $complaint_query = "
        SELECT  
            c.*,
            CONCAT(s.first_name, ' ', s.last_name) AS student_name
        FROM 
            complaints c
        LEFT JOIN 
            students s ON c.complainant_id = s.student_id
        WHERE 
            c.complaint_id = ?
    ";
    
    $complaint_stmt = $pdo->prepare($complaint_query);
    $complaint_stmt->execute([$complaint_id]);
    $complaint = $complaint_stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$complaint) {
        $error_message = "Complaint not found";
    } else {
        // Get actions for this complaint
        $actions_query = "
            SELECT 
                ca.*,
                a.name AS admin_name,
                h.name AS hod_name,
                m.name AS mrc_name,
                au.name AS aau_name
            FROM 
                complaint_actions ca
            LEFT JOIN 
                admins a ON ca.action_by_AA = a.admin_id
            LEFT JOIN
                hods h ON ca.action_by_HOD = h.hod_id
            LEFT JOIN
                mrcs m ON ca.action_by_MRC = m.mrc_id
            LEFT JOIN
                aau au ON ca.action_by_AAU = au.aau_id
            WHERE 
                ca.complaint_id = ?
            ORDER BY 
                ca.action_date DESC
        ";
        
        $actions_stmt = $pdo->prepare($actions_query);
        $actions_stmt->execute([$complaint_id]);
        $actions = $actions_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log("Database error in complaint_details.php: " . $e->getMessage());
    $error_message = "An error occurred while fetching complaint details.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Details</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="back-to-main">
                <a href="complaints_report.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Back to Complaints
                </a>
            </div>
            <h1><i class="fas fa-file-alt"></i> Complaint Details</h1>
        </div>
    </header>

    <main class="complaint-details-container">
        <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong>Error:</strong> <?= htmlspecialchars($error_message) ?>
                </div>
            </div>
        <?php elseif (empty($complaint)): ?>
            <div class="no-data">
                <i class="fas fa-inbox"></i>
                <div>Complaint not found</div>
            </div>
        <?php else: ?>
            <div class="complaint-details">
                <div class="detail-section">
                    <h2><i class="fas fa-info-circle"></i> Basic Information</h2>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label><i class="fas fa-id-card"></i> Complaint ID:</label>
                            <span><?= htmlspecialchars($complaint['complaint_id']) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-calendar-alt"></i> Created:</label>
                            <span><?= date('M j, Y g:i A', strtotime($complaint['created_at'])) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-calendar-check"></i> Updated:</label>
                            <span><?= date('M j, Y g:i A', strtotime($complaint['updated_at'])) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-user-graduate"></i> Student:</label>
                            <span><?= htmlspecialchars($complaint['student_name']) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-building"></i> Department:</label>
                            <span><?= htmlspecialchars($complaint['complaint_department']) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-tag"></i> Type:</label>
                            <span><?= htmlspecialchars($complaint['complaint_type']) ?></span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-exclamation-circle"></i> Priority:</label>
                            <span class="priority-badge <?= htmlspecialchars($complaint['priority']) ?>">
                                <?= ucfirst(htmlspecialchars($complaint['priority'])) ?>
                            </span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-bolt"></i> Severity:</label>
                            <span class="severity-badge <?= htmlspecialchars($complaint['severity']) ?>">
                                <?= ucfirst(htmlspecialchars($complaint['severity'])) ?>
                            </span>
                        </div>
                        <div class="detail-item">
                            <label><i class="fas fa-lock"></i> Status:</label>
                            <span class="status-badge <?= htmlspecialchars($complaint['status']) ?>">
                                <?= htmlspecialchars(str_replace('_', ' ', $complaint['status'])) ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h2><i class="fas fa-align-left"></i> Full Description</h2>
                    <div class="description-content">
                        <?= nl2br(htmlspecialchars($complaint['complaint_description'])) ?>
                    </div>
                </div>
                
                <?php if (!empty($complaint['file_path'])): ?>
                <div class="detail-section">
                    <h2><i class="fas fa-paperclip"></i> Attachments</h2>
                    <div class="attachments">
                        <a href="<?= htmlspecialchars($complaint['file_path']) ?>" target="_blank" class="attachment-link">
                            <i class="fas fa-file"></i> View Attachment
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="actions-section">
                <h2><i class="fas fa-tasks"></i> Actions Taken</h2>
                
                <?php if (!empty($actions)): ?>
                    <div class="actions-list">
                        <?php foreach ($actions as $action): ?>
                            <div class="action-item">
                                <div class="action-header">
                                    <h3>
                                        <?= ucfirst(htmlspecialchars($action['action_type'])) ?> 
                                        <span class="action-id">#<?= htmlspecialchars($action['action_id']) ?></span>
                                    </h3>
                                    <span class="action-date">
                                        <?= date('M j, Y g:i A', strtotime($action['action_date'])) ?>
                                    </span>
                                </div>
                                <div class="action-body">
                                    <p><strong>Action By:</strong> 
                                        <?= htmlspecialchars($action['admin_name'] ?? $action['hod_name'] ?? $action['mrc_name'] ?? $action['aau_name'] ?? 'System') ?>
                                    </p>
                                    
                                    <?php if (!empty($action['action_description'])): ?>
                                    <p><strong>Description:</strong> 
                                        <?= nl2br(htmlspecialchars($action['action_description'])) ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <p><strong>Resulting Status:</strong> 
                                        <span class="status-badge <?= htmlspecialchars($action['status_after_action']) ?>">
                                            <?= htmlspecialchars(str_replace('_', ' ', $action['status_after_action'])) ?>
                                        </span>
                                    </p>
                                    
                                    <?php if (!empty($action['AA_comment'])): ?>
                                    <p><strong>Admin Comment:</strong> 
                                        <?= nl2br(htmlspecialchars($action['AA_comment'])) ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($action['HOD_comment'])): ?>
                                    <p><strong>HOD Comment:</strong> 
                                        <?= nl2br(htmlspecialchars($action['HOD_comment'])) ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($action['MRC_comment'])): ?>
                                    <p><strong>MRC Comment:</strong> 
                                        <?= nl2br(htmlspecialchars($action['MRC_comment'])) ?>
                                    </p>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($action['AAU_comment'])): ?>
                                    <p><strong>AAU Comment:</strong> 
                                        <?= nl2br(htmlspecialchars($action['AAU_comment'])) ?>
                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="no-actions">
                        <i class="fas fa-info-circle"></i> No actions recorded for this complaint.
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <p>&copy; <?= date('Y') ?> University Complaint System. All rights reserved.</p>
    </footer>
</body>
</html>