<?php
session_start();

// Set default language if not already set
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en'; // Default to English
}

// Handle language switch
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = ($_GET['lang'] === 'ar') ? 'ar' : 'en';
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?')); // Redirect to clean URL
    exit();
}

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../login/index.php");
    exit;
}

// Language translations
$translations = [
    'en' => [
        'title' => 'Admin Services',
        'logout' => 'Logout',
        'services' => [
            'faculty_management' => 'Faculty Management',
            'complaints_report' => 'Complaints Report',
            'complaint_statistics' => 'Complaint Statistics',
            'popular_courses' => 'Popular Courses',
            'popular_departments' => 'Popular Departments',
            'export' => 'Export Excel'
        ],
        'descriptions' => [
            'faculty_management' => 'Efficiently manage faculty members with our dedicated tools.',
            'complaints_report' => 'View and manage complaints reports effortlessly.',
            'complaint_statistics' => 'Analyze complaint trends and statistics efficiently.',
            'popular_courses' => 'Explore the most popular courses among students.',
            'popular_departments' => 'Discover which departments are leading in popularity.',
            'export' => 'Export data to an Excel file for further analysis.'
        ],
        'buttons' => [
            'learn_more' => 'Learn More',
            'export' => 'Export',
            'click_here' => 'Click Here'
        ],
        'breadcrumb' => [
            'home' => 'Home',
            'services' => 'Services'
        ],
        'footer' => '&copy; 2025 Admin Panel. All rights reserved.'
    ],
    'ar' => [
        'title' => 'خدمات الإدارة',
        'logout' => 'تسجيل الخروج',
        'services' => [
            'faculty_management' => 'إدارة أعضاء هيئة التدريس',
            'complaints_report' => 'تقرير الشكاوى',
            'complaint_statistics' => 'إحصائيات الشكاوى',
            'popular_courses' => 'الكورسات الأكثر شيوعاً',
            'popular_departments' => 'الأقسام الأكثر شيوعاً',
            'export' => 'تصدير إكسل'
        ],
        'descriptions' => [
            'faculty_management' => 'إدارة أعضاء هيئة التدريس بكفاءة باستخدام أدواتنا المخصصة.',
            'complaints_report' => 'عرض وإدارة تقارير الشكاوى بسهولة.',
            'complaint_statistics' => 'تحليل اتجاهات وإحصائيات الشكاوى بكفاءة.',
            'popular_courses' => 'استكشف الكورسات الأكثر شيوعاً بين الطلاب.',
            'popular_departments' => 'اكتشف الأقسام الأكثر شيوعاً.',
            'export' => 'تصدير البيانات إلى ملف إكسل لمزيد من التحليل.'
        ],
        'buttons' => [
            'learn_more' => 'المزيد',
            'export' => 'تصدير',
            'click_here' => 'انقر هنا'
        ],
        'breadcrumb' => [
            'home' => 'الرئيسية',
            'services' => 'الخدمات'
        ],
        'footer' => '&copy; 2025 لوحة التحكم. جميع الحقوق محفوظة.'
    ]
];

$lang = $_SESSION['lang'];
$t = $translations[$lang];
?>

<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $lang === 'ar' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $t['title'] ?> | Voice of Student</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a76a8;
            --primary-hover: #3a5f8a;
            --background-color: #f8f9fa;
            --card-background: #ffffff;
            --text-color: #212529;
            --text-muted: #6c757d;
            --border-color: #dee2e6;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }

        .dark-theme {
            --primary-color: #34495e;
            --primary-hover: #2c3e50;
            --background-color: #1a1a1a;
            --card-background: #2d2d2d;
            --text-color: #f8f9fa;
            --text-muted: #adb5bd;
            --border-color: #444;
            --shadow-color: rgba(0, 0, 0, 0.3);
        }

        [dir="rtl"] {
            text-align: right;
        }
        
        [dir="rtl"] .card {
            text-align: right;
        }
        
        [dir="rtl"] .service-cards {
            direction: rtl;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--background-color);
            color: var(--text-color);
            transition: background-color 0.3s ease, color 0.3s ease;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navigation Bar */
        .navbar {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem;
            box-shadow: 0 2px 10px var(--shadow-color);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar h1 {
            margin: 0;
            font-size: 1.5rem;
        }

        .nav-links {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
            align-items: center;
            gap: 1.5rem;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: opacity 0.3s;
        }

        .nav-links a:hover {
            opacity: 0.8;
        }

        /* Theme Toggle */
        .theme-toggle button {
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 50%;
            transition: background-color 0.3s;
        }

        .theme-toggle button:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        /* Language Switch */
        .language-switch {
            display: flex;
            gap: 0.5rem;
        }

        .language-btn {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            font-weight: bold;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .language-btn:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .language-btn.active {
            background-color: rgba(255, 255, 255, 0.3);
        }

        /* Breadcrumb */
        .breadcrumb {
            padding: 1rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }
        
        .breadcrumb a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }

        /* Main Content */
        main {
            flex: 1;
            padding: 2rem 1rem;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }

        .service-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-top: 1.5rem;
        }

        .card {
            background-color: var(--card-background);
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 4px 8px var(--shadow-color);
            transition: transform 0.3s, box-shadow 0.3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px var(--shadow-color);
        }

        .card i {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .card h2 {
            margin: 0.5rem 0;
            color: var(--primary-color);
        }

        .card p {
            color: var(--text-muted);
            margin-bottom: 1.5rem;
            flex-grow: 1;
        }

        .btn {
            background-color: var(--primary-color);
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s;
            position: relative;
        }

        .btn:hover {
            background-color: var(--primary-hover);
        }
        
        .btn.loading {
            pointer-events: none;
            padding-right: 2.5rem;
        }
        
        .btn.loading::after {
            content: '';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255,255,255,0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: translateY(-50%) rotate(360deg); }
        }

        /* Footer */
        footer {
            text-align: center;
            padding: 1.5rem;
            background-color: var(--primary-color);
            color: white;
            margin-top: 2rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .navbar-container {
                flex-direction: column;
                gap: 1rem;
            }
            
            .nav-links {
                gap: 1rem;
            }
            
            .service-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-container">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <img src="../logo.png" alt="Logo" width="40" height="40">
                <h1>Voice of Student</h1>
            </div>
            <ul class="nav-links">
                <li>
                    <div class="language-switch">
                        <button class="language-btn <?= $lang === 'en' ? 'active' : '' ?>" data-lang="en">EN</button>
                        <button class="language-btn <?= $lang === 'ar' ? 'active' : '' ?>" data-lang="ar">AR</button>
                    </div>
                </li>
                <li>
                    <div class="theme-toggle">
                        <button id="theme-toggle-btn" aria-label="Toggle theme">
                            <i class="fas fa-sun"></i>
                        </button>
                    </div>
                </li>
                <li>
                    <a href="/PROJECT_VOS_G2/logout/logout.php" class="logout-link">
                        <i class="fas fa-sign-out-alt"></i> <?= $t['logout'] ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <main>
        <nav class="breadcrumb" aria-label="breadcrumb">
            <a href="/"><?= $t['breadcrumb']['home'] ?></a> &gt;
            <span><?= $t['breadcrumb']['services'] ?></span>
        </nav>
        
        <div class="service-cards">
            <!-- Service Cards -->
            <section class="card" data-service="faculty_management">
                <i class="fas fa-user-tie fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['faculty_management'] ?></h2>
                <p><?= $t['descriptions']['faculty_management'] ?></p>
                <a href="../../admin/services/faculty_management.php" class="btn" aria-label="<?= $t['services']['faculty_management'] ?>">
                    <?= $t['buttons']['click_here'] ?>
                </a>
            </section>
            
            <section class="card" data-service="complaints_report">
                <i class="fas fa-file-alt fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['complaints_report'] ?></h2>
                <p><?= $t['descriptions']['complaints_report'] ?></p>
                <a href="../../admin/services/complaints_report.php" class="btn" aria-label="<?= $t['services']['complaints_report'] ?>">
                    <?= $t['buttons']['click_here'] ?>
                </a>
            </section>
            
            <section class="card" data-service="complaint_statistics">
                <i class="fas fa-chart-bar fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['complaint_statistics'] ?></h2>
                <p><?= $t['descriptions']['complaint_statistics'] ?></p>
                <a href="../../admin/services/complaint_statistics.php" class="btn" aria-label="<?= $t['services']['complaint_statistics'] ?>">
                    <?= $t['buttons']['click_here'] ?>
                </a>
            </section>
            
            <section class="card" data-service="popular_courses">
                <i class="fas fa-book fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['popular_courses'] ?></h2>
                <p><?= $t['descriptions']['popular_courses'] ?></p>
                <a href="../../admin/services/popular_courses.php" class="btn" aria-label="<?= $t['services']['popular_courses'] ?>">
                    <?= $t['buttons']['click_here'] ?>
                </a>
            </section>
            
            <section class="card" data-service="popular_departments">
                <i class="fas fa-building fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['popular_departments'] ?></h2>
                <p><?= $t['descriptions']['popular_departments'] ?></p>
                <a href="../../admin/services/popular_departments.php" class="btn" aria-label="<?= $t['services']['popular_departments'] ?>">
                    <?= $t['buttons']['click_here'] ?>
                </a>
            </section>
            
            <section class="card" data-service="export">
                <i class="fas fa-file-excel fa-3x" aria-hidden="true"></i>
                <h2><?= $t['services']['export'] ?></h2>
                <p><?= $t['descriptions']['export'] ?></p>
                <a href="../../admin/services/export.php" class="btn" aria-label="<?= $t['services']['export'] ?>">
                    <?= $t['buttons']['export'] ?>
                </a>
            </section>
        </div>
    </main>

    <footer>
        <p><?= $t['footer'] ?></p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
            const body = document.body;
            const langButtons = document.querySelectorAll('.language-btn');

            // Theme Toggle
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-theme');
                themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
            }

            themeToggleBtn.addEventListener('click', () => {
                body.classList.toggle('dark-theme');
                const isDark = body.classList.contains('dark-theme');
                themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
                localStorage.setItem('theme', isDark ? 'dark' : 'light');
            });

            // Language switch handler
            langButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const lang = btn.dataset.lang;
                    window.location.href = `?lang=${lang}`;
                });
            });
            
            // Button loading states
            document.querySelectorAll('.btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    this.classList.add('loading');
                });
            });
        });
    </script>
</body>
</html>