// Theme Toggle Script
document.addEventListener('DOMContentLoaded', () => {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const body = document.body;

    // Load saved theme from localStorage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
    } else {
        themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
    }

    // Toggle theme on button click
    themeToggleBtn.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        const isDark = body.classList.contains('dark-theme');
        themeToggleBtn.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
});

// Card Click Script
document.addEventListener('DOMContentLoaded', () => {
    const serviceCards = document.querySelectorAll('.card');

    // Check if any cards exist
    if (!serviceCards.length) return;

    serviceCards.forEach(card => {
        card.addEventListener('click', (event) => {
            // Find the closest button element
            const button = event.target.closest('.btn');
            if (!button) return; // Exit if the click wasn't on a button

            // Get the service type from the data-service attribute
            const serviceType = card.dataset.service;
            if (serviceType) {
                console.log(`Navigating to: ${serviceType}`);

                // Optionally override the default link behavior
                event.preventDefault(); // Prevent the default <a> tag navigation

                // Navigate programmatically
                window.location.href = `../services/${serviceType}.php`;
            }
        });
    });
});