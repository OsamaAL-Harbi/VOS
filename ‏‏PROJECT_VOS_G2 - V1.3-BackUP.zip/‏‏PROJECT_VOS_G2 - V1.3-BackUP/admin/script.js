document.getElementById('roleForm').addEventListener('submit', function(event) {
    const newRole = document.getElementById('new_role').value.trim();
    if (newRole === '') {
        alert('Please enter a valid role.');
        event.preventDefault();
    }
});