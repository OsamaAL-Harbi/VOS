<?php
session_start();
require_once 'db.php';

// Check if the request method is POST and the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_role'])) {
    // Retrieve and validate POST data
    $faculty_id = filter_var($_POST['faculty_id'], FILTER_VALIDATE_INT);
    $new_role = filter_var($_POST['new_role'], FILTER_SANITIZE_STRING);

    if ($faculty_id === false || empty($new_role)) {
        die("Invalid input.");
    }

    try {
        // Prepare the SQL query to update the faculty role
        $query = "
            UPDATE faculty_members
            SET role = :role
            WHERE faculty_id = :faculty_id;
        ";
        $stmt = $pdo->prepare($query);

        // Execute the query with sanitized parameters
        $stmt->execute([
            ':role' => $new_role,
            ':faculty_id' => $faculty_id
        ]);

        // Check if the update was successful
        if ($stmt->rowCount() > 0) {
            // Redirect back to the admin page after a successful update
            header('Location: index.php');
            exit;
        } else {
            echo "No rows were updated. Faculty ID may not exist.";
        }
    } catch (PDOException $e) {
        // Log the error and display a user-friendly message
        error_log("Database error: " . $e->getMessage());
        die("An error occurred while updating the role.");
    }
}
?>