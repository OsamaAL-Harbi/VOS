<?php
session_start();

// Database configuration
$servername = "localhost";
$username = "root";
$password = "Root";
$dbname = "faculty";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error, ENT_QUOTES));
}

// Ensure student_id is set in the session
$student_id = isset($_SESSION['student_id']) ? $_SESSION['student_id'] : null;
if (!$student_id) {
    die("Student ID not found in session. Please log in again.");
}

// Query to get courses related to the student
$query = "SELECT courses.course_name, courses.department_id 
          FROM enrollments 
          JOIN courses ON enrollments.course_id = courses.course_id 
          WHERE enrollments.student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$courses_result = $stmt->get_result();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Retrieve and sanitize form inputs
        $complaint_type = trim($_POST['complaint_type']);
        $course_name = trim($_POST['course_name']);
        $description = trim($_POST['description']);
        $file_path = null;

        // Validate required fields
        if (empty($complaint_type) || empty($course_name) || empty($description)) {
            throw new Exception("All required fields must be filled.");
        }

        // Validate complaint_type against allowed ENUM options
        $allowed_complaint_types = ['final_exam', 'midterm_exam', 'late_announcement', 'Assignments/Quizzes/Labs(Excuses)'];
        if (!in_array($complaint_type, $allowed_complaint_types)) {
            throw new Exception("Invalid complaint type.");
        }

        // Check the number of active complaints for the student
        $check_query = "SELECT COUNT(*) AS active_complaints FROM complaints 
                        WHERE complainant_id = ? AND status = 'Submited'";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bind_param("i", $student_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $row = $result->fetch_assoc();
        $active_complaints = $row['active_complaints'];

        if ($active_complaints >= 3) {
            throw new Exception("You have reached the maximum limit of 3 active complaints.");
        }

        // Fetch the academic advisor AND department for the student
        $student_query = "SELECT academic_advisor, department_id FROM students WHERE student_id = ?";
        $student_stmt = $conn->prepare($student_query);
        $student_stmt->bind_param("i", $student_id);
        $student_stmt->execute();
        $student_result = $student_stmt->get_result();

        if ($student_result->num_rows > 0) {
            $student_row = $student_result->fetch_assoc();
            $recipient = $student_row['academic_advisor'];
            $department = $student_row['department_id']; // Get department directly from student table
        } else {
            throw new Exception("Student record not found.");
        }

        // Validate course selection
        $valid_course = false;
        $courses_result->data_seek(0); // Reset pointer
        while ($course = $courses_result->fetch_assoc()) {
            if ($course['course_name'] === $course_name) {
                $valid_course = true;
                break;
            }
        }
        if (!$valid_course) {
            throw new Exception("Invalid course selection.");
        }

        // Handle file upload conditionally
        $requires_file_upload = ($complaint_type === 'Assignments/Quizzes/Labs(Excuses)');
        if ($requires_file_upload) {
            if (isset($_FILES['file_path']) && $_FILES['file_path']['error'] == UPLOAD_ERR_OK) {
                $target_dir = "uploads/";
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }
                
                // Validate file
                $file_name = basename($_FILES["file_path"]["name"]);
                $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                $allowed_types = ['jpg', 'png', 'pdf', 'docx'];
                
                if (!in_array($file_type, $allowed_types)) {
                    throw new Exception("Only JPG, PNG, PDF, DOCX files are allowed.");
                }
                
                // Check file size (max 5MB)
                if ($_FILES["file_path"]["size"] > 5000000) {
                    throw new Exception("File size exceeds 5MB limit.");
                }
                
                // Generate unique filename
                $target_file = $target_dir . uniqid('file_', true) . '.' . $file_type;

                if (!move_uploaded_file($_FILES["file_path"]["tmp_name"], $target_file)) {
                    throw new Exception("Error uploading file.");
                }
                $file_path = $target_file;
            } else {
                throw new Exception("File upload is required for this complaint type.");
            }
        }

        // Insert complaint into the database with department
        $status = 'Submited';
        $stmt = $conn->prepare("INSERT INTO complaints 
                               (complainant_id, complaint_type, course_name, 
                                complaint_description, file_path, recipient, 
                                status, complaint_department) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssiss", 
            $student_id, 
            $complaint_type, 
            $course_name, 
            $description, 
            $file_path, 
            $recipient, 
            $status,
            $department // Include department directly from student record
        );

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => "Your complaint was submitted successfully and sent to your academic advisor."]);
        } else {
            throw new Exception("Error submitting complaint: " . $stmt->error);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => "Error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES)]);
    } finally {
        if (isset($stmt)) {
            $stmt->close();
        }
        $conn->close();
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Submission</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>

        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "segoe ui", roboto, oxygen, ubuntu, cantarell, "fira sans", "droid sans", "helvetica neue", Arial, sans-serif;
            font-size: 16px;
        }
        /* Navigation Bar Styles */
        .navtop {
            background-color: #2f3947;
            height: 60px;
            width: 100%;
            border: 0;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navtop div {
            display: flex;
            margin: 0 auto;
            max-width: 1200px;
            height: 100%;
            padding: 0 20px;
            align-items: center;
        }
        
        .navtop div h1, .navtop div a {
            display: inline-flex;
            align-items: center;
            color: #eaebed;
            text-decoration: none;
        }
        
        .navtop div h1 {
            flex: 1;
            font-size: 24px;
            padding: 0;
            margin: 0;
            font-weight: normal;
        }
        
        .navtop div a {
            padding: 0 15px;
            font-weight: bold;
            color: #c1c4c8;
            transition: color 0.3s ease;
        }
        
        .navtop div a i {
            padding: 2px 8px 0 0;
        }
        
        .navtop div a:hover {
            color: #eaebed;
        }
        
        .logo img {
            height: 40px;
            margin-right: 10px;
        }
        
        /* Form Container Styles */
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            margin: 100px auto 40px;
            animation: fadeIn 0.5s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .form-container h2 {
            margin-bottom: 20px;
            color: #2f3947;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
        
        .form-container label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
            color: #2f3947;
            font-size: 16px;
        }
        
        .form-container select,
        .form-container textarea,
        .form-container input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: all 0.3s ease;
            background-color: #f9f9f9;
        }
        
        .form-container select:focus,
        .form-container textarea:focus {
            border-color: #2f3947;
            box-shadow: 0 0 5px rgba(47, 57, 71, 0.3);
            outline: none;
            background-color: #fff;
        }
        
        .form-container textarea {
            resize: vertical;
            min-height: 120px;
        }
        
        .form-container button {
            background-color: #2f3947;
            color: white;
            padding: 14px 24px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            margin-top: 20px;
        }
        
        .form-container button:hover {
            background-color: #1e252b;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        /* Alert Styling */
        #alert-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
        }
        
        .alert {
            padding: 15px 25px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-weight: bold;
            animation: slideIn 0.3s ease-out;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        
        @keyframes slideIn {
            from { transform: translateX(100px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Account Details Table */
        .account-details {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        
        .account-details td {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        
        .account-details td:first-child {
            font-weight: bold;
            width: 30%;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .navtop div {
                flex-wrap: wrap;
                height: auto;
                padding: 10px;
            }
            
            .navtop div h1 {
                width: 100%;
                margin-bottom: 10px;
                text-align: center;
            }
            
            .navtop div a {
                padding: 8px 10px;
                font-size: 14px;
            }
            
            .form-container {
                margin-top: 120px;
                padding: 20px;
            }
            
            #alert-container {
                top: 140px;
                left: 20px;
                right: 20px;
            }
            
            .alert {
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navtop">
        <div>
            <a href="../phpsubmit/logo.png" class="logo">
                <img src="../phpsubmit/logo.png" alt="Logo">
            </a>
            <h1>Voice of Student</h1>
            <a href="../student_dashboard/Profile/profile.php"><i class="fas fa-user-circle"></i>Profile</a>
            <a href="../student_dashboard/Home/student_dashboard.php"> <i class="fas fa-home"></i> Back to Home</a>
            <a href="../logout/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
        </div>
    </nav>
    
    <!-- Alert Container -->
    <div id="alert-container"></div>
    
    <!-- Complaint Form -->
    <div class="form-container">
        <h2>Submit Your Complaint</h2>
        <form action="" method="POST" enctype="multipart/form-data" id="complaintForm">
            <div>
                <p>Your account details:</p>
                <table class="account-details">
                    <tr>
                        <td>ID:</td>
                        <td><?= isset($_SESSION['student_id']) ? htmlspecialchars($_SESSION['student_id'], ENT_QUOTES) : 'Not Available'; ?></td>
                    </tr>
                    <tr>
                        <td>Username:</td>
                        <td><?= isset($_SESSION['name']) ? htmlspecialchars($_SESSION['name'], ENT_QUOTES) : 'Not Available'; ?></td>
                    </tr>
                </table>
            </div>
            
            <label for="complaint_type">Complaint Type:</label>
            <select id="complaint_type" name="complaint_type" required>
                <option value="" disabled selected>Select a Type</option>
                <?php
                $complaint_types = [
                    'final_exam' => 'Final Exam',
                    'midterm_exam' => 'MidTerm Exam',
                    'late_announcement' => 'Late Announcement',
                    'Assignments/Quizzes/Labs(Excuses)' => 'Academic Excuses (Assignment/Quizzes/Labs)'
                ];
                foreach ($complaint_types as $value => $label) {
                    echo '<option value="' . htmlspecialchars($value, ENT_QUOTES) . '">' . htmlspecialchars($label, ENT_QUOTES) . '</option>';
                }
                ?>
            </select>
            
            <label for="course_name">Course Name:</label>
            <select id="course_name" name="course_name" required>
                <option value="" disabled selected>Select a Course</option>
                <?php 
                if ($courses_result->num_rows > 0) {
                    $courses_result->data_seek(0); // Reset pointer
                    while ($course = $courses_result->fetch_assoc()) {
                        echo '<option value="' . htmlspecialchars($course['course_name'], ENT_QUOTES) . '">' . htmlspecialchars($course['course_name'], ENT_QUOTES) . '</option>';
                    }
                } else {
                    echo '<option value="" disabled>No courses available</option>';
                }
                ?>
            </select>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description" placeholder="Please provide detailed information about your complaint..." required></textarea>
            
            <div id="fileUploadSection" style="display: none;">
                <label for="file_path">Upload Supporting Document (Required):</label>
                <input type="file" id="file_path" name="file_path" accept=".jpg,.png,.pdf,.docx">
                <p class="file-hint" style="font-size: 14px; color: #666; margin-top: 5px;">
                    Accepted formats: JPG, PNG, PDF, DOCX (Max 5MB)
                </p>
            </div>
            
            <button type="submit">Submit Complaint</button>
        </form>
    </div>

    <script>
        // Show/hide file upload section based on complaint type
        document.getElementById('complaint_type').addEventListener('change', function() {
            const fileUploadSection = document.getElementById('fileUploadSection');
            const selectedType = this.value;
            fileUploadSection.style.display = (selectedType === 'Assignments/Quizzes/Labs(Excuses)') ? 'block' : 'none';
            
            // Toggle required attribute for file input
            const fileInput = document.getElementById('file_path');
            if (selectedType === 'Assignments/Quizzes/Labs(Excuses)') {
                fileInput.setAttribute('required', '');
            } else {
                fileInput.removeAttribute('required');
            }
        });

        // Function to show alerts
        function showAlert(message, type) {
            const alertContainer = document.getElementById('alert-container');
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type}`;
            alertDiv.textContent = message;
            alertContainer.appendChild(alertDiv);

            // Remove the alert after 5 seconds
            setTimeout(() => {
                alertDiv.style.opacity = '0';
                setTimeout(() => {
                    alertDiv.remove();
                }, 300);
            }, 5000);
        }

        // Handle form submission via AJAX
        document.getElementById('complaintForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
            // Validate file upload if required
            const complaintType = document.getElementById('complaint_type').value;
            const fileInput = document.getElementById('file_path');
            if (complaintType === 'Assignments/Quizzes/Labs(Excuses)' && fileInput.files.length === 0) {
                showAlert('Please upload a supporting document for this complaint type.', 'error');
                return;
            }

            const formData = new FormData(this);
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

            fetch('', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showAlert(data.message, 'success');
                    // Reset form on success
                    document.getElementById('complaintForm').reset();
                    document.getElementById('fileUploadSection').style.display = 'none';
                    
                    // Redirect after 3 seconds
                    setTimeout(() => {
                        window.location.href = '../student_dashboard/Home/student_dashboard.php';
                    }, 3000);
                } else {
                    showAlert(data.message, 'error');
                }
            })
            .catch(error => {
                showAlert('An unexpected error occurred. Please try again.', 'error');
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Complaint';
            });
        });
    </script>
</body>
</html>