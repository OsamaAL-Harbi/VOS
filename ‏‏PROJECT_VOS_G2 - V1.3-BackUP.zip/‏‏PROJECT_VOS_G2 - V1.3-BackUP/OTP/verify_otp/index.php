<?php
session_start();
$email = htmlspecialchars($_GET['email'] ?? '');
$user_type = htmlspecialchars($_GET['user_type'] ?? '');
$error = htmlspecialchars($_GET['error'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --primary-hover: #3a56d4;
            --background: #f8fafc;
            --card: #ffffff;
            --text: #1e293b;
            --text-light: #64748b;
            --error: #ef4444;
            --success: #10b981;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        body {
            background-color: var(--background);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            background-image: radial-gradient(circle at 10% 20%, rgba(67, 97, 238, 0.1) 0%, rgba(67, 97, 238, 0.05) 90%);
        }

        .container {
            width: 100%;
            max-width: 480px;
        }

        .card {
            background-color: var(--card);
            border-radius: 12px;
            box-shadow: var(--shadow);
            padding: 40px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
        }

        .logo {
            text-align: center;
            margin-bottom: 24px;
            color: var(--primary);
            font-size: 32px;
        }

        h2 {
            color: var(--text);
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 24px;
            text-align: center;
        }

        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .alert-danger {
            background-color: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .alert-warning {
            background-color: rgba(234, 179, 8, 0.1);
            color: #a16207;
            border: 1px solid rgba(234, 179, 8, 0.2);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: var(--text);
            font-weight: 500;
            font-size: 14px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
            font-size: 16px;
        }

        input, select {
            width: 100%;
            height: 48px;
            padding: 0 16px 0 42px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 14px;
            color: var(--text);
            transition: all 0.3s ease;
            background-color: var(--background);
        }

        select {
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 16px;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }

        button {
            width: 100%;
            padding: 14px;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            position: relative;
        }

        button:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0);
        }

        button.loading {
            pointer-events: none;
            opacity: 0.8;
        }

        .spinner {
            width: 18px;
            height: 18px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            position: absolute;
            right: 20px;
            display: none;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .attempts-warning {
            color: var(--error);
            margin-top: 10px;
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .resend-link {
            margin-top: 20px;
            text-align: center;
            color: var(--text-light);
            font-size: 14px;
        }

        .resend-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s;
        }

        .resend-link a:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="logo">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h2>Verify Your Identity</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <div>
                        <?= $error ?>
                        <?php if (strpos($error, 'expired') !== false): ?>
                            <div style="margin-top: 8px;">Please request a new verification code.</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <form id="otpForm" method="POST" action="verify_otp.php">
                <input type="hidden" name="email" value="<?= $email ?>">
                
                <div class="form-group">
                    <label for="user_type">Account Type</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user-tag input-icon"></i>
                        <select id="user_type" name="user_type" required>
                            <option value="">Select account type</option>
                            <option value="student" <?= $user_type === 'student' ? 'selected' : '' ?>>Student</option>
                            <option value="faculty" <?= $user_type === 'faculty' ? 'selected' : '' ?>>Faculty</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="otp_code">6-Digit Verification Code</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="text" id="otp_code" name="otp_code" 
                               maxlength="6" pattern="\d{6}" 
                               title="Enter exactly 6 digits" required
                               placeholder="Enter code sent to <?= $email ?>">
                    </div>
                </div>
                
                <button type="submit" id="submitBtn">
                    <i class="fas fa-check-circle"></i> Verify Code
                    <div class="spinner" id="spinner"></div>
                </button>
            </form>

            <div class="resend-link">
                Didn't receive code? <a href="../request_otp/index.html?= urlencode($email) ?>&user_type=<?= urlencode($user_type) ?>">Resend code</a>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const otpForm = document.getElementById('otpForm');
        const submitBtn = document.getElementById('submitBtn');
        const spinner = document.getElementById('spinner');
        const otpInput = document.getElementById('otp_code');

        // Auto-advance between OTP digits
        otpInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/\D/g, '').substring(0, 6);
        });

        // Form submission with loader
        otpForm.addEventListener('submit', function(e) {
            // Client-side validation
            if (!/^\d{6}$/.test(otpInput.value)) {
                e.preventDefault();
                showAlert('Please enter exactly 6 digits', 'error');
                otpInput.focus();
                return;
            }

            // Show loading state
            submitBtn.classList.add('loading');
            spinner.style.display = 'block';
            submitBtn.querySelector('i').style.opacity = '0.5';
        });

        // Function to show alert (for client-side validation)
        function showAlert(message, type = 'error') {
            // Remove existing alerts first
            const existingAlert = document.querySelector('.alert-client');
            if (existingAlert) existingAlert.remove();

            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type === 'error' ? 'danger' : 'warning'} alert-client`;
            alertDiv.innerHTML = `
                <i class="fas ${type === 'error' ? 'fa-exclamation-circle' : 'fa-exclamation-triangle'}"></i>
                ${message}
            `;
            
            const form = document.querySelector('form');
            form.insertBefore(alertDiv, form.firstChild);
            
            // Auto-dismiss after 5 seconds
            setTimeout(() => {
                alertDiv.style.opacity = '0';
                setTimeout(() => alertDiv.remove(), 300);
            }, 5000);
        }

        // Reset loading state if form submission fails
        window.addEventListener('pageshow', function() {
            submitBtn.classList.remove('loading');
            spinner.style.display = 'none';
            submitBtn.querySelector('i').style.opacity = '1';
        });
    });
    </script>
</body>
</html>