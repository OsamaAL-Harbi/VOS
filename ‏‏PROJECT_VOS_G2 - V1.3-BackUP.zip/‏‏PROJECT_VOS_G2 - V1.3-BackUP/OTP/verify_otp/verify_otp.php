<?php
require_once '../database.php';

// Configuration
const OTP_EXPIRY_MINUTES = 15;
const MAX_ATTEMPTS = 5;

session_start();

// Rate limiting
if (!isset($_SESSION['otp_attempts'])) {
    $_SESSION['otp_attempts'] = 0;
}

if ($_SESSION['otp_attempts'] >= MAX_ATTEMPTS) {
    die("Too many attempts. Please try again later.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $otp = preg_replace('/[^0-9]/', '', $_POST['otp_code'] ?? '');
    $user_type = strtolower($_POST['user_type'] ?? '');

    // Validate inputs
    $errors = [];
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address";
    }
    
    if (strlen($otp) !== 6 || !ctype_digit($otp)) {
        $errors[] = "OTP must be exactly 6 digits";
    }
    
    if (!in_array($user_type, ['student', 'faculty'])) {
        $errors[] = "Invalid account type";
    }

    if (!empty($errors)) {
        $_SESSION['otp_attempts']++;
        header("Location: verify_otp.php?" . http_build_query([
            'email' => $email,
            'user_type' => $user_type,
            'error' => implode(", ", $errors)
        ]));
        exit();
    }

    try {
        // Verify OTP
        $stmt = $pdo->prepare("
            SELECT o.* 
            FROM password_reset_otp o
            JOIN {$user_type}s u ON o.user_id = u.{$user_type}_id
            WHERE u.email = :email
            AND o.otp_code = :otp
            AND o.is_used = 0
            AND o.user_type = :user_type
            LIMIT 1
        ");
        
        $stmt->execute([
            ':email' => $email,
            ':otp' => $otp,
            ':user_type' => $user_type
        ]);
        
        $otp_record = $stmt->fetch();

        if (!$otp_record) {
            $_SESSION['otp_attempts']++;
            
            // Check if it's expired or already used
            $stmt = $pdo->prepare("
                SELECT 1 FROM password_reset_otp o
                JOIN {$user_type}s u ON o.user_id = u.{$user_type}_id
                WHERE u.email = :email AND o.otp_code = :otp
                LIMIT 1
            ");
            $stmt->execute([':email' => $email, ':otp' => $otp]);
            
            $error = "Invalid verification code";
            if ($stmt->fetch()) {
                $error = "This code has expired or already been used";
            }
            
            header("Location: verify_otp.php?" . http_build_query([
                'email' => $email,
                'user_type' => $user_type,
                'error' => $error
            ]));
            exit();
        }

        // Mark OTP as used
        $pdo->prepare("
            UPDATE password_reset_otp 
            SET is_used = 1, 
                updated_at = NOW() 
            WHERE otp_id = :otp_id
        ")->execute([':otp_id' => $otp_record['otp_id']]);

        // Reset attempt counter
        $_SESSION['otp_attempts'] = 0;
        
        // Start session for password reset
        $_SESSION['otp_verified'] = true;
        $_SESSION['reset_user_id'] = $otp_record['user_id'];
        $_SESSION['reset_user_type'] = $user_type;
        $_SESSION['reset_expiry'] = time() + (15 * 60); // 15 minutes expiry
        
        header("Location: ../reset_password/reset_password.html");
        exit();
        
    } catch (PDOException $e) {
        error_log("OTP Verification Error: " . $e->getMessage());
        die("A system error occurred. Please try again later.");
    }
}

// Redirect if accessed directly
header("Location: ../request_otp/index.html");
exit();
?>