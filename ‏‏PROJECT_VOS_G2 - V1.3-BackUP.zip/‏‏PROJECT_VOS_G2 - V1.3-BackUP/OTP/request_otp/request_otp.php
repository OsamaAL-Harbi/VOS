<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../database.php';
require_once '../send_email.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email address");
    }

    try {
        error_log("Attempting to find user with email: $email");
        
        // Check both students and faculty tables
        $query = "
            (SELECT student_id AS user_id, 'student' AS user_type 
             FROM students WHERE email = ? LIMIT 1)
            UNION
            (SELECT faculty_id AS user_id, 'faculty' AS user_type 
             FROM faculty_members WHERE email = ? LIMIT 1)
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([$email, $email]);
        $user = $stmt->fetch();

        if (!$user) {
            error_log("No user found with email: $email");
            die("No account found with this email address");
        }

        error_log("Found user: ".print_r($user, true));
        
        // Generate OTP
        $otp_code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiration_time = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        error_log("Generated OTP: $otp_code, expires: $expiration_time");

        // Insert into password_reset_otp
        $insertQuery = "
            INSERT INTO password_reset_otp 
            (user_id, user_type, otp_code, expiration_time) 
            VALUES (?, ?, ?, ?)
        ";
        
        $stmt = $pdo->prepare($insertQuery);
        $stmt->execute([
            $user['user_id'],
            $user['user_type'],
            $otp_code,
            $expiration_time
        ]);
        
        error_log("OTP saved to database for user: ".$user['user_id']);

        // Send email
        $subject = "Your Password Reset Code";
        $message = "Your verification code is: $otp_code\n\nThis code will expire in 15 minutes.";
        
        if (sendOTP($email, $subject, $message)) {
            error_log("OTP email sent to $email");
            header("Location: ../verify_otp/index.php?email=".urlencode($email)."&user_type=".$user['user_type']);
            exit();
        } else {
            throw new Exception("Failed to send OTP email");
        }
        
    } catch (PDOException $e) {
        $error_msg = "Database error: " . $e->getMessage();
        error_log($error_msg);
        die($error_msg); // Show actual error during development
    } catch (Exception $e) {
        $error_msg = "Error: " . $e->getMessage();
        error_log($error_msg);
        die($error_msg);
    }
}

header("Location: index.html");
exit();
?>