<?php
// database.php - Backward compatible version
$host = 'localhost';
$dbname = 'faculty';
$username = 'root';
$password = 'Root';

try {
    // Basic connection without constants
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Alternative way to set attributes if constants aren't available
    $pdo->setAttribute(3, 2); // 3 = PDO::ATTR_ERRMODE, 2 = PDO::ERRMODE_EXCEPTION
    $pdo->setAttribute(19, 2); // 19 = PDO::ATTR_DEFAULT_FETCH_MODE, 2 = PDO::FETCH_ASSOC
    
    // Test connection
    $pdo->query("SELECT 1");
    error_log("Database connected successfully");
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>