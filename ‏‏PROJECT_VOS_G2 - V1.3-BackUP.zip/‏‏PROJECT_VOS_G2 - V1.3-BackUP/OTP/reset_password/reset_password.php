<?php
require_once '../database.php';

session_start();

// Verify OTP verification was completed
if (!isset($_SESSION['otp_verified']) || !$_SESSION['otp_verified'] || 
    !isset($_SESSION['reset_user_id']) || !isset($_SESSION['reset_user_type'])) {
    header("Location: request_otp.php?error=invalid_reset_request");
    exit();
}

// Check session expiration (15 minutes)
if (time() > ($_SESSION['reset_expiry'] ?? 0)) {
    header("Location: request_otp.php?error=session_expired");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get validated user information
        $user_id = $_SESSION['reset_user_id'];
        $user_type = $_SESSION['reset_user_type'];
        
        // Validate passwords
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if ($password !== $confirm_password) {
            throw new Exception("Passwords do not match");
        }
        
        // Enhanced password requirements
        if (strlen($password) < 8) {
            throw new Exception("Password must be at least 8 characters");
        }
        if (!preg_match('/[A-Z]/', $password)) {
            throw new Exception("Password must contain at least one uppercase letter");
        }
        if (!preg_match('/[a-z]/', $password)) {
            throw new Exception("Password must contain at least one lowercase letter");
        }
        if (!preg_match('/[0-9]/', $password)) {
            throw new Exception("Password must contain at least one number");
        }
        
        // Determine table and ID field based on user type
        $table_name = ($user_type === 'student') ? 'students' : 'faculty_members';
        $id_field = $user_type . '_id';
        
        // DEBUG: Log the query details
        error_log("Updating password in $table_name where $id_field = $user_id");
        
        // UPDATE query without updated_at and password hashing
        $query = "UPDATE $table_name SET password = ? WHERE $id_field = ?";
        $stmt = $pdo->prepare($query);
        
        // Execute with parameters as array
        $success = $stmt->execute([$password, $user_id]);
        
        if (!$success) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Database update failed: " . ($errorInfo[2] ?? 'Unknown error'));
        }
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("No records updated - user not found");
        }
        
        // Clear session data
        unset($_SESSION['otp_verified']);
        unset($_SESSION['reset_user_id']);
        unset($_SESSION['reset_user_type']);
        unset($_SESSION['reset_expiry']);
        
        // Redirect to success page
        header("Location: ../../login/index.html?reset=success");
        exit();
        
    } catch (PDOException $e) {
        error_log("Database Exception: " . $e->getMessage());
        error_log("SQL Query: " . ($query ?? 'Not available'));
        die("A database error occurred. Please try again later. Error: " . htmlspecialchars($e->getMessage()));
    } catch (Exception $e) {
        error_log("Application Error: " . $e->getMessage());
        die("An error occurred: " . htmlspecialchars($e->getMessage()));
    }
}

// Show reset form if not POST request
include 'reset_password.html';
?>