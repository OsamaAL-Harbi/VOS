<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require "vendor/autoload.php";

/**
 * Enhanced OTP Email Sender with Security Features
 * 
 * @param string $email Recipient email address
 * @param string $subject Email subject
 * @param string $message Message content (OTP code)
 * @return bool Returns true on success, false on failure
 */
function sendOTP($email, $subject, $message) {
    // Validate and sanitize inputs
    $email = filter_var(trim($email), FILTER_SANITIZE_EMAIL);
    $subject = htmlspecialchars(trim($subject));
    $message = trim($message);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log("[OTP] Invalid email address: $email");
        return false;
    }

    // Extract OTP code from message (assuming format "Your OTP code is: 123456")
    preg_match('/\b\d{6}\b/', $message, $matches);
    $otp_code = $matches[0] ?? '';

    $mail = new PHPMailer(true);

    try {
        // Server settings (using environment variables)
        $mail->isSMTP();
        $mail->Host = getenv('SMTP_HOST') ?: 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = getenv('SMTP_USER') ?: 'vos.info.project@gmail.com';
        $mail->Password = getenv('SMTP_PASS') ?: 'vzfz kwsj fccj xcoy';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = getenv('SMTP_PORT') ?: 587;
        
        // Security settings
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
                'allow_self_signed' => false
            ]
        ];
        $mail->Timeout = 10; // 10 seconds timeout
        $mail->CharSet = 'UTF-8';

        // Sender details
        $mail->setFrom(
            getenv('SMTP_FROM_EMAIL') ?: 'no-reply@vos.project.com',
            getenv('SMTP_FROM_NAME') ?: 'VoS System'
        );
        $mail->addReplyTo('support@vos.project.com', 'VoS Support');

        // Recipient
        $mail->addAddress($email);

        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        
        $mail->Body = sprintf('
        <div style="font-family: \'Inter\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; 
                    max-width: 600px; margin: 20px auto; padding: 0; background: #ffffff; border-radius: 8px; 
                    overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); border: 1px solid #e5e7eb;">
            <div style="background: #4361ee; padding: 24px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
                    <i class="fas fa-shield-alt" style="margin-right: 10px;"></i> OTP Verification
                </h1>
            </div>
            
            <div style="padding: 32px;">
                <p style="font-size: 16px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    Hello,<br>
                    We received a request to reset your password. Please use the following verification code:
                </p>
                
                <div style="background: #f3f4f6; padding: 20px; text-align: center; margin: 0 0 32px 0;
                            font-size: 32px; font-weight: 700; letter-spacing: 3px; color: #1e40af;
                            border-radius: 6px; border: 1px dashed #d1d5db;">
                    %s
                </div>
                
                <div style="background: #fef2f2; padding: 16px; border-radius: 6px; margin-bottom: 24px;
                            border-left: 4px solid #ef4444;">
                    <p style="font-size: 14px; color: #b91c1c; margin: 0;">
                        <i class="fas fa-clock" style="margin-right: 8px;"></i>
                        <strong>This code will expire in 15 minutes.</strong>
                    </p>
                </div>
                
                <p style="font-size: 15px; line-height: 1.6; color: #4b5563; margin-bottom: 24px;">
                    If you didn\'t request this password reset, please secure your account immediately by 
                    changing your password from the system in Profile Update Password.
                </p>
                
                <div style="background: #f9fafb; padding: 16px; border-radius: 6px; margin-top: 32px;
                            border-top: 1px solid #e5e7eb; font-size: 12px; color: #6b7280;">
                    <p style="margin: 0 0 8px 0; font-weight: 600;">SECURITY INFORMATION</p>
                    <table style="width: 100%%; border-collapse: collapse;">
                        <tr>
                            <td style="padding: 4px 0; width: 100px;">Request ID:</td>
                            <td style="padding: 4px 0; font-family: monospace;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">IP Address:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">Time:</td>
                            <td style="padding: 4px 0;">%s (UTC)</td>
                        </tr>
                        <tr>
                            <td style="padding: 4px 0;">User Agent:</td>
                            <td style="padding: 4px 0;">%s</td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div style="background: #f9fafb; padding: 16px; text-align: center; font-size: 12px; 
                        color: #9ca3af; border-top: 1px solid #e5e7eb;">
                <p style="margin: 0;">For security reasons, please do not share this code with anyone.</p>
            </div>
        </div>',
        $otp_code,
        bin2hex(random_bytes(8)), // Longer request ID for better security
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        gmdate('Y-m-d H:i:s'), // Using UTC time
        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    );
    
    // Plain text fallback
    $mail->AltBody = sprintf(
        "ACCOUNT SECURITY VERIFICATION\n\n" .
        "Your verification code is: %s\n\n" .
        "This code will expire in 15 minutes.\n\n" .
        "SECURITY INFORMATION:\n" .
        "Request ID: %s\n" .
        "IP Address: %s\n" .
        "Time: %s (UTC)\n" .
        "User Agent: %s\n\n" .
        "If you didn't request this password reset, please secure your account immediately.\n\n" .
        "For security reasons, please do not share this code with anyone.",
        $otp_code,
        bin2hex(random_bytes(8)),
        $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        gmdate('Y-m-d H:i:s'),
        $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    );

        // Send and log
        $mail->send();
        error_log("[OTP] Sent to $email | Code: $otp_code | IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        return true;

    } catch (Exception $e) {
        error_log("[OTP ERROR] Failed to send to $email: " . $mail->ErrorInfo);
        return false;
    } finally {
        $mail->clearAddresses();
        $mail->clearAttachments();
    }
}