<?php
// Start session if needed
session_start();

// Set page title
$pageTitle = "Data Visualization Dashboard";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Data Visualization System</title>
    <!-- Include Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Include Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <!-- Include DataTables for enhanced tables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>
<body>
    <!-- Loader -->
    <div id="loader" class="loader-container hidden">
        <div class="loader"></div>
    </div>

    <!-- Notification -->
    <div id="notification" class="notification hidden" role="alert">
        <i class="fas fa-info-circle"></i>
        <span id="notification-message">Notification message</span>
    </div>

    <!-- App Container -->
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <i class="fas fa-chart-line"></i>
                <h3>Analytics Pro</h3>
            </div>
            <div class="sidebar-menu">
                <ul>
                    <li>
                        <a href="#" class="active">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fas fa-chart-bar"></i>
                            <span>Analytics</span>
                            <span class="badge">3</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="has-submenu">
                            <i class="fas fa-table"></i>
                            <span>Reports</span>
                            <i class="fas fa-chevron-down"></i>
                        </a>
                        <div class="submenu">
                            <a href="#">Sales</a>
                            <a href="#">Inventory</a>
                            <a href="#">Customers</a>
                        </div>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fas fa-users"></i>
                            <span>Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fas fa-question-circle"></i>
                            <span>Help</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Header -->
            <header class="top-header">
                <div class="header-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <div class="search-box">
                        <input type="text" placeholder="Search...">
                        <i class="fas fa-search"></i>
                    </div>
                </div>
                <div class="header-right">
                    <div class="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="badge">5</span>
                    </div>
                    <div class="messages">
                        <i class="fas fa-envelope"></i>
                        <span class="badge">3</span>
                    </div>
                    <div class="user-profile" id="userProfile">
                        <div class="user-avatar">JD</div>
                        <span>John Doe</span>
                        <i class="fas fa-chevron-down"></i>
                        <div class="dropdown-menu" id="dropdownMenu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="#"><i class="fas fa-cog"></i> Settings</a>
                            <div class="dropdown-divider"></div>
                            <a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content Wrapper -->
            <div class="content-wrapper">
                <!-- Page Header -->
                <div class="page-header">
                    <div class="page-title">
                        <h1>Data Visualization Dashboard</h1>
                        <ul class="breadcrumb">
                            <li><a href="#">Home</a></li>
                            <li>Dashboard</li>
                        </ul>
                    </div>
                    <div class="page-actions">
                        <button class="btn btn-secondary">
                            <i class="fas fa-download"></i> Export
                        </button>
                        <button class="btn btn-success" id="refreshData">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card primary">
                        <i class="fas fa-users"></i>
                        <div class="stat-info">
                            <h3 id="totalStudents">1,245</h3>
                            <p>Total Students</p>
                        </div>
                    </div>
                    <div class="stat-card success">
                        <i class="fas fa-graduation-cap"></i>
                        <div class="stat-info">
                            <h3 id="totalCourses">42</h3>
                            <p>Total Courses</p>
                        </div>
                    </div>
                    <div class="stat-card warning">
                        <i class="fas fa-building"></i>
                        <div class="stat-info">
                            <h3 id="totalDepartments">8</h3>
                            <p>Total Departments</p>
                        </div>
                    </div>
                    <div class="stat-card danger">
                        <i class="fas fa-chart-line"></i>
                        <div class="stat-info">
                            <h3 id="enrollmentRate">12.5%</h3>
                            <p>Enrollment Rate</p>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h3>Student Enrollment Trends</h3>
                                <div class="chart-actions">
                                    <select id="timeRange" class="form-control">
                                        <option value="week">Last Week</option>
                                        <option value="month">Last Month</option>
                                        <option value="year" selected>Last Year</option>
                                    </select>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="enrollmentChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h3>Department Distribution</h3>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="departmentChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tabs Section -->
                <div class="card">
                    <div class="card-header">
                        <div class="tabs">
                            <div class="tab active" data-tab="students">Students</div>
                            <div class="tab" data-tab="courses">Courses</div>
                            <div class="tab" data-tab="departments">Departments</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="tab-content active" id="students-tab">
                            <div class="table-responsive">
                                <table class="data-table" id="studentsTable">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Department</th>
                                            <th>Enrollment Date</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Data will be loaded here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-content" id="courses-tab">
                            <div class="table-responsive">
                                <table class="data-table" id="coursesTable">
                                    <thead>
                                        <tr>
                                            <th>Code</th>
                                            <th>Name</th>
                                            <th>Department</th>
                                            <th>Students</th>
                                            <th>Instructor</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Data will be loaded here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-content" id="departments-tab">
                            <div class="table-responsive">
                                <table class="data-table" id="departmentsTable">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Head</th>
                                            <th>Students</th>
                                            <th>Courses</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Data will be loaded here -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Profile Modal -->
    <div class="modal" id="profileModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>User Profile</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                <form id="profileForm">
                    <div class="form-group">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" value="John Doe">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="john.doe@example.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Role</label>
                        <input type="text" class="form-control" value="Administrator" disabled>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Login</label>
                        <input type="text" class="form-control" value="2023-11-15 14:30:22" disabled>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary modal-close">Cancel</button>
                <button class="btn btn-success">Save Changes</button>
            </div>
        </div>
    </div>

    <script>
        // DOM Elements
        const sidebar = document.getElementById('sidebar');
        const toggleSidebar = document.getElementById('toggleSidebar');
        const userProfile = document.getElementById('userProfile');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const refreshBtn = document.getElementById('refreshData');
        const tabs = document.querySelectorAll('.tab');
        const tabContents = document.querySelectorAll('.tab-content');
        const profileModal = document.getElementById('profileModal');
        const modalCloseBtns = document.querySelectorAll('.modal-close');
        const loader = document.getElementById('loader');
        const notification = document.getElementById('notification');
        const notificationMessage = document.getElementById('notification-message');
        const submenuToggles = document.querySelectorAll('.has-submenu');

        // Chart instances
        let enrollmentChart;
        let departmentChart;
        let studentsTable;
        let coursesTable;
        let departmentsTable;

        // Initialize the system
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize sidebar toggle
            toggleSidebar.addEventListener('click', function() {
                sidebar.classList.toggle('show');
            });

            // Initialize user profile dropdown
            userProfile.addEventListener('click', function(e) {
                e.stopPropagation();
                dropdownMenu.classList.toggle('show');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function() {
                dropdownMenu.classList.remove('show');
            });

            // Initialize submenus
            submenuToggles.forEach(toggle => {
                toggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    const submenu = this.nextElementSibling;
                    submenu.classList.toggle('show');
                    const icon = this.querySelector('.fa-chevron-down');
                    icon.classList.toggle('fa-chevron-up');
                });
            });

            // Initialize tabs
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // Remove active class from all tabs and contents
                    tabs.forEach(t => t.classList.remove('active'));
                    tabContents.forEach(c => c.classList.remove('active'));
                    
                    // Add active class to clicked tab and corresponding content
                    this.classList.add('active');
                    document.getElementById(`${tabId}-tab`).classList.add('active');
                });
            });

            // Initialize modals
            modalCloseBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    profileModal.classList.remove('show');
                });
            });

            // Profile link in dropdown
            dropdownMenu.querySelector('a[href="#"]').addEventListener('click', function(e) {
                e.preventDefault();
                profileModal.classList.add('show');
                dropdownMenu.classList.remove('show');
            });

            // Refresh data button
            refreshBtn.addEventListener('click', function() {
                loadData();
                showNotification('Data refreshed successfully', 'success');
            });

            // Initialize DataTables
            studentsTable = $('#studentsTable').DataTable({
                responsive: true,
                columns: [
                    { data: 'id' },
                    { data: 'name' },
                    { data: 'email' },
                    { data: 'department' },
                    { data: 'enrollment_date' },
                    { 
                        data: 'status',
                        render: function(data) {
                            const badgeClass = data === 'Active' ? 'success' : 'warning';
                            return `<span class="badge badge-${badgeClass}">${data}</span>`;
                        }
                    },
                    {
                        data: null,
                        render: function() {
                            return `
                                <button class="btn btn-sm btn-primary"><i class="fas fa-eye"></i></button>
                                <button class="btn btn-sm btn-success"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                            `;
                        }
                    }
                ]
            });

            coursesTable = $('#coursesTable').DataTable({
                responsive: true
            });

            departmentsTable = $('#departmentsTable').DataTable({
                responsive: true
            });

            // Load initial data
            loadData();
        });

        // Load data function
        function loadData() {
            showLoader();
            
            // Simulate API calls with setTimeout
            setTimeout(() => {
                // Update stats cards
                document.getElementById('totalStudents').textContent = '1,342';
                document.getElementById('totalCourses').textContent = '45';
                document.getElementById('totalDepartments').textContent = '8';
                document.getElementById('enrollmentRate').textContent = '14.2%';

                // Load enrollment chart data
                loadEnrollmentChart();
                
                // Load department chart data
                loadDepartmentChart();
                
                // Load tables data
                loadTablesData();
                
                hideLoader();
            }, 1500);
        }

        // Load enrollment chart
        function loadEnrollmentChart() {
            const ctx = document.getElementById('enrollmentChart').getContext('2d');
            const timeRange = document.getElementById('timeRange').value;
            
            // Sample data based on time range
            let labels, data;
            if (timeRange === 'week') {
                labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                data = [12, 19, 8, 15, 12, 5, 9];
            } else if (timeRange === 'month') {
                labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
                data = [45, 52, 38, 49];
            } else {
                labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                data = [120, 135, 110, 125, 142, 130, 115, 125, 140, 155, 160, 175];
            }
            
            if (enrollmentChart) {
                enrollmentChart.destroy();
            }
            
            enrollmentChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Student Enrollment',
                        data: data,
                        backgroundColor: 'rgba(52, 152, 219, 0.2)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 20
                            }
                        }
                    }
                }
            });
        }

        // Load department chart
        function loadDepartmentChart() {
            const ctx = document.getElementById('departmentChart').getContext('2d');
            
            const departments = ['Computer Science', 'Engineering', 'Business', 'Arts', 'Science'];
            const studentCounts = [320, 280, 240, 180, 160];
            const backgroundColors = [
                'rgba(52, 152, 219, 0.7)',
                'rgba(46, 204, 113, 0.7)',
                'rgba(155, 89, 182, 0.7)',
                'rgba(241, 196, 15, 0.7)',
                'rgba(231, 76, 60, 0.7)'
            ];
            
            if (departmentChart) {
                departmentChart.destroy();
            }
            
            departmentChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: departments,
                    datasets: [{
                        data: studentCounts,
                        backgroundColor: backgroundColors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        }

        // Load tables data
        function loadTablesData() {
            // Sample students data
            const studentsData = [
                { id: 1001, name: 'John Smith', email: 'john.smith@example.com', department: 'Computer Science', enrollment_date: '2023-09-15', status: 'Active' },
                { id: 1002, name: 'Emily Johnson', email: 'emily.j@example.com', department: 'Engineering', enrollment_date: '2023-09-10', status: 'Active' },
                { id: 1003, name: 'Michael Brown', email: 'michael.b@example.com', department: 'Business', enrollment_date: '2023-08-28', status: 'Active' },
                { id: 1004, name: 'Sarah Davis', email: 'sarah.d@example.com', department: 'Arts', enrollment_date: '2023-09-05', status: 'Inactive' },
                { id: 1005, name: 'Robert Wilson', email: 'robert.w@example.com', department: 'Science', enrollment_date: '2023-09-20', status: 'Active' }
            ];
            
            // Sample courses data
            const coursesData = [
                { code: 'CS101', name: 'Introduction to Programming', department: 'Computer Science', students: 45, instructor: 'Dr. Smith' },
                { code: 'ENG201', name: 'Mechanical Engineering', department: 'Engineering', students: 32, instructor: 'Prof. Johnson' },
                { code: 'BUS301', name: 'Business Management', department: 'Business', students: 28, instructor: 'Dr. Williams' },
                { code: 'ART105', name: 'Modern Art History', department: 'Arts', students: 22, instructor: 'Prof. Davis' },
                { code: 'SCI202', name: 'Advanced Chemistry', department: 'Science', students: 18, instructor: 'Dr. Brown' }
            ];
            
            // Sample departments data
            const departmentsData = [
                { id: 1, name: 'Computer Science', head: 'Dr. Alice Johnson', students: 320, courses: 12 },
                { id: 2, name: 'Engineering', head: 'Dr. Bob Smith', students: 280, courses: 10 },
                { id: 3, name: 'Business', head: 'Dr. Carol Williams', students: 240, courses: 8 },
                { id: 4, name: 'Arts', head: 'Prof. David Brown', students: 180, courses: 6 },
                { id: 5, name: 'Science', head: 'Dr. Eva Davis', students: 160, courses: 7 }
            ];
            
            // Clear and reload tables
            studentsTable.clear().rows.add(studentsData).draw();
            coursesTable.clear().rows.add(coursesData).draw();
            departmentsTable.clear().rows.add(departmentsData).draw();
        }

        // Show loader
        function showLoader(text = 'Loading...') {
            loader.classList.remove('hidden');
        }

        // Hide loader
        function hideLoader() {
            loader.classList.add('hidden');
        }

        // Show notification
        function showNotification(message, type = 'info') {
            notification.className = `notification ${type}`;
            notificationMessage.textContent = message;
            notification.classList.add('show');

            setTimeout(() => notification.classList.remove('show'), 5000);
        }

        // Time range change event
        document.getElementById('timeRange').addEventListener('change', function() {
            loadEnrollmentChart();
            showNotification('Time range updated', 'info');
        });
        // Update your JavaScript to use the PHP endpoints
        async function fetchData(endpoint, params = {}) {
            showLoader();
            try {
                // Convert params to URL query string
                const queryString = new URLSearchParams(params).toString();
                const url = `${endpoint}.php?${queryString}`;
                
                const response = await fetch(url);
                if (!response.ok) throw new Error("Failed to fetch data");
                const data = await response.json();
                if (data.error) throw new Error(data.error);
                return data;
            } catch (error) {
                showNotification(`Error: ${error.message}`, 'error');
                console.error(error);
                return null;
            } finally {
                hideLoader();
            }
        }

        // Update your data loading functions to use the PHP API
        async function loadSystemStats() {
            const response = await fetchData('data', { action: 'stats' });
            if (response && response.status === 'success') {
                document.getElementById('totalStudents').textContent = 
                    response.data.total_students.toLocaleString();
                document.getElementById('totalCourses').textContent = 
                    response.data.total_courses;
                document.getElementById('totalDepartments').textContent = 
                    response.data.total_departments;
                document.getElementById('enrollmentRate').textContent = 
                    `${response.data.enrollment_rate}%`;
            }
        }

        async function loadEnrollmentChart() {
            const timeRange = document.getElementById('timeRange').value;
            const response = await fetchData('data', { 
                action: 'enrollment-trend', 
                range: timeRange 
            });
            
            if (response && response.status === 'success') {
                const labels = response.data.map(item => item.label);
                const data = response.data.map(item => item.value);
                
                // Update chart with new data
                if (enrollmentChart) {
                    enrollmentChart.data.labels = labels;
                    enrollmentChart.data.datasets[0].data = data;
                    enrollmentChart.update();
                }
            }
        }

        // Initialize the system with all data
        async function initializeSystem() {
            // First check if we need to initialize sample data
            const initResponse = await fetchData('data', { action: 'init' });
            
            // Then load all the data
            await Promise.all([
                loadSystemStats(),
                loadEnrollmentChart(),
                loadDepartmentChart(),
                loadTablesData()
            ]);
            
            showNotification('System initialized successfully', 'success');
        }

        // Call initializeSystem when the page loads
        document.addEventListener('DOMContentLoaded', initializeSystem);
    </script>
</body>
</html>