<?php
require_once 'config.php';

// Get the requested action
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Initialize response array
$response = [
    'status' => 'error',
    'message' => 'Invalid action',
    'data' => []
];

// Process different actions
switch ($action) {
    case 'enrollments':
        $response = getDepartmentEnrollments();
        break;
        
    case 'stats':
        $response = getSystemStats();
        break;
        
    case 'students':
        $response = getStudentsData();
        break;
        
    case 'courses':
        $response = getCoursesData();
        break;
        
    case 'departments':
        $response = getDepartmentsData();
        break;
        
    case 'enrollment-trend':
        $timeRange = isset($_GET['range']) ? $_GET['range'] : 'year';
        $response = getEnrollmentTrend($timeRange);
        break;
        
    default:
        // Check if we should initialize sample data
        if ($action === 'init') {
            $response = initializeSampleData();
        }
        break;
}

// Return JSON response
echo json_encode($response);

/**
 * Get department enrollment data
 */
function getDepartmentEnrollments() {
    $conn = getDBConnection();
    
    $query = "SELECT d.id, d.name AS department_name, COUNT(s.id) AS student_count 
              FROM departments d
              LEFT JOIN students s ON s.department_id = d.id
              GROUP BY d.id, d.name
              ORDER BY student_count DESC";
    
    $result = $conn->query($query);
    
    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $data
    ];
}

/**
 * Get system statistics
 */
function getSystemStats() {
    $conn = getDBConnection();
    
    $stats = [
        'total_students' => 0,
        'total_courses' => 0,
        'total_departments' => 0,
        'enrollment_rate' => 0
    ];
    
    // Get total students
    $result = $conn->query("SELECT COUNT(id) AS total FROM students");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stats['total_students'] = (int)$row['total'];
    }
    
    // Get total courses
    $result = $conn->query("SELECT COUNT(id) AS total FROM courses");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stats['total_courses'] = (int)$row['total'];
    }
    
    // Get total departments
    $result = $conn->query("SELECT COUNT(id) AS total FROM departments");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stats['total_departments'] = (int)$row['total'];
    }
    
    // Calculate enrollment rate (simplified)
    $result = $conn->query("SELECT 
                            (SELECT COUNT(id) FROM students WHERE enrollment_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)) AS new_students,
                            (SELECT COUNT(id) FROM students) AS total_students");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['total_students'] > 0) {
            $stats['enrollment_rate'] = round(($row['new_students'] / $row['total_students']) * 100, 2);
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $stats
    ];
}

/**
 * Get students data for table
 */
function getStudentsData() {
    $conn = getDBConnection();
    
    $query = "SELECT s.id, s.first_name, s.last_name, s.email, 
                     d.name AS department, s.enrollment_date, s.status
              FROM students s
              JOIN departments d ON s.department_id = d.id
              ORDER BY s.id";
    
    $result = $conn->query($query);
    
    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $row['name'] = $row['first_name'] . ' ' . $row['last_name'];
            $data[] = $row;
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $data
    ];
}

/**
 * Get courses data for table
 */
function getCoursesData() {
    $conn = getDBConnection();
    
    $query = "SELECT c.code, c.name, d.name AS department, 
                     COUNT(sc.student_id) AS students, 
                     CONCAT(i.first_name, ' ', i.last_name) AS instructor
              FROM courses c
              JOIN departments d ON c.department_id = d.id
              LEFT JOIN student_courses sc ON sc.course_id = c.id
              LEFT JOIN instructors i ON c.instructor_id = i.id
              GROUP BY c.id, c.code, c.name, d.name, i.first_name, i.last_name
              ORDER BY c.code";
    
    $result = $conn->query($query);
    
    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $data
    ];
}

/**
 * Get departments data for table
 */
function getDepartmentsData() {
    $conn = getDBConnection();
    
    $query = "SELECT d.id, d.name, 
                     CONCAT(i.first_name, ' ', i.last_name) AS head,
                     COUNT(s.id) AS students,
                     COUNT(c.id) AS courses
              FROM departments d
              LEFT JOIN instructors i ON d.head_id = i.id
              LEFT JOIN students s ON s.department_id = d.id
              LEFT JOIN courses c ON c.department_id = d.id
              GROUP BY d.id, d.name, i.first_name, i.last_name
              ORDER BY d.id";
    
    $result = $conn->query($query);
    
    $data = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $data
    ];
}

/**
 * Get enrollment trend data
 */
function getEnrollmentTrend($timeRange = 'year') {
    $conn = getDBConnection();
    
    $data = [];
    
    switch ($timeRange) {
        case 'week':
            $query = "SELECT DAYNAME(enrollment_date) AS day, 
                             COUNT(id) AS count
                      FROM students
                      WHERE enrollment_date >= DATE_SUB(NOW(), INTERVAL 1 WEEK)
                      GROUP BY DAY(enrollment_date), DAYNAME(enrollment_date)
                      ORDER BY DAY(enrollment_date)";
            
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $data[] = [
                        'label' => $row['day'],
                        'value' => (int)$row['count']
                    ];
                }
            }
            break;
            
        case 'month':
            $query = "SELECT WEEK(enrollment_date) AS week, 
                             COUNT(id) AS count
                      FROM students
                      WHERE enrollment_date >= DATE_SUB(NOW(), INTERVAL 1 MONTH)
                      GROUP BY WEEK(enrollment_date)
                      ORDER BY WEEK(enrollment_date)";
            
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                $weekCount = 1;
                while($row = $result->fetch_assoc()) {
                    $data[] = [
                        'label' => 'Week ' . $weekCount++,
                        'value' => (int)$row['count']
                    ];
                }
            }
            break;
            
        case 'year':
        default:
            $query = "SELECT MONTHNAME(enrollment_date) AS month, 
                             COUNT(id) AS count
                      FROM students
                      WHERE enrollment_date >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
                      GROUP BY MONTH(enrollment_date), MONTHNAME(enrollment_date)
                      ORDER BY MONTH(enrollment_date)";
            
            $result = $conn->query($query);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $data[] = [
                        'label' => $row['month'],
                        'value' => (int)$row['count']
                    ];
                }
            }
            break;
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => '',
        'data' => $data
    ];
}

/**
 * Initialize sample data in database
 */
function initializeSampleData() {
    $conn = getDBConnection();
    
    
    // Create departments table
    $conn->query("CREATE TABLE departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        head_id INT
    )");
    
    // Create instructors table
    $conn->query("CREATE TABLE instructors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL,
        department_id INT
    )");
    
    // Create courses table
    $conn->query("CREATE TABLE courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(20) NOT NULL,
        name VARCHAR(100) NOT NULL,
        department_id INT,
        instructor_id INT,
        FOREIGN KEY (department_id) REFERENCES departments(id),
        FOREIGN KEY (instructor_id) REFERENCES instructors(id)
    )");
    
    // Create students table
    $conn->query("CREATE TABLE students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL,
        department_id INT,
        enrollment_date DATE NOT NULL,
        status ENUM('Active', 'Inactive') DEFAULT 'Active',
        FOREIGN KEY (department_id) REFERENCES departments(id)
    )");
    
    // Create student_courses junction table
    $conn->query("CREATE TABLE student_courses (
        student_id INT,
        course_id INT,
        enrollment_date DATE,
        PRIMARY KEY (student_id, course_id),
        FOREIGN KEY (student_id) REFERENCES students(id),
        FOREIGN KEY (course_id) REFERENCES courses(id)
    )");
    
    // Insert sample departments
    $departments = ['Computer Science', 'Engineering', 'Business', 'Arts', 'Science'];
    foreach ($departments as $dept) {
        $conn->query("INSERT INTO departments (name) VALUES ('$dept')");
    }
    
    
    foreach ($instructors as $instructor) {
        $conn->query("INSERT INTO instructors (first_name, last_name, email, department_id) 
                      VALUES ('{$instructor[0]}', '{$instructor[1]}', '{$instructor[2]}', {$instructor[3]})");
    }
    
    // Update departments with head instructors
    for ($i = 1; $i <= 5; $i++) {
        $conn->query("UPDATE departments SET head_id = $i WHERE id = $i");
    }
    
    
    foreach ($courses as $course) {
        $conn->query("INSERT INTO courses (code, name, department_id, instructor_id) 
                      VALUES ('{$course[0]}', '{$course[1]}', {$course[2]}, {$course[3]})");
    }
    
    
    for ($i = 0; $i < 50; $i++) {
        $firstName = $firstNames[array_rand($firstNames)];
        $lastName = $lastNames[array_rand($lastNames)];
        $email = strtolower($firstName . '.' . $lastName) . ($i+1) . '@example.com';
        $deptId = rand(1, 5);
        $enrollmentDate = date('Y-m-d', strtotime('-' . rand(0, 365) . ' days'));
        $status = rand(0, 10) > 1 ? 'Active' : 'Inactive';
        
        $conn->query("INSERT INTO students (first_name, last_name, email, department_id, enrollment_date, status) 
                      VALUES ('$firstName', '$lastName', '$email', $deptId, '$enrollmentDate', '$status')");
        
        $studentId = $conn->insert_id;
        
        // Enroll student in 3-5 random courses
        $courseCount = rand(3, 5);
        $courseIds = range(1, 10);
        shuffle($courseIds);
        $selectedCourses = array_slice($courseIds, 0, $courseCount);
        
        foreach ($selectedCourses as $courseId) {
            $conn->query("INSERT INTO student_courses (student_id, course_id, enrollment_date) 
                          VALUES ($studentId, $courseId, '$enrollmentDate')");
        }
    }
    
    $conn->close();
    
    return [
        'status' => 'success',
        'message' => 'Sample data initialized successfully',
        'data' => []
    ];
}
?>