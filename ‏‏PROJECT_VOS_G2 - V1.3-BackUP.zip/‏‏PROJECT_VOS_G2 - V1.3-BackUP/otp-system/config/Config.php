<?php
class Config {
    // Security settings
    const CSRF_TOKEN_LENGTH = 32;
    const OTP_EXPIRY_MINUTES = 15;
    const OTP_LENGTH = 6;
    const MAX_OTP_ATTEMPTS = 3;
    
    // Application settings
    const APP_NAME = 'Secure OTP System';
    const BASE_URL = 'http://yourdomain.com';
    
    // Email settings (for sending OTP)
    const SMTP_HOST = 'smtp.gmail.com';
    const SMTP_PORT = 587;
    const SMTP_USER = 'vos.info.project@gmail.com';
    const SMTP_PASS = 'ycic veds zomw dgdg';
    const EMAIL_FROM = 'no-reply@VoS.Project.com';
}