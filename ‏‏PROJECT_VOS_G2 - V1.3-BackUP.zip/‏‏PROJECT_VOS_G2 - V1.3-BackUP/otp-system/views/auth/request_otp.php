<?php
ob_start();
?>
<h2>Request OTP for Password Reset</h2>
<div class="card">
    <form id="otpRequestForm" method="POST" action="/otp-system/public/index.php?action=request_otp">
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Enter your registered email" required
                   value="<?php echo htmlspecialchars($_GET['email'] ?? ''); ?>">
        </div>
        <button type="submit" id="submitBtn">
            <span id="submitText">Send OTP</span>
            <span id="submitSpinner" class="loading-spinner" style="display: none;"></span>
        </button>
    </form>
</div>
<a href="/otp-system/views/auth/login.php" class="back-link">Back to Login</a>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('otpRequestForm');
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const submitSpinner = document.getElementById('submitSpinner');

    form.addEventListener('submit', function() {
        submitBtn.disabled = true;
        submitText.textContent = 'Sending...';
        submitSpinner.style.display = 'inline-block';
    });
});
</script>
<?php
$content = ob_get_clean();
$title = 'Request OTP';
require_once __DIR__ . '/../layouts/main.php';