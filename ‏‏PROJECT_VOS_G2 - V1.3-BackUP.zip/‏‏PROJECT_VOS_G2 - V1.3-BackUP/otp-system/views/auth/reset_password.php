<?php
ob_start();
$token = $_GET['token'] ?? '';
$email = $_SESSION['reset_email'] ?? '';
?>
<h2>Reset Your Password</h2>
<div class="card">
    <form method="POST" action="/otp-system/public/index.php?action=reset_password">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
        
        <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" placeholder="Enter new password" required>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm new password" required>
        </div>
        
        <button type="submit">Reset Password</button>
    </form>
</div>
<?php
$content = ob_get_clean();
$title = 'Reset Password';
require_once __DIR__ . '/../layouts/main.php';