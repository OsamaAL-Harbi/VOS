<?php
ob_start();
$email = $_GET['email'] ?? '';
?>
<h2>Enter OTP Code</h2>
<div class="card">
    <p style="margin-bottom: 20px;">We've sent a 6-digit OTP code to <strong><?php echo htmlspecialchars($email); ?></strong></p>
    
    <form method="POST" action="/otp-system/public/index.php?action=verify_otp">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
        <div class="form-group">
            <label for="otp">OTP Code</label>
            <input type="text" id="otp" name="otp" placeholder="Enter 6-digit code" required maxlength="6">
        </div>
        <button type="submit">Verify OTP</button>
    </form>
    
    <div class="resend-link">
        Didn't receive code? <a href="/otp-system/views/auth/request_otp.php?email=<?php echo urlencode($email); ?>">Resend OTP</a>
    </div>
</div>
<a href="/otp-system/views/auth/login.php" class="back-link">Back to Login</a>
<?php
$content = ob_get_clean();
$title = 'Verify OTP';
require_once __DIR__ . '/../layouts/main.php';