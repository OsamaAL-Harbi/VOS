<?php
require_once __DIR__ . '/OTPController.php';

class AuthController {
    private $otpController;

    public function __construct() {
        $this->otpController = new OTPController();
    }

    public function handleRequest() {
        session_start();

        $action = $_GET['action'] ?? '';

        switch ($action) {
            case 'request_otp':
                $this->handleOTPRequest();
                break;
            case 'verify_otp':
                $this->handleOTPVerification();
                break;
            case 'reset_password':
                $this->handlePasswordReset();
                break;
            default:
                header("Location: /otp-system/views/auth/request_otp.php");
                exit();
        }
    }

    private function handleOTPRequest() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $result = $this->otpController->requestOTP($email);

            if ($result['success']) {
                $_SESSION['otp_email'] = $email;
                header("Location: /otp-system/views/auth/verify_otp.php?email=" . urlencode($email));
                exit();
            } else {
                $_SESSION['error'] = $result['message'];
                header("Location: /otp-system/views/auth/request_otp.php");
                exit();
            }
        }
    }

    private function handleOTPVerification() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otpCode = $_POST['otp'] ?? '';
            $email = $_POST['email'] ?? $_SESSION['otp_email'] ?? '';
            
            $result = $this->otpController->verifyOTP($otpCode, $email);

            if ($result['success']) {
                header("Location: /otp-system/views/auth/reset_password.php?token=" . urlencode($result['token']));
                exit();
            } else {
                $_SESSION['error'] = $result['message'];
                header("Location: /otp-system/views/auth/verify_otp.php?email=" . urlencode($email));
                exit();
            }
        }
    }

    private function handlePasswordReset() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            $token = $_POST['token'] ?? '';
            
            $result = $this->otpController->resetPassword($email, $newPassword, $confirmPassword, $token);

            if ($result['success']) {
                $_SESSION['success'] = $result['message'];
                header("Location: /otp-system/views/auth/login.php");
                exit();
            } else {
                $_SESSION['error'] = $result['message'];
                header("Location: /otp-system/views/auth/reset_password.php?token=" . urlencode($token));
                exit();
            }
        }
    }
}