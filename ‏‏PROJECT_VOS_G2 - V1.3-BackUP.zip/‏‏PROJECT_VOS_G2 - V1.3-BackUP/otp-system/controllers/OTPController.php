<?php
require_once __DIR__ . '/../models/OTP.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../config/Config.php';

class OTPController {
    private $otpModel;
    private $userModel;

    public function __construct() {
        $this->otpModel = new OTP();
        $this->userModel = new User();
    }

    public function requestOTP($email) {
        // Validate email
        if (empty($email) )
            return ['success' => false, 'message' => 'Email is required'];
        

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Invalid email format'];
        }

        // Check if user exists
        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            return ['success' => false, 'message' => 'Email not found'];
        }

        // Generate OTP
        $otpCode = $this->otpModel->create($user['id'], $email);
        if (!$otpCode) {
            return ['success' => false, 'message' => 'Failed to generate OTP'];
        }

        // Send OTP to user (in a real app, implement email/SMS sending)
        $this->sendOTP($email, $otpCode);

        return ['success' => true, 'message' => 'OTP sent successfully'];
    }

    public function verifyOTP($otpCode, $email) {
        // Validate inputs
        if (empty($otpCode) || empty($email)) {
            return ['success' => false, 'message' => 'OTP and email are required'];
        }

        // Check if user exists
        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            return ['success' => false, 'message' => 'Email not found'];
        }

        // Validate OTP
        $result = $this->otpModel->validate($otpCode, $user['id'], $email);
        
        if ($result['success']) {
            // Create a verification token for password reset
            $token = bin2hex(random_bytes(32));
            $_SESSION['reset_token'] = $token;
            $_SESSION['reset_email'] = $email;
            
            return ['success' => true, 'token' => $token];
        }

        return $result;
    }

    public function resetPassword($email, $newPassword, $confirmPassword, $token) {
        // Validate inputs
        if (empty($email) || empty($newPassword) || empty($confirmPassword) || empty($token)) {
            return ['success' => false, 'message' => 'All fields are required'];
        }

        // Verify token
        if (!isset($_SESSION['reset_token']) || $_SESSION['reset_token'] !== $token) {
            return ['success' => false, 'message' => 'Invalid token'];
        }

        if ($_SESSION['reset_email'] !== $email) {
            return ['success' => false, 'message' => 'Email mismatch'];
        }

        // Check password match
        if ($newPassword !== $confirmPassword) {
            return ['success' => false, 'message' => 'Passwords do not match'];
        }

        // Check password strength (minimum 8 chars)
        if (strlen($newPassword) < 8) {
            return ['success' => false, 'message' => 'Password must be at least 8 characters'];
        }

        // Update password
        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            return ['success' => false, 'message' => 'User not found'];
        }

        if ($this->userModel->updatePassword($user['id'], $newPassword)) {
            // Clear reset session
            unset($_SESSION['reset_token']);
            unset($_SESSION['reset_email']);
            
            return ['success' => true, 'message' => 'Password updated successfully'];
        }

        return ['success' => false, 'message' => 'Failed to update password'];
    }

    private function sendOTP($email, $otpCode) {
        // In a real application, implement email sending using PHPMailer or similar
        // This is just a placeholder implementation
        
        $subject = 'Your OTP Code';
        $message = "Your OTP code is: $otpCode\n\nThis code will expire in " . Config::OTP_EXPIRY_MINUTES . " minutes.";
        $headers = 'From: ' . Config::EMAIL_FROM;

        // Uncomment to actually send email (configure your server first)
        // mail($email, $subject, $message, $headers);
        
        // For development, just log the OTP
        error_log("OTP for $email: $otpCode");
    }
}