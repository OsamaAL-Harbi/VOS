<?php
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../config/Config.php';

class OTP {
    private $db;
    private $table = 'password_reset_otp';

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
    }

    public function create($userId, $email) {
        $otpCode = $this->generateOTP();
        $expirationTime = date('Y-m-d H:i:s', strtotime('+' . Config::OTP_EXPIRY_MINUTES . ' minutes'));

        try {
            // Invalidate any existing OTPs for this user
            $this->invalidateExistingOTPs($userId, $email);

            $query = "INSERT INTO {$this->table} 
                      (user_id, otp_code, expiration_time, email) 
                      VALUES (:user_id, :otp_code, :expiration_time, :email)";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':otp_code', $otpCode);
            $stmt->bindParam(':expiration_time', $expirationTime);
            $stmt->bindParam(':email', $email);

            if ($stmt->execute()) {
                return $otpCode;
            }
        } catch (PDOException $e) {
            error_log("OTP Creation Error: " . $e->getMessage());
        }

        return false;
    }

    public function validate($otpCode, $userId, $email) {
        try {
            $query = "SELECT otp_id, expiration_time, is_used, attempts 
                      FROM {$this->table} 
                      WHERE user_id = :user_id 
                      AND otp_code = :otp_code 
                      AND email = :email
                      ORDER BY created_at DESC 
                      LIMIT 1";

            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $userId);
            $stmt->bindParam(':otp_code', $otpCode);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                // Check if OTP is already used
                if ($row['is_used']) {
                    return ['success' => false, 'message' => 'OTP already used'];
                }

                // Check if OTP is expired
                if (strtotime($row['expiration_time']) < time()) {
                    return ['success' => false, 'message' => 'OTP expired'];
                }

                // Check if exceeded max attempts
                if ($row['attempts'] >= Config::MAX_OTP_ATTEMPTS) {
                    return ['success' => false, 'message' => 'Max attempts reached'];
                }

                // Mark OTP as used
                $this->markAsUsed($row['otp_id']);

                return ['success' => true];
            }

            // Increment attempt count if OTP is invalid
            $this->incrementAttempt($userId, $email);

            return ['success' => false, 'message' => 'Invalid OTP'];
        } catch (PDOException $e) {
            error_log("OTP Validation Error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Validation error'];
        }
    }

    private function generateOTP() {
        return str_pad(mt_rand(0, pow(10, Config::OTP_LENGTH) - 1), Config::OTP_LENGTH, '0', STR_PAD_LEFT);
    }

    private function invalidateExistingOTPs($userId, $email) {
        $query = "UPDATE {$this->table} 
                 SET is_used = 1 
                 WHERE user_id = :user_id 
                 AND email = :email 
                 AND is_used = 0";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
    }

    private function markAsUsed($otpId) {
        $query = "UPDATE {$this->table} 
                 SET is_used = 1 
                 WHERE otp_id = :otp_id";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':otp_id', $otpId);
        $stmt->execute();
    }

    private function incrementAttempt($userId, $email) {
        $query = "UPDATE {$this->table} 
                 SET attempts = attempts + 1 
                 WHERE user_id = :user_id 
                 AND email = :email 
                 AND is_used = 0 
                 ORDER BY created_at DESC 
                 LIMIT 1";

        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
    }

    public function cleanupExpiredOTPs() {
        $query = "DELETE FROM {$this->table} 
                 WHERE expiration_time < NOW()";

        $stmt = $this->db->prepare($query);
        $stmt->execute();
    }
}