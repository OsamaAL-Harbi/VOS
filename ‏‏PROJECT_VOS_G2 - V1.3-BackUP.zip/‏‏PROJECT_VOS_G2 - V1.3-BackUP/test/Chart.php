<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        canvas {
            max-width: 600px;
            margin: auto;
        }
    </style>
</head>
<body>
    <h2>Complaints Chart</h2>
    <canvas id="complaintsChart"></canvas>
    
    <?php
        $conn = new mysqli('localhost', 'root', 'Root', 'vosdata');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        
        $sql = "SELECT id, email, COUNT(*) as count FROM student_user GROUP BY id, email";
        $result = $conn->query($sql);
        
        $labels = [];
        $data = [];
        
        while ($row = $result->fetch_assoc()) {
            $labels[] = $row['course'] . ' (' . $row['department'] . ')';
            $data[] = $row['count'];
        }
        
        $conn->close();
    ?>
    
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const ctx = document.getElementById('complaintsChart').getContext('2d');
            const complaintsChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($labels); ?>,
                    datasets: [{
                        label: 'Number of Complaints',
                        data: <?php echo json_encode($data); ?>,
                        backgroundColor: ['red', 'blue', 'green', 'purple', 'orange'],
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>
